"""
intraday_lab / self_test.py
End-to-end check of the machinery on synthetic data, in a throwaway folder.
Run once after installing:  python self_test.py

Expected:
  NULL world (no edge)            -> every family REJECT (no look-ahead, gates hold)
  INJECTED world (beta 0.3)       -> early_late CANDIDATE, regression slope ~0.3
"""
import os
import subprocess
import sys
import shutil
import tempfile
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import config  # noqa: E402
BAR = os.environ.get("INTRADAY_BAR_MINUTES", str(config.BAR_MINUTES))   # test the bar size you will run


def sh(args, root):
    env = dict(os.environ, INTRADAY_ROOT=str(root), INTRADAY_SOURCE=str(root / "bars"),
               INTRADAY_BAR_MINUTES=BAR, PYTHONIOENCODING="utf-8")
    r = subprocess.run([sys.executable, *args], cwd=HERE, env=env, capture_output=True, text=True)
    if r.returncode != 0:
        print(r.stdout[-3000:], r.stderr[-3000:])
        raise SystemExit(f"FAILED: {' '.join(args)}")
    return r.stdout


def world(beta, families):
    root = Path(tempfile.mkdtemp(prefix=f"ilab_selftest_b{beta}_"))
    try:
        sh(["make_synthetic.py", "--days", "1200", "--stocks", "4", "--beta", str(beta)], root)
        sh(["run.py", "split"], root)
        sh(["run.py", "facts"], root)
        out = {}
        for f in families:
            sh(["run.py", "run", "--family", f], root)
            out[f] = sh(["run.py", "evaluate", "--family", f], root)
        return out
    finally:
        shutil.rmtree(root, ignore_errors=True)


def verdict(txt):
    return "CANDIDATE" if "VERDICT: CANDIDATE" in txt else "REJECT"


if __name__ == "__main__":
    print(f"bar size under test: {BAR} minute(s); real data folder: {config.MINUTE_DIR}")
    print("1/2 null world (no edge anywhere) ...")
    null = world(0.0, ["early_late", "tsmom_index", "rules_index", "orb_stocks"])
    for f, t in null.items():
        print(f"   {f}: {verdict(t)}")
    print("2/2 injected early->late momentum (beta 0.3) ...")
    inj = world(0.3, ["early_late"])
    print(f"   early_late: {verdict(inj['early_late'])}")
    line = [l for l in inj["early_late"].splitlines() if l.startswith("r1_full:")]
    print("  ", line[0] if line else "")
    ok = all(verdict(t) == "REJECT" for t in null.values()) and verdict(inj["early_late"]) == "CANDIDATE"
    print("\nSELF-TEST", "PASSED" if ok else "FAILED (null world passed or real effect missed)")
    sys.exit(0 if ok else 1)
