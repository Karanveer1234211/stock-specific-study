"""
intraday_lab / make_synthetic.py
Synthetic intraday bars (generated at 1 minute, saved at config.BAR_MINUTES) for testing the machinery (NOT for research).

  set INTRADAY_ROOT=C:\\QuantData\\intraday_synth
  set INTRADAY_SOURCE=C:\\QuantData\\intraday_synth\\bars
  python make_synthetic.py --days 1500 --stocks 6 --beta 0.0     # null world: nothing should pass
  python make_synthetic.py --days 1500 --stocks 6 --beta 0.3     # injected early->late momentum

Has a U-shaped intraday volatility profile, clustered daily volatility and fat tails.
With --beta b, the NIFTY last half-hour gets an added drift of b * (09:45 return vs prev close).
"""
import argparse
import numpy as np
import pandas as pd
import config


def make(days, n_stocks, beta, seed=7):
    rng = np.random.default_rng(seed)
    dates = pd.bdate_range("2017-01-02", periods=days)
    M = 375                                   # generated at 1 minute, saved at config.BAR_MINUTES
    n = np.arange(M)
    shape = 1 + 1.8 * np.exp(-n / 15) + 0.9 * np.exp(-(M - 1 - n) / 20)
    shape /= np.sqrt((shape ** 2).mean())
    logv = np.zeros(days)
    for t in range(1, days):
        logv[t] = 0.97 * logv[t - 1] + 0.25 * rng.standard_normal()
    sig_d = 0.009 * np.exp(logv - logv.mean())          # ~0.9% daily vol
    minute_idx = pd.to_timedelta(9 * 60 + 15 + n, unit="m")

    def series(market_r=None, mkt_gap=None, b_mkt=0.0, inject=0.0, p0=20000.0, vol_base=0):
        tdf = 4
        eps = rng.standard_t(tdf, (days, M)) / np.sqrt(tdf / (tdf - 2))
        r = sig_d[:, None] * shape[None, :] * eps / np.sqrt(M)
        gap = 0.35 * sig_d * rng.standard_normal(days)
        if market_r is not None:
            r = b_mkt * market_r + 0.8 * r
            gap = b_mkt * mkt_gap + 0.8 * gap
        if inject:
            r1 = gap + r[:, :30].sum(axis=1)
            r[:, 345:] += (inject * r1 / 30)[:, None]
        logp = np.log(p0) + np.cumsum((r.sum(axis=1) + gap))
        close_day = np.exp(logp)
        rows = []
        prev_close = p0
        for t in range(days):
            o_first = prev_close * np.exp(gap[t])
            c = o_first * np.exp(np.cumsum(r[t]))
            o = np.r_[o_first, c[:-1]]
            wig = np.abs(rng.standard_normal((2, M))) * sig_d[t] * shape / np.sqrt(M) * 0.5
            h = np.maximum(o, c) * np.exp(wig[0])
            l = np.minimum(o, c) * np.exp(-wig[1])
            v = (vol_base * shape ** 2 * rng.lognormal(0, 0.4, M)).round() if vol_base else np.zeros(M)
            idx = dates[t] + minute_idx
            rows.append(pd.DataFrame({"open": o, "high": h, "low": l, "close": c, "volume": v}, index=idx))
            prev_close = c[-1]
        df = pd.concat(rows)
        k = config.BAR_MINUTES
        if k > 1:                              # aggregate to the bar size the engine reads
            g = df.groupby(df.index.floor(f"{k}min"))
            df = pd.DataFrame({"open": g["open"].first(), "high": g["high"].max(), "low": g["low"].min(),
                               "close": g["close"].last(), "volume": g["volume"].sum()})
        df.index.name = "timestamp"
        return df.reset_index(), r, gap

    config.MINUTE_DIR.mkdir(parents=True, exist_ok=True)
    nifty, r_m, g_m = series(inject=beta)
    import data
    nifty.to_parquet(data.sym_file(config.INDEX_SYMBOL), index=False)
    bank, _, _ = series(market_r=r_m, mkt_gap=g_m, b_mkt=1.1, p0=45000)
    bank.to_parquet(data.sym_file(config.BANK_INDEX_SYMBOL), index=False)
    for i in range(n_stocks):
        s, _, _ = series(market_r=r_m, mkt_gap=g_m, b_mkt=1.0, p0=float(rng.uniform(300, 3000)), vol_base=40000)
        s.to_parquet(data.sym_file(f"STOCK{i:02d}"), index=False)
        if i == 0:   # a pick-window-only file (like the engine-pick cache): must be left out of stock families
            day = pd.to_datetime(s["timestamp"]).dt.normalize()
            ud = day.unique()
            keep = set()
            for j in rng.choice(len(ud) - 11, size=max(1, len(ud) // 40), replace=False):
                keep.update(ud[j:j + 11])
            s[day.isin(keep)].to_parquet(data.sym_file("PICKONLY"), index=False)
    print(f"wrote synthetic data for {days} days to {config.MINUTE_DIR}")


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--days", type=int, default=1500)
    ap.add_argument("--stocks", type=int, default=6)
    ap.add_argument("--beta", type=float, default=0.0)
    ap.add_argument("--seed", type=int, default=7)
    a = ap.parse_args()
    make(a.days, a.stocks, a.beta, a.seed)
