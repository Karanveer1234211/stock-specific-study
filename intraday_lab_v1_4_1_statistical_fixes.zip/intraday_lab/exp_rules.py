"""
intraday_lab / exp_rules.py
Control family — simple technical rules (Brock, Lakonishok & LeBaron 1992), intraday version.

Purpose: these are the BASELINES. A fancier strategy that cannot beat a moving-average
crossover is not worth its complexity. They are also members of the searched universe,
so the multiple-testing corrections know they were tried (Sullivan, Timmermann & White 1999).

All rules run on 15-minute bars, inside the day only (no overnight windows), flat at EOD.
  VMA  variable-length moving average: long while MA_short > MA_long*(1+band),
       short while MA_short < MA_long*(1-band), flat inside the band.
       (short, long) in {(1,4), (1,8), (2,8), (1,16)} bars x band {0, 0.1%}         = 8
       (1,4) = price vs 1-hour average; (1,16) = price vs 4-hour average.
  TRB  trading-range break: long when the bar closes above the high of the previous
       L bars, short below the low; hold until the opposite break or EOD.
       L in {4, 8, 16} bars (1, 2, 4 hours)                                           = 3
Families: rules_index (NIFTY, futures costs) and rules_stocks (liquid stocks, MIS costs).
Execution identical to exp_tsmom: decided on bar close, traded at the next bar's open.
"""
import numpy as np
import pandas as pd
import config
import data
import universe
from engine import VariantAccumulator
from exp_tsmom import k_bars, hold_returns, lag_signal, score, add_diagnostics

K = 15            # minutes per rule bar


def variants(family):
    v = []
    for s, l in ((1, 4), (1, 8), (2, 8), (1, 16)):
        for band in (0.0, 0.001):
            v.append({"name": f"vma_{s}_{l}_b{band:g}", "rule": "vma", "short": s, "long": l, "band": band, "L": 0})
    for L in (4, 8, 16):
        v.append({"name": f"trb_{L}", "rule": "trb", "short": 0, "long": 0, "band": 0.0, "L": L})
    return v


def _ma(C, n):
    cs = np.cumsum(C, axis=1)
    out = np.full_like(C, np.nan)
    out[:, n - 1:] = (cs[:, n - 1:] - np.c_[np.zeros(len(C)), cs[:, :-n]][:, : C.shape[1] - n + 1]) / n
    return out


def _rolling_prev(A, L, fn):
    """fn (max/min) over the previous L bars within the day; NaN until L bars exist."""
    D, M = A.shape
    out = np.full((D, M), np.nan)
    for j in range(L, M):
        out[:, j] = fn(A[:, j - L:j], axis=1)
    return out


def signal(b, v):
    C = b["C"]
    if v["rule"] == "vma":
        d = _ma(C, v["short"]) / _ma(C, v["long"]) - 1
        d = np.nan_to_num(d)
        return np.where(d > v["band"], 1.0, np.where(d < -v["band"], -1.0, 0.0))
    hi = _rolling_prev(b["H"], v["L"], np.max)
    lo = _rolling_prev(b["L"], v["L"], np.min)
    ev = np.where(C > hi, 1.0, np.where(C < lo, -1.0, np.nan))
    ev[:, 0] = np.where(np.isnan(ev[:, 0]), 0.0, ev[:, 0])
    return pd.DataFrame(ev).ffill(axis=1).fillna(0.0).to_numpy()


def run(family, period="research", symbols=None, only=None, progress=True):
    vs = [v for v in variants(family) if not only or v["name"] in only]
    is_index = family == "rules_index"
    instrument = "index_fut" if is_index else "equity_intraday"
    eod_min = data.minute_of(config.EOD_EXIT_FUTURES if is_index else config.EOD_EXIT_EQUITY)
    accs = {v["name"]: VariantAccumulator(instrument) for v in vs}
    syms = [config.INDEX_SYMBOL] if is_index else (symbols or universe.stock_symbols())
    for i, sym in enumerate(syms):
        try:
            dm, _ = data.load_matrix(sym)
        except Exception as ex:
            print(f"  skip {sym}: {ex}")
            continue
        if progress:
            print(f"  [{i+1}/{len(syms)}] {sym}")
        b = k_bars(dm, K)
        h, nb = hold_returns(dm, b["starts"], eod_min)
        liq = np.ones(len(dm.dates), bool) if is_index else universe.liquid_mask(dm)
        liq_lab = None if is_index else universe.liquidity_label(dm)
        active = data.period_mask(dm.dates, period) & b["warm"] & liq
        for v in vs:
            p = lag_signal(signal(b, v), nb)
            gross, rt, contrib, tcols = score(p, h)
            acc = accs[v["name"]]
            acc.add(dm.dates, gross, rt, active)
            add_diagnostics(acc, contrib, tcols, b["starts"][:nb], active, liq_lab)
    return {v["name"]: (v, accs[v["name"]].finalize()) for v in vs}
