@echo off
REM Use the user's existing 3-minute cache as read-only research input.
set INTRADAY_SOURCE=C:\QuantData\cache_daily\intraday_3m
set INTRADAY_BAR_MINUTES=3
set INTRADAY_ROOT=C:\QuantData\intraday_lab_v1_4_3m

echo === 1. Unit tests ===
python -m pytest tests -q
if errorlevel 1 exit /b 1

echo === 2. Synthetic end-to-end self-test ===
python self_test.py
if errorlevel 1 exit /b 1

echo === 3. Data coverage ===
python run.py coverage
if errorlevel 1 exit /b 1

echo === 4. Data quality audit ===
python run.py audit
if errorlevel 1 exit /b 1

echo === 5. Stylised facts ===
python run.py facts
if errorlevel 1 exit /b 1

echo === 6. Freeze research/lockbox split (first run only) ===
python run.py split
if errorlevel 1 exit /b 1

echo.
echo Preflight complete. Review coverage.csv, data_audit.csv, stylized_facts.csv.
echo Then run a research family and its evaluator manually.
echo Example:
echo   python run.py run --family tsmom_index
echo   python run.py evaluate --family tsmom_index
echo   python run.py run --family orb_stocks
echo   python run.py evaluate --family orb_stocks
