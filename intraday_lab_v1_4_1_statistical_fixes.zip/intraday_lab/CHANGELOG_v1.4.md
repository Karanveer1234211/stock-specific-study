# intraday_lab v1.4 — change log

## Added in this update

### Time-of-day-normalised ORB
- Added four `orb_todband_m15_*` variants to `exp_orb.py`.
- After the first 15 minutes, a completed bar must close beyond the opening-range boundary by a buffer based on the past-only expected volatility for that bar's time slot.
- Uses the opposite edge of the opening range as its stop.
- These variants are part of `orb_stocks`, so the family-level selection corrections account for the larger search family.

### Volatility-conditioned momentum
- Added twelve `ts_*_vol_{low,mid,high}` variants to both `tsmom_index` and `tsmom_stocks`.
- They use the prior session's realised variance compared with a trailing historical distribution; today's signal does not use today's final volatility.
- Added `ex_ante_vol_regime` bucket attribution to the normal daily trade diagnostics.
- Variants remain part of their established families and are not evaluated as an isolated best-of-one result.

### Local cache setup
- Added `preflight_3m_cache.cmd` to force the input source to `C:\QuantData\cache_daily\intraday_3m` and the bar interval to 3 minutes.
- Outputs, ledger and frozen data split are placed in a new directory `C:\QuantData\intraday_lab_v1_4_3m` so they do not contaminate the earlier engine's ledger or split.
- Input cache is read-only.

## Verification performed here
- Python compilation succeeded.
- Unit tests: 21 passed, 1 skipped (optional `arch` SPA reference cross-check skipped in this environment).
- Full synthetic end-to-end `self_test.py` was not run successfully here because `pyarrow` is not installed in this execution environment. Install the declared requirements on Windows, then require `SELF-TEST PASSED` before real-data research.

## Interpretation
The added variants are hypotheses. Passing tests validates code paths and plumbing, not a profitable NSE trading edge. No candidate is promoted and there is no broker/live-trading integration.
