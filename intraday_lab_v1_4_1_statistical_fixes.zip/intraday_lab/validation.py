"""
intraday_lab / validation.py
The research-integrity layer. Plain-English summary of each test:

stationary_bootstrap   Resample whole blocks of consecutive DAYS (random block lengths), so
                       volatility clustering and serial dependence survive the resampling.
reality_check / SPA    "Is the BEST variant in this family really better than doing nothing,
(White 2000,           given that I picked it from N tries?" SPA (Hansen 2005) is the main
 Hansen 2005)          number; it is not dragged down by obviously bad variants.
pbo_cscv               "How often does the in-sample winner land in the bottom half
(Bailey et al. 2017)   out-of-sample?" 0.5 = selection is no better than a coin flip.
deflated_sharpe        "Given N tries, fat tails and skew, how likely is it that the true
(Bailey & LdP 2014)    Sharpe of the chosen variant is above zero?"
oos_r2_clark_west      Recursive out-of-sample R^2 for a predictive regression, with the
                       Clark-West test (GHLZ / Li et al. use this).
"""
import itertools
import math
import numpy as np
import pandas as pd
from scipy import stats
import config


# ----------------------------------------------------------------------------- bootstrap
def stationary_bootstrap_indices(T, B, mean_block, rng):
    p = 1.0 / mean_block
    idx = np.empty((B, T), dtype=np.int64)
    idx[:, 0] = rng.integers(0, T, B)
    new_block = rng.random((B, T)) < p
    fresh = rng.integers(0, T, (B, T))
    for t in range(1, T):
        idx[:, t] = np.where(new_block[:, t], fresh[:, t], (idx[:, t - 1] + 1) % T)
    return idx


def block_bootstrap_ci(x, B=None, mean_block=None, alpha=0.05, seed=None):
    x = np.asarray(x, float)
    B = B or config.BOOTSTRAP_B
    rng = np.random.default_rng(seed if seed is not None else config.SEED)
    idx = stationary_bootstrap_indices(len(x), B, mean_block or config.BOOTSTRAP_MEAN_BLOCK, rng)
    means = x[idx].mean(axis=1)
    return float(x.mean()), float(np.quantile(means, alpha / 2)), float(np.quantile(means, 1 - alpha / 2))


# ----------------------------------------------------------------------------- RC / SPA
def reality_check_spa(F, B=None, mean_block=None, seed=None):
    """F: T x N matrix of relative performance (strategy minus benchmark; benchmark = cash -> F = net returns).
    Null: no strategy has positive expected relative performance.
    Returns p-values: rc (White), spa_l, spa_c (use this), spa_u."""
    F = np.asarray(F, float)
    T, N = F.shape
    B = B or config.BOOTSTRAP_B
    rng = np.random.default_rng(seed if seed is not None else config.SEED)
    idx = stationary_bootstrap_indices(T, B, mean_block or config.BOOTSTRAP_MEAN_BLOCK, rng)
    fbar = F.mean(axis=0)
    boot = np.stack([F[idx[b]].mean(axis=0) for b in range(B)])        # B x N
    sqn = math.sqrt(T)
    # White's Reality Check (not studentised)
    V = np.max(sqn * fbar)
    V_star = np.max(sqn * (boot - fbar), axis=1)
    p_rc = float(np.mean(V_star >= V))
    # Hansen SPA (studentised, data-dependent null)
    omega = np.sqrt(np.var(sqn * (boot - fbar), axis=0, ddof=1))
    omega = np.where(omega > 0, omega, np.inf)
    t_spa = max(0.0, float(np.max(sqn * fbar / omega)))
    thr = -np.sqrt(2 * np.log(np.log(T))) * omega / sqn
    centres = {
        "spa_l": np.maximum(fbar, 0.0),
        "spa_c": fbar * (fbar >= thr),
        "spa_u": fbar,
    }
    out = {"rc": p_rc, "t_spa": t_spa}
    for k, g in centres.items():
        Z = sqn * (boot - g) / omega
        T_star = np.maximum(0.0, Z.max(axis=1))
        out[k] = float(np.mean(T_star >= t_spa))
    out["best"] = int(np.argmax(fbar / np.where(np.isfinite(omega), omega, np.nan)))
    return out


# ----------------------------------------------------------------------------- PBO via CSCV
def pbo_cscv(M, S=None, metric="sharpe"):
    """M: T x N matrix of returns (same days, one column per configuration).
    Returns dict with pbo, logits, perf degradation slope, prob of OOS loss."""
    M = np.asarray(M, float)
    T, N = M.shape
    S = S or config.CSCV_S
    S = min(S, (T // 20) // 2 * 2) if T < S * 20 else S
    if N < 2 or S < 4:
        return {"pbo": np.nan, "note": "not enough configurations or days"}
    blocks = np.array_split(np.arange(T), S)
    bs = np.stack([M[b].sum(axis=0) for b in blocks])           # S x N
    bss = np.stack([(M[b] ** 2).sum(axis=0) for b in blocks])
    bn = np.array([len(b) for b in blocks], float)

    def perf(sel):
        n = bn[sel].sum()
        mu = bs[sel].sum(axis=0) / n
        if metric == "mean":
            return mu
        var = bss[sel].sum(axis=0) / n - mu ** 2
        return mu / np.sqrt(np.maximum(var, 1e-18))

    logits, is_best, oos_best = [], [], []
    allb = np.arange(S)
    for comb in itertools.combinations(allb, S // 2):
        J = np.zeros(S, bool)
        J[list(comb)] = True
        p_is, p_oos = perf(J), perf(~J)
        n_star = int(np.argmax(p_is))
        rank = stats.rankdata(p_oos)[n_star]                   # 1..N
        w = rank / (N + 1)
        logits.append(math.log(w / (1 - w)))
        is_best.append(p_is[n_star])
        oos_best.append(p_oos[n_star])
    logits = np.array(logits)
    is_best, oos_best = np.array(is_best), np.array(oos_best)
    slope = np.polyfit(is_best, oos_best, 1)[0] if np.std(is_best) > 0 else np.nan
    return {"pbo": float(np.mean(logits <= 0)), "n_splits": len(logits), "S": S,
            "median_logit": float(np.median(logits)), "degradation_slope": float(slope),
            "prob_oos_loss": float(np.mean(oos_best < 0))}


# ----------------------------------------------------------------------------- PSR / DSR
EULER_GAMMA = 0.5772156649015329


def psr(sr, T, skew, kurt, sr_star=0.0):
    """Probabilistic Sharpe ratio. sr per-period (daily); kurt is RAW kurtosis (normal = 3)."""
    den = 1 - skew * sr + (kurt - 1) / 4 * sr ** 2
    if den <= 0 or T < 3:
        return np.nan
    return float(stats.norm.cdf((sr - sr_star) * math.sqrt(T - 1) / math.sqrt(den)))


def expected_max_sr(sr_var, n_trials):
    """Expected maximum Sharpe of n_trials skill-less strategies (per-period units)."""
    if n_trials <= 1:
        return 0.0
    n = n_trials
    return math.sqrt(sr_var) * ((1 - EULER_GAMMA) * stats.norm.ppf(1 - 1 / n)
                                + EULER_GAMMA * stats.norm.ppf(1 - 1 / (n * math.e)))


def effective_n(M):
    """Effective number of independent trials from the average pairwise correlation:
    N_eff = N / (1 + (N-1) * mean_rho). Correlated variants count for less."""
    M = np.asarray(M, float)
    N = M.shape[1]
    if N < 2:
        return 1.0
    sd = M.std(axis=0)
    keep = sd > 0
    if keep.sum() < 2:
        return 1.0
    C = np.corrcoef(M[:, keep].T)
    n = C.shape[0]
    rho = (C.sum() - n) / (n * (n - 1))
    rho = max(rho, 0.0)
    return float(np.clip(n / (1 + (n - 1) * rho), 1, n))


def deflated_sharpe(best_returns, family_matrix, n_trials_total=None):
    """Deflated Sharpe diagnostic using one consistent return basis.

    `best_returns` and every column of `family_matrix` must both be NET or both be
    GROSS returns. The caller should compute and report gross and net DSR separately
    if both views are useful. Mixing net candidate Sharpe with gross trial dispersion
    is internally inconsistent and can misstate the selection threshold.
    """
    r = np.asarray(best_returns, float)
    T = len(r)
    sd = r.std(ddof=1)
    sr = r.mean() / sd if sd > 0 else 0.0
    skew = float(stats.skew(r))
    kurt = float(stats.kurtosis(r, fisher=False))
    M = np.asarray(family_matrix, float)
    sds = M.std(axis=0, ddof=1)
    srs = np.where(sds > 0, M.mean(axis=0) / np.where(sds > 0, sds, 1), 0.0)
    n_eff = effective_n(M)
    if n_trials_total and n_trials_total > M.shape[1]:
        n_eff *= n_trials_total / M.shape[1]     # scale for trials logged outside this matrix
    sr0 = expected_max_sr(np.var(srs, ddof=1) if len(srs) > 1 else 0.0, n_eff)
    return {"sr_daily": float(sr), "sr_ann": float(sr * math.sqrt(250)), "skew": skew, "kurt": kurt,
            "n_eff": n_eff, "sr0_daily": float(sr0), "sr0_ann": float(sr0 * math.sqrt(250)),
            "psr0": psr(sr, T, skew, kurt, 0.0), "dsr": psr(sr, T, skew, kurt, sr0),
            "min_trl_days": min_trl(sr, skew, kurt, 0.0)}


def min_trl(sr, skew, kurt, sr_star=0.0, alpha=0.05):
    """Minimum track record length (days) for PSR(sr_star) >= 1-alpha."""
    if sr <= sr_star:
        return np.inf
    z = stats.norm.ppf(1 - alpha)
    return float(1 + (1 - skew * sr + (kurt - 1) / 4 * sr ** 2) * (z / (sr - sr_star)) ** 2)


# ----------------------------------------------------------------------------- OOS R^2
def oos_r2_clark_west(y, X, min_train=250):
    """Expanding-window OLS forecasts of y from X (with intercept), benchmark = expanding mean.
    Returns OOS R^2 and the Clark-West (2007) MSPE-adjusted one-sided t-stat / p-value."""
    y = np.asarray(y, float)
    X = np.atleast_2d(np.asarray(X, float))
    if X.shape[0] != len(y):
        X = X.T
    T = len(y)
    if T <= min_train + 20:
        return {"oos_r2": np.nan, "cw_t": np.nan, "cw_p": np.nan, "n_oos": 0}
    Xc = np.c_[np.ones(T), X]
    f_model, f_bench, actual = [], [], []
    for t in range(min_train, T):
        beta, *_ = np.linalg.lstsq(Xc[:t], y[:t], rcond=None)
        f_model.append(Xc[t] @ beta)
        f_bench.append(y[:t].mean())
        actual.append(y[t])
    f_model, f_bench, actual = map(np.array, (f_model, f_bench, actual))
    e_b = actual - f_bench
    e_m = actual - f_model
    r2 = 1 - np.sum(e_m ** 2) / np.sum(e_b ** 2)
    adj = e_b ** 2 - (e_m ** 2 - (f_bench - f_model) ** 2)
    # Newey-West standard error (5 lags) for the mean of adj
    n = len(adj)
    a = adj - adj.mean()
    lags = 5
    s = a @ a / n
    for L in range(1, lags + 1):
        s += 2 * (1 - L / (lags + 1)) * (a[L:] @ a[:-L]) / n
    t = adj.mean() / math.sqrt(s / n) if s > 0 else np.nan
    return {"oos_r2": float(r2), "cw_t": float(t), "cw_p": float(1 - stats.norm.cdf(t)), "n_oos": n}


def in_sample_ols(y, x):
    """Slope, Newey-West t-stat, R^2 for a single predictor."""
    y = np.asarray(y, float)
    x = np.asarray(x, float)
    X = np.c_[np.ones(len(y)), x]
    beta, *_ = np.linalg.lstsq(X, y, rcond=None)
    e = y - X @ beta
    n = len(y)
    XtX_inv = np.linalg.inv(X.T @ X)
    u = X * e[:, None]
    S = u.T @ u / n
    for L in range(1, 6):
        G = u[L:].T @ u[:-L] / n
        S += (1 - L / 6) * (G + G.T)
    V = n * XtX_inv @ S @ XtX_inv
    r2 = 1 - e @ e / np.sum((y - y.mean()) ** 2)
    return {"slope": float(beta[1]), "t_nw": float(beta[1] / math.sqrt(V[1, 1])), "r2": float(r2), "n": n}


def paired_diff_ci(a, b, **kw):
    """Mean daily difference (a - b) with block-bootstrap CI — used for 'does this filter add value'."""
    return block_bootstrap_ci(np.asarray(a) - np.asarray(b), **kw)


# ----------------------------------------------------------------------------- walk-forward selection
def walk_forward_selection(M, embargo_days=5, min_train_days=250):
    """Re-run the SELECTION RULE chronologically: for each calendar year Y, pick the variant
    with the best Sharpe on all days before Y (minus an embargo gap), then record what that
    pick earned during Y. Returns (per-year DataFrame, concatenated out-of-sample series).
    M: DataFrame of daily net returns, DatetimeIndex x variants."""
    years = sorted(set(M.index.year))
    rows, pieces = [], []
    for y in years:
        start = pd.Timestamp(f"{y}-01-01")
        train = M[M.index < start]
        if embargo_days:
            train = train.iloc[:-embargo_days] if len(train) > embargo_days else train.iloc[:0]
        test = M[M.index.year == y]
        if len(train) < min_train_days or not len(test):
            continue
        sd = train.std(ddof=1).replace(0, np.nan)
        pick = (train.mean() / sd).idxmax()
        r = test[pick]
        pieces.append(r)
        rows.append({"year": y, "picked": pick, "net_pct": r.sum() * 100, "days": len(r),
                     "train_days": len(train)})
    oos = pd.concat(pieces) if pieces else pd.Series(dtype=float)
    return pd.DataFrame(rows), oos
