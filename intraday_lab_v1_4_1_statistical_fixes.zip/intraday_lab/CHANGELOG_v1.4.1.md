# v1.4.1 — Statistical consistency fixes

## Fixed
- Ex-ante volatility regime thresholds now use history ending before the prior session being classified. The prior session's realised variance is no longer included in its own threshold distribution.
- Candidate DSR and family trial-dispersion calculations now use the same return basis. Net DSR is the primary report; gross DSR is reported separately.
- Added regression tests for the regime threshold boundary and DSR basis consistency.

## Validation
- Unit tests: 23 passed, 1 skipped.
- The skipped test cross-checks SPA against `arch` when that optional dependency is available.
- Synthetic end-to-end self-test was attempted but cannot run in this environment because neither `pyarrow` nor `fastparquet` is installed. This remains outstanding; install requirements on Windows and require `SELF-TEST PASSED` before real-data experiments.
- No tests were run against the user's local NSE cache; it is not present in this environment.

## Interpretation
These fixes improve statistical consistency; they do not establish that any strategy is profitable or that execution assumptions match live NSE fills.
