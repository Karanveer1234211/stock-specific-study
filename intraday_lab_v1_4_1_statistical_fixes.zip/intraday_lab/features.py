"""
intraday_lab / features.py
Time-of-day normalisation (Andersen & Bollerslev 1997) and regime variables (Cont 2001).

Everything here is PAST-ONLY: the value used on day t is built from days < t
(rolling windows are shifted by one day). That is the leakage firewall.
"""
import numpy as np
import pandas as pd
import config


def bar_returns(O, C):
    """Within-day log returns per bar. First bar = open->close, so the overnight gap is excluded."""
    R = np.empty_like(C)
    R[:, 0] = np.log(C[:, 0] / O[:, 0])
    R[:, 1:] = np.log(C[:, 1:] / C[:, :-1])
    return R


def expected_variance(R, lookback=None, halflife=None):
    """Expected squared return for each (day, bucket), past-only.

    E[r^2]_{t,n} = mean_{d in t-L..t-1}(r^2_{d,n})  *  level_t
    level_t      = EWMA(daily RV, past) / rolling mean(daily RV, past)

    The bucket mean is the A&B intraday shape; the level term scales it to the
    current volatility regime (volatility clusters, Cont 2001).
    """
    L = lookback or config.SEASONALITY_LOOKBACK
    hl = halflife or config.LEVEL_HALFLIFE
    R2 = pd.DataFrame(R ** 2)
    shape = R2.rolling(L, min_periods=L).mean().shift(1).values
    rv = R2.sum(axis=1)
    level = (rv.ewm(halflife=hl, min_periods=L).mean().shift(1)
             / rv.rolling(L, min_periods=L).mean().shift(1)).values
    return shape * level[:, None]


def relative_volume(V, lookback=None):
    """Volume / past median volume for the same time-of-day bucket."""
    L = lookback or config.SEASONALITY_LOOKBACK
    base = pd.DataFrame(V).rolling(L, min_periods=L).median().shift(1).values
    with np.errstate(divide="ignore", invalid="ignore"):
        rel = V / base
    rel[~np.isfinite(rel)] = np.nan
    return rel


def daily_realized_vol(dm):
    """Daily realised variance from 1-minute returns (gap excluded)."""
    R = bar_returns(dm.O, dm.C)
    return pd.Series((R ** 2).sum(axis=1), index=dm.dates)


def ex_ante_vol_regime(dm, window=250):
    """Regime label known BEFORE the session: tercile (0 low,1 mid,2 high) of the
    PREVIOUS day's realised variance within the trailing `window` days."""
    rv = daily_realized_vol(dm)
    # For session t, classify the previous session's RV using thresholds estimated
    # strictly before that previous session. rv[t-1] must NOT participate in its own
    # classification thresholds; therefore the threshold history ends at t-2.
    prev = rv.shift(1)
    history = rv.shift(2)
    lo = history.rolling(window, min_periods=60).quantile(1 / 3)
    hi = history.rolling(window, min_periods=60).quantile(2 / 3)
    reg = pd.Series(np.where(prev > hi, 2, np.where(prev < lo, 0, 1)), index=rv.index).astype(float)
    reg[lo.isna() | hi.isna() | prev.isna()] = np.nan
    return reg


def trailing_tercile_flag(x, window=250, min_periods=60):
    """True where x_t is above the 2/3 quantile of x over days < t (past-only)."""
    s = pd.Series(x)
    hi = s.shift(1).rolling(window, min_periods=min_periods).quantile(2 / 3)
    unknown = hi.isna().to_numpy()
    out = (s > hi).to_numpy().copy()
    out[unknown] = False
    return out, unknown
