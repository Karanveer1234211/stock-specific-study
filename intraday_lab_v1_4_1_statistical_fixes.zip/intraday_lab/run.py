"""
intraday_lab / run.py — command line entry point.

  python run.py costs                         show the cost model
  python run.py coverage                      what is in the 3-minute cache, which stocks are usable
  python run.py audit                         data validation report for every stored symbol
  python run.py split                         freeze the research / lockbox boundary (once)
  python run.py run --family early_late       simulate a family on the research period, log every variant
  python run.py evaluate --family early_late  RC/SPA, PBO, DSR, CI, gates -> report
  python run.py lockbox --family early_late --confirm      ONE-TIME score of the candidate on the lockbox
  python run.py ledger --export trials.csv

Families: early_late, tsmom_index, rules_index, orb_stocks, tsmom_stocks, rules_stocks
  python run.py facts                         stylized-facts audit of the real data (run before experiments)
"""
import argparse
import json
import sys
import time
import numpy as np
import pandas as pd
import config
import costs
import data
import engine
import ledger
import universe
import validation as V

FAMILIES = ("early_late", "tsmom_index", "rules_index", "orb_stocks", "tsmom_stocks", "rules_stocks")


def run_family(family, period="research", only=None):
    if family == "early_late":
        import exp_early_late as E
        return E.run(period, only=only)
    if family == "orb_stocks":
        import exp_orb as E
        return E.run(period, only=only)
    if family in ("tsmom_index", "tsmom_stocks"):
        import exp_tsmom as E
        return E.run(family, period, only=only)
    if family in ("rules_index", "rules_stocks"):
        import exp_rules as E
        return E.run(family, period, only=only)
    raise SystemExit(f"unknown family {family}; choose from {FAMILIES}")


def cmd_run(a):
    data.get_split()          # refuses to run before the split is frozen
    t0 = time.time()
    res = run_family(a.family, "research")
    summ = {n: engine.summarize(d) for n, (_, d) in res.items()}
    ledger.record_run(a.family, res, summ, "research")
    tab = pd.DataFrame(summ).T.sort_values("sharpe_ann", ascending=False)
    print(tab[["days", "n_trades", "gross_bp_per_trade", "net_bp_per_trade", "mean_daily_net_bp", "sharpe_ann"]].round(2).to_string())
    print(f"\n{len(res)} variants logged to the ledger in {time.time()-t0:.0f}s. Next: python run.py evaluate --family {a.family}")


def cmd_evaluate(a):
    import evaluate
    evaluate.evaluate(a.family, control_csv=a.control)


def cmd_lockbox(a):
    if not a.confirm:
        raise SystemExit("The lockbox can be scored once. Re-run with --confirm when you are sure.")
    hist = ledger.lockbox_history(a.family)
    if hist and not a.force_rescore:
        raise SystemExit(f"Lockbox already scored for {a.family}: {hist}. A second look turns it into research data. "
                         f"Use --force-rescore only for a documented bug fix.")
    con = ledger.connect()
    if a.variant:
        name = a.variant
    else:
        row = con.execute("SELECT name FROM trials WHERE family=? AND decision='candidate' ORDER BY last_run DESC LIMIT 1",
                          (a.family,)).fetchone()
        if not row:
            raise SystemExit("No variant in this family passed the research gates. Nothing to score — that is the answer.")
        name = row[0]
    con.close()
    res = run_family(a.family, "lockbox", only=[name])
    params, daily = res[name]
    s = engine.summarize(daily)
    m, lo, hi = V.block_bootstrap_ci(daily["net"].values)
    net2 = (daily["gross"] - daily["stat_cost"] - 2 * daily["slip_cost"]).mean()
    passed = bool(m > 0 and net2 > 0)
    out = {**s, "ci_bp": [lo * 1e4, hi * 1e4], "net_2x_slip_bp_day": net2 * 1e4, "pass": passed}
    ledger.log_lockbox(a.family, name, out)
    ledger.set_decision(a.family, name, "lockbox_pass" if passed else "lockbox_fail",
                        f"lockbox mean {m*1e4:.2f} bp/day [{lo*1e4:.2f},{hi*1e4:.2f}]")
    print(json.dumps({"family": a.family, "variant": name, **out}, indent=1, default=str))
    print("\nPASS -> freeze the variant and start paper trading." if passed else
          "\nFAIL -> the research result did not carry over. Do not trade it.")


def cmd_audit(a):
    rows = []
    for sym in data.list_symbols():
        try:
            df = data.load_minutes(sym)
            _, rep, _ = data.audit(df, sym)
            rows.append({k: v for k, v in rep.items() if k != "irregular_day_list"})
        except Exception as ex:
            rows.append({"symbol": sym, "error": str(ex)})
    t = pd.DataFrame(rows)
    out = config.ROOT / "data_audit.csv"
    t.to_csv(out, index=False)
    with pd.option_context("display.width", 200, "display.max_columns", 20):
        print(t.drop(columns=["suspected_corp_action_days"], errors="ignore").to_string(index=False))
    print(f"\nWritten {out}. Check: irregular_days, intraday_jumps, suspected_corp_action_days.")


def cmd_split(a):
    if config.SPLIT_FILE.exists():
        print("Already frozen:", config.SPLIT_FILE.read_text())
        return
    dm, _ = data.load_matrix(config.INDEX_SYMBOL)
    print(json.dumps(data.get_split(dm.dates), indent=2))


def cmd_coverage(a):
    import universe
    if not config.MINUTE_DIR.exists():
        raise SystemExit(f"Bar folder not found: {config.MINUTE_DIR}")
    t = universe.coverage_table()
    out = config.ROOT / "coverage.csv"
    out.parent.mkdir(parents=True, exist_ok=True)
    t.to_csv(out, index=False)
    ok = t.get("coverage", pd.Series(dtype=float)) >= config.MIN_COVERAGE
    with pd.option_context("display.width", 200, "display.max_rows", 40):
        print(t.sort_values("days", ascending=False).head(40).round(3).to_string(index=False))
    idx = t[t["symbol"] == config.INDEX_SYMBOL]
    print(f"\nBar folder: {config.MINUTE_DIR}")
    print(f"{len(t)} files; {int(ok.sum())} with >= {config.MIN_COVERAGE:.0%} day coverage (usable); "
          f"{int((~ok).sum())} pick-window or gappy (left out of stock families).")
    if len(idx):
        r = idx.iloc[0]
        print(f"{config.INDEX_SYMBOL}: {r.get('first')} to {r.get('last')}, {r.get('days')} days")
    else:
        print(f"{config.INDEX_SYMBOL} file missing - the NIFTY families cannot run until it is cached.")
    print(f"Full table: {out}")


def cmd_fetch(a):
    raise SystemExit("intraday_lab reads the 3-minute cache that bigmove_deploy's intraday_cache.py maintains;\n"
                     "it does not fetch. To add data, use intraday_cache.py (see README: 'Filling the 3-minute cache').")


def main():
    p = argparse.ArgumentParser()
    sp = p.add_subparsers(dest="cmd", required=True)
    sp.add_parser("costs")
    f = sp.add_parser("fetch"); f.add_argument("--symbols-file"); f.add_argument("--from", dest="start")
    sp.add_parser("audit")
    sp.add_parser("coverage")
    sp.add_parser("facts")
    sp.add_parser("split")
    r = sp.add_parser("run"); r.add_argument("--family", required=True, choices=FAMILIES)
    e = sp.add_parser("evaluate"); e.add_argument("--family", required=True, choices=FAMILIES); e.add_argument("--control")
    l = sp.add_parser("lockbox"); l.add_argument("--family", required=True, choices=FAMILIES)
    l.add_argument("--variant"); l.add_argument("--confirm", action="store_true"); l.add_argument("--force-rescore", action="store_true")
    g = sp.add_parser("ledger"); g.add_argument("--export", default=str(config.ROOT / "trials.csv"))
    a = p.parse_args()
    if a.cmd == "costs":
        for ins in ("equity_intraday", "index_fut"):
            print(costs.cost_table(ins))
    elif a.cmd == "fetch":
        cmd_fetch(a)
    elif a.cmd == "audit":
        cmd_audit(a)
    elif a.cmd == "coverage":
        cmd_coverage(a)
    elif a.cmd == "facts":
        import facts
        facts.run()
    elif a.cmd == "split":
        cmd_split(a)
    elif a.cmd == "run":
        cmd_run(a)
    elif a.cmd == "evaluate":
        cmd_evaluate(a)
    elif a.cmd == "lockbox":
        cmd_lockbox(a)
    elif a.cmd == "ledger":
        ledger.export_csv(a.export)
        print("written", a.export)


if __name__ == "__main__":
    main()
