"""
intraday_lab / evaluate.py
Scores one experiment family on the RESEARCH period and writes a report.

Selection rule (declared): the candidate is the variant with the highest research Sharpe
among variants with at least MIN_TRADES_CANDIDATE trades (a variant that barely trades can
"win" on a near-zero Sharpe while everything else loses to costs).
Gates are in config.GATES. A family PASSES only if its candidate clears every gate.
"""
import datetime as dt
import json
import numpy as np
import pandas as pd
import config
import costs
import data
import engine
import features
import ledger
import validation as V

INSTRUMENT = {"early_late": "index_fut", "tsmom_index": "index_fut", "rules_index": "index_fut",
              "orb_stocks": "equity_intraday", "tsmom_stocks": "equity_intraday", "rules_stocks": "equity_intraday"}


def _fmt(x, nd=2):
    if x is None or (isinstance(x, float) and not np.isfinite(x)):
        return "n/a"
    return f"{x:.{nd}f}"


def neighbours(name, params):
    """Variants whose settings differ from `name` in exactly one parameter (same parameter set)."""
    p0 = {k: v for k, v in params[name].items() if k != "name"}
    out = []
    for n, p in params.items():
        if n == name:
            continue
        q = {k: v for k, v in p.items() if k != "name"}
        if q.keys() != p0.keys():
            continue
        if sum(q[k] != p0[k] for k in p0) == 1:
            out.append(n)
    return out


def evaluate(family, control_csv=None, write=True):
    net = ledger.load_matrix(family, "net")
    gross = ledger.load_matrix(family, "gross").reindex_like(net).fillna(0)
    stat = ledger.load_matrix(family, "stat_cost").reindex_like(net).fillna(0)
    slip = ledger.load_matrix(family, "slip_cost").reindex_like(net).fillna(0)
    ntr = ledger.load_matrix(family, "n_trades").reindex_like(net).fillna(0)
    nact = ledger.load_matrix(family, "n_active").reindex_like(net).fillna(0)
    params = ledger.load_variants(family)
    T, N = net.shape
    lines = []
    P = lines.append
    P(f"# {family} — research evaluation ({dt.date.today()})")
    P(f"Days {T} ({net.index.min().date()} to {net.index.max().date()}), variants {N}, "
      f"trials ever logged for this family {ledger.n_trials(family)}")
    P(f"Costs: {costs.cost_table(INSTRUMENT[family])}\n")

    # ---------------------------------------------------------------- per-variant table
    rows = []
    for c in net.columns:
        n = ntr[c].sum()
        g_trade = (gross[c] * nact[c]).sum() / n * 1e4 if n else np.nan
        n_trade = (net[c] * nact[c]).sum() / n * 1e4 if n else np.nan
        sd = net[c].std(ddof=1)
        rows.append({"variant": c, "trades": int(round(n)), "gross_bp/trade": g_trade, "net_bp/trade": n_trade,
                     "net_bp/day": net[c].mean() * 1e4,
                     "net_2x_slip_bp/day": (gross[c] - stat[c] - 2 * slip[c]).mean() * 1e4,
                     "gross_bp/day": gross[c].mean() * 1e4,
                     "sharpe": net[c].mean() / sd * np.sqrt(250) if sd > 0 else np.nan})
    tab = pd.DataFrame(rows).set_index("variant").sort_values("sharpe", ascending=False)
    P("## Variants (sorted by research Sharpe, net of costs)")
    P(tab.round(2).to_string())
    P(f"\nVariants with positive net mean: {(tab['net_bp/day'] > 0).sum()} of {N}; "
      f"with positive GROSS mean: {(tab['gross_bp/day'] > 0).sum()} of {N}")

    # ---------------------------------------------------------------- family tests
    traded_cols = [c for c in net.columns if ntr[c].sum() > 0]
    F = net[traded_cols].values
    spa = V.reality_check_spa(F) if len(traded_cols) else {"rc": np.nan, "spa_c": np.nan, "spa_l": np.nan, "spa_u": np.nan}
    pbo = V.pbo_cscv(F) if len(traded_cols) >= 2 else {"pbo": np.nan}
    P("\n## Family-level multiple-testing")
    P(f"White Reality Check p = {_fmt(spa['rc'],3)} | Hansen SPA p: lower {_fmt(spa['spa_l'],3)}, "
      f"consistent {_fmt(spa['spa_c'],3)} (primary), upper {_fmt(spa['spa_u'],3)}")
    P(f"PBO (CSCV, S={pbo.get('S','-')}, {pbo.get('n_splits','-')} splits) = {_fmt(pbo['pbo'],3)}; "
      f"median logit {_fmt(pbo.get('median_logit'))}; IS->OOS degradation slope {_fmt(pbo.get('degradation_slope'))}; "
      f"P(OOS loss of IS winner) {_fmt(pbo.get('prob_oos_loss'),3)}")
    P("(PBO measures whether the SELECTION is stable, not whether there is an edge: a family where some "
      "variants simply trade less, and so pay less cost, has a stable ranking and a low PBO even with zero skill. "
      "Read it together with SPA and the CI.)")

    # ---------------------------------------------------------------- candidate
    eligible = tab.index[tab["trades"] >= config.MIN_TRADES_CANDIDATE]
    best = eligible[0] if len(eligible) else tab.index[0]
    if not len(eligible):
        P(f"\n(no variant has >= {config.MIN_TRADES_CANDIDATE} trades; candidate chosen from all)")
    # Net DSR is the primary selection diagnostic: candidate and trial family both
    # include the same transaction-cost assumptions. Gross DSR is reported separately
    # as a diagnostic, never mixed into the net DSR calculation.
    r = net[best].values
    net_family = net[traded_cols].values if len(traded_cols) else r[:, None]
    gross_family = gross[traded_cols].values if len(traded_cols) else gross[best].values[:, None]
    trial_count = ledger.n_trials(family)
    dsr = V.deflated_sharpe(r, net_family, trial_count)
    dsr_gross = V.deflated_sharpe(gross[best].values, gross_family, trial_count)
    mean, lo, hi = V.block_bootstrap_ci(r)
    years = net[best].groupby(net.index.year).sum() * 100
    pos_frac = float((years > 0).mean())
    top = np.sort(r)[::-1]
    pnl = r.sum()
    conc = top[: max(1, int(0.05 * T))].sum() / pnl if pnl > 0 else np.nan
    net2 = (gross[best] - stat[best] - 2 * slip[best]).mean()
    P(f"\n## Candidate: {best}")
    P(f"params: {json.dumps(params.get(best))}")
    P(f"mean net {mean*1e4:.2f} bp/day, 95% block-bootstrap CI [{lo*1e4:.2f}, {hi*1e4:.2f}]")
    P(f"Sharpe {dsr['sr_ann']:.2f} ann | skew {dsr['skew']:.2f} | kurtosis {dsr['kurt']:.1f}")
    P(f"NET PSR(0) {_fmt(dsr['psr0'],3)} | expected max NET Sharpe of {dsr['n_eff']:.1f} effective skill-less trials "
      f"{dsr['sr0_ann']:.2f} ann | NET DSR {_fmt(dsr['dsr'],3)} | min track record {_fmt(dsr['min_trl_days'],0)} days")
    P(f"GROSS Sharpe {dsr_gross['sr_ann']:.2f} ann | GROSS PSR(0) {_fmt(dsr_gross['psr0'],3)} | GROSS DSR {_fmt(dsr_gross['dsr'],3)} (reported separately)")
    P(f"net at 0x / 1x / 2x / 3x slippage (bp/day): "
      + " / ".join(f"{(gross[best]-stat[best]-k*slip[best]).mean()*1e4:.2f}" for k in (0, 1, 2, 3)))
    P(f"share of total profit from best 5% of days: {_fmt(conc)}")
    P("net % by year: " + ", ".join(f"{y}: {v:+.1f}" for y, v in years.items()))

    # regime breakdown (ex-ante NIFTY volatility tercile)
    try:
        idm, _ = data.load_matrix(config.INDEX_SYMBOL)
        reg = features.ex_ante_vol_regime(idm).reindex(net.index)
        rb = net[best].groupby(reg).agg(["mean", "count"])
        P("by ex-ante NIFTY vol regime (0 low / 1 mid / 2 high): " + ", ".join(
            f"{int(k)}: {v['mean']*1e4:+.2f} bp/day (n={int(v['count'])})" for k, v in rb.iterrows()))
    except Exception as ex:
        P(f"(regime breakdown skipped: {ex})")

    # event days (rule-based expiries + events.csv)
    try:
        import events
        cal = events.calendar(net.index)
        eb = net[best].groupby(cal.reindex(net.index).replace("", "ordinary")).agg(["mean", "count"])
        P("by day type: " + ", ".join(f"{k}: {v['mean']*1e4:+.2f} bp/day (n={int(v['count'])})"
                                      for k, v in eb.iterrows()))
    except Exception as ex:
        P(f"(event breakdown skipped: {ex})")

    # ---------------------------------------------------------------- walk-forward selection
    wf_cols = [c for c in traded_cols if c in set(eligible)] or traded_cols or list(net.columns)
    wf_tab, wf_oos = V.walk_forward_selection(net[wf_cols],
                                              embargo_days=config.WF_EMBARGO_DAYS)
    P(f"\n## Walk-forward selection (pick best Sharpe on all prior years, {config.WF_EMBARGO_DAYS}-day embargo, trade next year)")
    if len(wf_oos):
        wm, wl, wh = V.block_bootstrap_ci(wf_oos.values)
        P(wf_tab.round(2).to_string(index=False))
        P(f"walk-forward out-of-sample: mean {wm*1e4:.2f} bp/day [{wl*1e4:.2f}, {wh*1e4:.2f}], "
          f"positive years {int((wf_tab['net_pct'] > 0).sum())} of {len(wf_tab)}, "
          f"picks changed {int((wf_tab['picked'] != wf_tab['picked'].shift()).sum() - 1)} times")
    else:
        wm = np.nan
        P("not enough history for walk-forward (needs > 1 year of training)")

    # ---------------------------------------------------------------- neighbours
    nb_names = neighbours(best, params)
    P(f"\n## Neighbouring parameter sets of {best} (differ in exactly one setting)")
    if nb_names:
        nt = tab.loc[[n for n in nb_names if n in tab.index], ["trades", "net_bp/day", "gross_bp/day", "sharpe"]]
        P(nt.round(2).to_string())
        nb_med = float(nt["net_bp/day"].median())
        P(f"median neighbour net {nb_med:.2f} bp/day vs candidate {tab.loc[best, 'net_bp/day']:.2f}"
          + ("  <- ISOLATED PEAK: neighbours do not share the result" if nb_med <= 0 < tab.loc[best, 'net_bp/day'] else ""))
    else:
        nb_med = np.nan
        P("no neighbours in the declared grid")

    # ---------------------------------------------------------------- buckets
    bk = ledger.load_buckets(family)
    if bk is not None and len(bk[bk["variant"] == best]):
        rt_cost = costs.statutory_round_trip(INSTRUMENT[family]) + costs.slippage_round_trip(INSTRUMENT[family])
        b = bk[bk["variant"] == best].copy()
        b["gross_bp/trade"] = b["gross_sum"] / b["n_trades"] * 1e4
        b["net_bp/trade"] = b["gross_bp/trade"] - rt_cost * 1e4
        P(f"\n## {best} by bucket (per trade; net = gross - {rt_cost*1e4:.2f} bp current round-trip cost)")
        P("Diagnostic only. A good-looking bucket is a NEW hypothesis: declare it as a variant and it gets logged.")
        for dim, g in b.groupby("dim"):
            P(f"[{dim}]")
            P(g.sort_values("bucket")[["bucket", "n_trades", "gross_bp/trade", "net_bp/trade"]]
              .round(2).to_string(index=False))

    # ---------------------------------------------------------------- incremental filters
    filt = {n: p for n, p in params.items()
            if p.get("filter") not in (None, "none")
            or p.get("vol") not in (None, "none")
            or p.get("regime") not in (None, "all")
            or p.get("trigger") == "todband"}
    if filt:
        P("\n## Incremental value of conditioning (candidate minus its unconditioned baseline, bp/day, 95% block-bootstrap CI)")
        P("GROSS diff asks whether the condition changes the underlying return stream before costs.")
        P("NET diff includes changes in turnover/costs as well as any predictive information.")
        P("These are exploratory paired comparisons; interpret them with the family-level SPA/DSR, not as isolated confirmatory tests.")
        for n, p in filt.items():
            if family == "orb_stocks":
                base = f"orb_m15_cbar_eod_range_{p['dir']}"
            elif family == "early_late":
                base = f"el_{p['r1']}_none"
            elif family in ("tsmom_stocks", "tsmom_index"):
                base = f"ts_k{p['k']}_th{p['thr']:g}_{p['align']}"
            else:
                continue
            if base in net.columns:
                gm, gl, gh = V.paired_diff_ci(gross[n].values, gross[base].values)
                m_, l_, h_ = V.paired_diff_ci(net[n].values, net[base].values)
                P(f"{n} vs {base}: GROSS {gm*1e4:+.2f} [{gl*1e4:+.2f}, {gh*1e4:+.2f}] | "
                  f"NET {m_*1e4:+.2f} [{l_*1e4:+.2f}, {h_*1e4:+.2f}]")

    # ---------------------------------------------------------------- GHLZ regressions
    if family == "early_late":
        try:
            import exp_early_late as EL
            rf = EL.regression_frame("research")
            P("\n## Predictive regressions: late half-hour return on early return (research period)")
            for col in ("r1_full", "r1_regular", "r1_gap"):
                ins = V.in_sample_ols(rf["late"], rf[col])
                oos = V.oos_r2_clark_west(rf["late"].values, rf[[col]].values)
                P(f"{col}: slope {ins['slope']:.4f}, NW t {ins['t_nw']:.2f}, R2 {ins['r2']*100:.2f}% | "
                  f"OOS R2 {oos['oos_r2']*100:.2f}%, Clark-West p {_fmt(oos['cw_p'],3)}")
            oos2 = V.oos_r2_clark_west(rf["late"].values, rf[["r1_full", "r12"]].values)
            P(f"r1_full + r12: OOS R2 {oos2['oos_r2']*100:.2f}%, Clark-West p {_fmt(oos2['cw_p'],3)}")
            P(f"reference, always long last half-hour (gross): {rf['late'].mean()*1e4:.2f} bp/day")
        except Exception as ex:
            P(f"(regressions skipped: {ex})")

    # ---------------------------------------------------------------- control
    if control_csv:
        c = pd.read_csv(control_csv, parse_dates=["date"]).set_index("date")["net"]
        c = c.reindex(net.index).fillna(0.0)
        cm, cl, ch = V.block_bootstrap_ci(c.values)
        dm_, dl, dh = V.paired_diff_ci(net[best].values, c.values)
        P(f"\n## Control ({control_csv}): mean {cm*1e4:.2f} bp/day [{cl*1e4:.2f}, {ch*1e4:.2f}]; "
          f"candidate minus control {dm_*1e4:+.2f} [{dl*1e4:+.2f}, {dh*1e4:+.2f}]")

    # ---------------------------------------------------------------- gates
    g = config.GATES
    checks = [
        (f"at least {config.MIN_TRADES_CANDIDATE} trades", tab.loc[best, "trades"] >= config.MIN_TRADES_CANDIDATE),
        ("SPA consistent p < %.2f" % g["spa_c_p_max"], spa["spa_c"] < g["spa_c_p_max"]),
        ("selection holds OOS: PBO < %.2f or P(OOS loss of IS winner) < %.2f" % (g["pbo_max"], g["oos_loss_max"]),
         (pbo["pbo"] < g["pbo_max"]) or (pbo.get("prob_oos_loss", 1) < g["oos_loss_max"])),
        ("DSR > %.2f" % g["dsr_min"], (dsr["dsr"] or 0) > g["dsr_min"]),
        ("CI lower bound > %.1f bp/day" % g["ci_low_min_bp"], lo * 1e4 > g["ci_low_min_bp"]),
        ("positive in >= %.0f%% of years" % (g["pos_year_frac_min"] * 100), pos_frac >= g["pos_year_frac_min"]),
        ("still positive at 2x slippage", net2 > 0 if g["survive_2x_slip"] else True),
        ("walk-forward selection mean net > 0", bool(np.isfinite(wm) and wm > 0) if g["wf_positive"] else True),
        ("neighbour median net > 0 (not an isolated peak)",
         bool(not np.isfinite(nb_med) or nb_med > 0) if g["neighbours_positive"] else True),
    ]
    P("\n## Gates")
    for name, ok in checks:
        P(f"[{'PASS' if ok else 'FAIL'}] {name}")
    verdict = "CANDIDATE (eligible for lockbox)" if all(ok for _, ok in checks) else "REJECT"
    P(f"\nVERDICT: {verdict}")
    reason = "; ".join(n for n, ok in checks if not ok) or "all gates passed"
    ledger.set_decision(family, best, "candidate" if verdict.startswith("CAND") else "reject", reason)

    text = "\n".join(lines)
    if write:
        out = config.RESEARCH_DIR / family / f"report_{dt.date.today()}.md"
        out.write_text(text, encoding="utf-8")
        tab.to_csv(config.RESEARCH_DIR / family / "variants_table.csv")
        print(text)
        print(f"\nReport written: {out}")
    return {"verdict": verdict, "best": best, "spa": spa, "pbo": pbo, "dsr": dsr, "ci": (mean, lo, hi), "text": text}
