"""
intraday_lab / data.py
Load 1-minute bars, validate them, convert to day x minute matrices,
and manage the frozen research / lockbox split.

Conventions
- Timestamps are tz-naive IST, bar START (Kite convention).
- A bar's close is only known when the bar ends, so a signal computed on bar j
  is executed at the OPEN of bar j+1. Every experiment follows this.
"""
import json
import datetime as dt
import numpy as np
import pandas as pd
import config


def _safe(symbol):
    return symbol.replace(" ", "_").replace("&", "and")


def sym_file(symbol):
    """1-minute folder: NIFTY_50.parquet, MandM.parquet (spaces -> _, & -> and).
    3-minute cache: 'NIFTY 50_3m.parquet' as intraday_cache.py writes it. Existing file wins."""
    cands = [config.MINUTE_DIR / f"{symbol}{config.FILE_SUFFIX}.parquet",
             config.MINUTE_DIR / f"{_safe(symbol)}{config.FILE_SUFFIX}.parquet"]
    for c in cands:
        if c.exists():
            return c
    return cands[1] if config.BAR_MINUTES == 1 else cands[0]


def symbol_of(path):
    stem = path.stem
    if config.FILE_SUFFIX and stem.endswith(config.FILE_SUFFIX):
        stem = stem[: -len(config.FILE_SUFFIX)]
    return {"NIFTY_50": "NIFTY 50", "NIFTY_BANK": "NIFTY BANK"}.get(stem, stem)


def list_symbols():
    pat = f"*{config.FILE_SUFFIX}.parquet" if config.FILE_SUFFIX else "*.parquet"
    files = [f for f in sorted(config.MINUTE_DIR.glob(pat))
             if config.FILE_SUFFIX or not f.stem.endswith(("_3m", "_5m", "_15m"))]
    return [symbol_of(f) for f in files]


def load_minutes(symbol):
    f = sym_file(symbol)
    if not f.exists():
        raise FileNotFoundError(f"No minute data for {symbol}: {f}")
    df = pd.read_parquet(f)
    if not isinstance(df.index, pd.DatetimeIndex):
        tcol = next((c for c in ("timestamp", "date", "datetime") if c in df.columns), None)
        if tcol is None:
            raise ValueError(f"{f.name}: no timestamp column")
        df = df.set_index(tcol)
    df.index = pd.to_datetime(df.index)
    if df.index.tz is not None:
        df.index = df.index.tz_convert("Asia/Kolkata").tz_localize(None)
    df = df.sort_index()
    cols = ["open", "high", "low", "close"] + (["volume"] if "volume" in df.columns else [])
    df = df[cols].astype(float)
    if "volume" not in df.columns:
        df["volume"] = 0.0
    return df


# ----------------------------------------------------------------------------- validation
def audit(df, symbol=""):
    """Return (clean_df, report dict). Drops broken rows and irregular days, flags the rest."""
    rep = {"symbol": symbol, "rows_in": len(df)}
    dup = df.index.duplicated(keep="last")
    rep["duplicates"] = int(dup.sum())
    df = df[~dup]

    t = df.index.strftime("%H:%M")
    in_sess = (t >= config.SESSION_START) & (t <= config.SESSION_END_BAR)
    off = (df.index.hour * 60 + df.index.minute) - (9 * 60 + 15)
    aligned = (off % config.BAR_MINUTES == 0) & (df.index.second == 0)
    rep["out_of_session"] = int((~(in_sess & aligned)).sum())
    df = df[in_sess & aligned]

    bad_px = (df[["open", "high", "low", "close"]] <= 0).any(axis=1)
    hi_bad = df["high"] < df[["open", "close", "low"]].max(axis=1) - 1e-9
    lo_bad = df["low"] > df[["open", "close", "high"]].min(axis=1) + 1e-9
    rep["bad_ohlc"] = int((bad_px | hi_bad | lo_bad).sum())
    df = df[~(bad_px | hi_bad | lo_bad)]

    day = df.index.normalize()
    counts = df.groupby(day).size()
    irregular = counts[counts < config.MIN_BARS_PER_DAY].index
    rep["irregular_days"] = len(irregular)
    rep["irregular_day_list"] = [d.strftime("%Y-%m-%d") for d in irregular[:20]]
    df = df[~day.isin(irregular)]

    # minute jumps > 8% inside a day are almost always bad ticks
    r = np.log(df["close"]).diff()
    same_day = df.index.normalize() == pd.Series(df.index.normalize()).shift(1).values
    jumps = (r.abs() > 0.08) & same_day
    rep["intraday_jumps_gt8pct"] = int(jumps.sum())

    # overnight gaps > 20% => suspected unadjusted corporate action
    daily_close = df["close"].groupby(df.index.normalize()).last()
    daily_open = df["open"].groupby(df.index.normalize()).first()
    gap = np.log(daily_open / daily_close.shift(1))
    ca_days = gap[gap.abs() > 0.20].index
    rep["suspected_corp_action_days"] = [d.strftime("%Y-%m-%d") for d in ca_days]
    rep["days"] = int(df.index.normalize().nunique())
    rep["first_day"] = str(df.index.min().date()) if len(df) else None
    rep["last_day"] = str(df.index.max().date()) if len(df) else None
    rep["rows_out"] = len(df)
    return df, rep, set(ca_days)


# ----------------------------------------------------------------------------- matrices
class DayMatrix:
    """Day x minute arrays (D x 375). Missing minutes are forward-filled flat with volume 0."""

    def __init__(self, df, symbol="", corp_action_days=()):
        self.symbol = symbol
        minute_idx = ((df.index.hour * 60 + df.index.minute) - (9 * 60 + 15)) // config.BAR_MINUTES
        days = df.index.normalize()
        self.dates = pd.DatetimeIndex(days.unique())
        d_idx = self.dates.get_indexer(days)
        D, M = len(self.dates), config.BARS_PER_DAY
        arr = {}
        for c in ("open", "high", "low", "close", "volume"):
            a = np.full((D, M), np.nan)
            a[d_idx, minute_idx] = df[c].values
            arr[c] = a
        self.missing = np.isnan(arr["close"])
        # forward fill within day; a leading gap is back-filled from the first real open
        C = pd.DataFrame(arr["close"]).ffill(axis=1).values
        first_open = pd.DataFrame(arr["open"]).bfill(axis=1).values[:, 0]
        C = np.where(np.isnan(C), first_open[:, None], C)
        for c in ("open", "high", "low"):
            arr[c] = np.where(np.isnan(arr[c]), C, arr[c])
        arr["close"] = C
        arr["volume"] = np.nan_to_num(arr["volume"])
        self.O, self.H, self.L, self.C, self.V = (arr[k] for k in ("open", "high", "low", "close", "volume"))
        self.prev_close = np.r_[np.nan, self.C[:-1, -1]]
        # gap unusable on corporate-action days and after a calendar hole > 7 days
        ca = self.dates.isin(list(corp_action_days))
        hole = np.r_[True, np.diff(self.dates.values).astype("timedelta64[D]").astype(int) > 7]
        self.prev_close[ca | hole] = np.nan

    def resample(self, k):
        """Aggregate k base bars into one, aligned at 09:15 (use bars_for(minutes) to get k).
        Returned `starts` are base-bar indices. Last bar may be partial."""
        starts = np.arange(0, config.BARS_PER_DAY, k)
        O = self.O[:, starts]
        H = np.maximum.reduceat(self.H, starts, axis=1)
        L = np.minimum.reduceat(self.L, starts, axis=1)
        ends = np.r_[starts[1:] - 1, config.BARS_PER_DAY - 1]
        C = self.C[:, ends]
        V = np.add.reduceat(self.V, starts, axis=1)
        return O, H, L, C, V, starts


def minute_of(hhmm):
    """Index of the bar that CONTAINS minute hh:mm (bar 0 starts 09:15)."""
    h, m = map(int, hhmm.split(":"))
    return (h * 60 + m - (9 * 60 + 15)) // config.BAR_MINUTES


def bars_for(minutes):
    """Number of base bars in `minutes`; None if it is not a whole number of bars."""
    return minutes // config.BAR_MINUTES if minutes % config.BAR_MINUTES == 0 else None


def bar_start_minute(idx):
    """Minutes after midnight at which bar idx starts."""
    return 9 * 60 + 15 + np.asarray(idx) * config.BAR_MINUTES


def load_matrix(symbol):
    df = load_minutes(symbol)
    clean, rep, ca = audit(df, symbol)
    return DayMatrix(clean, symbol, ca), rep


# ----------------------------------------------------------------------------- frozen split
def get_split(index_dates=None):
    """Research/lockbox boundary, frozen the first time it is computed so that adding
    new data never moves it (new data simply lands in lockbox/forward)."""
    if config.SPLIT_FILE.exists():
        return json.loads(config.SPLIT_FILE.read_text())
    if index_dates is None:
        raise RuntimeError("Split not frozen yet: run 'python run.py split' after fetching data.")
    dates = pd.DatetimeIndex(index_dates)
    cut = int(len(dates) * (1 - config.LOCKBOX_FRACTION))
    sp = {
        "research_start": str(dates[0].date()),
        "research_end": str(dates[cut - 1].date()),
        "lockbox_start": str(dates[cut].date()),
        "frozen_on": str(dt.date.today()),
        "note": "Never edit. Lockbox is scored only via 'run.py lockbox'.",
    }
    config.SPLIT_FILE.parent.mkdir(parents=True, exist_ok=True)
    config.SPLIT_FILE.write_text(json.dumps(sp, indent=2))
    return sp


def period_mask(dates, period):
    sp = get_split()
    d = pd.DatetimeIndex(dates)
    if period == "research":
        return np.asarray(d <= pd.Timestamp(sp["research_end"]))
    if period == "lockbox":
        return np.asarray(d >= pd.Timestamp(sp["lockbox_start"]))
    raise ValueError(period)
