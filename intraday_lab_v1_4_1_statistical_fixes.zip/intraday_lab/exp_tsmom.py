"""
intraday_lab / exp_tsmom.py
Experiment 1 — intraday time-series momentum (Li, Sakkas & Urquhart 2022; Gao et al. 2018).

At the close of each k-minute bar j:   S_j = r_j / sqrt(E[r_j^2])
where E[r^2] is the past-only time-of-day expected variance (Andersen & Bollerslev).
Position for the NEXT bar = sign(S_j) if |S_j| > threshold, else flat.
Execution: positions change at the OPEN of bar j+1; the holding return runs open-to-open,
and the last bar of the day closes out at the close of the EOD exit minute.
Consecutive bars in the same direction are held, not re-traded (no double costs).

Declared grid:
  tsmom_index  (NIFTY, futures costs): k {one bar (3 min), 15, 30} x threshold {0,1,2} =  9
  tsmom_stocks (liquid stocks, MIS costs): k {3,15,30} x threshold {0,1,2}
                                           x align {none, index}                       = 18
               + volume conditioning (Li et al.): k {15,30}, threshold 1,
                 relative volume > 1.5                                               =  2
  Volatility-conditioned momentum (both index and stocks): k {15,30} x threshold
                 {1,2} x previous-day volatility regime {low,mid,high}               = 12 per family
  The volatility regime is derived from the previous session's realised variance against
  a trailing 250-session distribution. It is known before today's session starts.
  align=index: trade a stock only when NIFTY's own signal for the same bar agrees.
  NIFTY index has no volume in Kite data, so volume conditioning is stocks-only.

Diagnostics (not trials): every variant also reports results by time of day, liquidity
bucket and the signal bar's relative volume, so conditional effects are visible without
adding variants. If a bucket looks good, declare a NEW variant for it — it gets logged.

Honest prior: with ~8 bp round-trip costs, the one-bar horizon is close to hopeless. It is in the grid so
the ledger records that it was tried.
"""
import itertools
import numpy as np
import config

KS = tuple(sorted({config.SHORT_MINUTES, 15, 30}))   # horizons in minutes: 5,15,30 on 1-min data; 3,15,30 on 3-min
import data
import features
import universe
from engine import VariantAccumulator, tod_label


def variants(family):
    out = []
    aligns = ("none",) if family == "tsmom_index" else ("none", "index")
    for k, th, al in itertools.product(KS, (0.0, 1.0, 2.0), aligns):
        out.append({"name": f"ts_k{k}_th{th:g}_{al}", "k": k, "thr": th,
                    "align": al, "vol": "none", "regime": "all"})
    if family == "tsmom_stocks":
        for k in (15, 30):
            out.append({"name": f"ts_k{k}_th1_none_rv1.5", "k": k, "thr": 1.0,
                        "align": "none", "vol": "rv1.5", "regime": "all"})
    # Declared regime experiments: compare like-for-like 15/30-minute momentum
    # thresholds inside low/normal/high ex-ante daily volatility states.
    # These are separate trials and are all counted in the family-level SPA/DSR.
    for k, th, regime in itertools.product((15, 30), (1.0, 2.0), ("low", "mid", "high")):
        out.append({"name": f"ts_k{k}_th{th:g}_vol_{regime}", "k": k, "thr": th,
                    "align": "none", "vol": "none", "regime": regime})
    return out


# ----------------------------------------------------------------------------- shared helpers
def k_bars(dm, k):
    """k is in MINUTES; must be a whole number of base bars."""
    O, H, L, C, V, starts = dm.resample(data.bars_for(k))
    R = features.bar_returns(O, C)
    ev = features.expected_variance(R)
    return {"O": O, "H": H, "L": L, "C": C, "V": V, "starts": starts, "R": R, "ev": ev,
            "warm": np.isfinite(ev).all(axis=1)}


def hold_returns(dm, starts, eod_min):
    """Open-to-open return of each k-bucket, truncated at the EOD exit minute."""
    allowed = starts <= eod_min
    st = starts[allowed]
    p_start = dm.O[:, st]
    nxt = np.r_[st[1:], 10 ** 6]
    p_end = np.where((nxt <= eod_min)[None, :], dm.O[:, np.minimum(nxt, eod_min)], dm.C[:, [eod_min]])
    return p_end / p_start - 1, int(allowed.sum())


def lag_signal(sig, nb):
    """Position held during bucket j = signal known at the close of bucket j-1."""
    p = np.zeros((sig.shape[0], nb))
    p[:, 1:] = sig[:, :nb - 1]
    return p


def score(p, h):
    """Daily gross return, round trips per day, plus per-bucket gross and trades for diagnostics."""
    contrib = p * h
    pz = np.c_[np.zeros(len(p)), p, np.zeros(len(p))]
    turn = np.abs(np.diff(pz, axis=1))              # (D, nb+1): entries/changes at j, close-out at nb
    trades_cols = turn[:, :-1] / 2.0
    trades_cols[:, -1] += turn[:, -1] / 2.0
    return contrib.sum(axis=1), trades_cols.sum(axis=1), contrib, trades_cols


def relvol_label(rel):
    return np.where(~np.isfinite(rel), "na", np.where(rel < 1, "1 <1x", np.where(rel < 2, "2 1-2x", "3 >2x"))).astype(object)


def add_diagnostics(acc, contrib, trades_cols, starts_nb, active, liq_lab=None, rel_signal=None):
    acc.add_buckets("time_of_day", np.broadcast_to(tod_label(starts_nb)[None, :], contrib.shape), contrib, trades_cols, active)
    if liq_lab is not None:
        acc.add_buckets("liquidity", liq_lab, contrib.sum(axis=1), trades_cols.sum(axis=1), active)
    if rel_signal is not None:
        acc.add_buckets("signal_relvol", relvol_label(rel_signal), contrib, trades_cols, active)


# ----------------------------------------------------------------------------- run
def run(family, period="research", symbols=None, only=None, progress=True):
    vs = [v for v in variants(family) if not only or v["name"] in only]
    instrument = "index_fut" if family == "tsmom_index" else "equity_intraday"
    eod_min = data.minute_of(config.EOD_EXIT_FUTURES if instrument == "index_fut" else config.EOD_EXIT_EQUITY)
    accs = {v["name"]: VariantAccumulator(instrument) for v in vs}
    idx_dm, _ = data.load_matrix(config.INDEX_SYMBOL)
    idx_S = {}
    for k in KS:
        b = k_bars(idx_dm, k)
        with np.errstate(invalid="ignore", divide="ignore"):
            idx_S[k] = b["R"] / np.sqrt(b["ev"])
    is_index = family == "tsmom_index"
    syms = [config.INDEX_SYMBOL] if is_index else (symbols or universe.stock_symbols())
    for i, sym in enumerate(syms):
        try:
            dm = idx_dm if sym == config.INDEX_SYMBOL else data.load_matrix(sym)[0]
        except Exception as ex:
            print(f"  skip {sym}: {ex}")
            continue
        if progress:
            print(f"  [{i+1}/{len(syms)}] {sym}")
        pmask = data.period_mask(dm.dates, period)
        liq = np.ones(len(dm.dates), bool) if is_index else universe.liquid_mask(dm)
        liq_lab = None if is_index else universe.liquidity_label(dm)
        # Ex-ante state based only on the previous session and an expanding history
        # of past daily realised variance. Never uses today's intraday outcomes.
        exante_regime = features.ex_ante_vol_regime(dm).to_numpy()
        regime_code = {"low": 0.0, "mid": 1.0, "high": 2.0}
        regime_labels = np.where(np.isnan(exante_regime), "unknown",
                                 np.where(exante_regime == 0, "low",
                                          np.where(exante_regime == 1, "mid", "high")))
        ix = idx_dm.dates.get_indexer(dm.dates)
        for k in KS:
            kvs = [v for v in vs if v["k"] == k]
            if not kvs:
                continue
            b = k_bars(dm, k)
            with np.errstate(invalid="ignore", divide="ignore"):
                S = b["R"] / np.sqrt(b["ev"])
            h, nb = hold_returns(dm, b["starts"], eod_min)
            active = pmask & b["warm"] & liq
            rel = None
            rel_sig_nb = None
            if not is_index:
                rel = features.relative_volume(b["V"])
                rel_sig_nb = np.full((len(dm.dates), nb), np.nan)
                rel_sig_nb[:, 1:] = rel[:, :nb - 1]
            for v in kvs:
                Sn = np.nan_to_num(S)
                sig = np.where(np.abs(Sn) > v["thr"], np.sign(Sn), 0.0)
                if v["vol"] == "rv1.5":
                    sig = np.where(np.nan_to_num(rel) > 1.5, sig, 0.0)
                regime_filter = v.get("regime", "all")
                if regime_filter != "all":
                    sig = np.where(exante_regime[:, None] == regime_code[regime_filter], sig, 0.0)
                if v["align"] == "index":
                    Si = np.zeros_like(S)
                    ok = ix >= 0
                    Si[ok] = np.nan_to_num(idx_S[k][ix[ok]])
                    sig = np.where(np.sign(Si) == sig, sig, 0.0)
                p = lag_signal(sig, nb)
                gross, rt, contrib, tcols = score(p, h)
                acc = accs[v["name"]]
                acc.add(dm.dates, gross, rt, active)
                add_diagnostics(acc, contrib, tcols, b["starts"][:nb], active, liq_lab, rel_sig_nb)
                acc.add_buckets("ex_ante_vol_regime", regime_labels, gross, rt, active)
    return {v["name"]: (v, accs[v["name"]].finalize()) for v in vs}
