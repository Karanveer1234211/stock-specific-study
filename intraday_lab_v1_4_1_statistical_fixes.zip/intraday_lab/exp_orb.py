"""
intraday_lab / exp_orb.py
Experiment 2 — opening-range breakout on liquid NSE stocks (Holmberg, Lönnbark & Lundström 2013),
with the time-of-day volatility band from Andersen & Bollerslev 1997 as a declared alternative trigger.

One trade per stock per day: the FIRST breakout of the day in either direction.
Long and short are scored as separate variants (a "long" variant takes the day's first
breakout only if it is upward).

Declared grid (every cell is logged as a trial; nothing is added after looking):
  Baseline: range m in {5 (3 on 3-min data), 15, 30 min} x confirm {bar close, 15-min close}
            x exit {eod, 60 min} x stop {none, opposite side of range} x direction {long, short}
            = 48 variants
  A1 opening-price volatility band: price closes beyond open * (1 +/- k * expected open-to-close sd),
            k in {0.5, 1.0} x direction, exit eod, no stop = 4 variants
  A2 time-of-day-normalised breakout: close beyond the 15-minute opening range by
            k * expected volatility for THAT signal bar, k in {0.5, 1.0} x direction,
            opposite side of range used as stop = 4 variants
  Filters, one at a time, on the primary spec (m=15, bar close, eod, range stop) x direction:
            hi_open_vol — opening-range realised variance above its time-of-day expectation
            narrow      — range width / expected range below its trailing median (Crabel contraction)
            relvol      — opening-range volume above its trailing median (same minutes)
            mkt         — NIFTY return from 09:15 to the signal bar agrees with the trade
            = 8 variants
  Total 64.

Timing: signal on the close of bar j, entry at the OPEN of the next bar,
entries no later than ENTRY_CUTOFF, exit at the close of EOD_EXIT_EQUITY (or 60 min).
Stop fill: first bar whose low (long) / high (short) touches the stop, filled at the
worse of the stop and that bar's open (gaps through stops are charged in full).
"""
import itertools
import numpy as np
import pandas as pd
import config
import data
import features
import universe
from engine import VariantAccumulator, tod_label

FAMILY = "orb_stocks"
INSTRUMENT = "equity_intraday"
PRIMARY = {"m": 15, "confirm": "bar", "exit": "eod", "stop": "range"}


def _bars(x):
    """'bar' -> 1 base bar; minutes -> number of base bars."""
    return 1 if x == "bar" else data.bars_for(int(x))


def variants():
    v = []
    for m, c, ex, st, d in itertools.product((config.SHORT_MINUTES, 15, 30), ("bar", 15), ("eod", 60), ("none", "range"), ("long", "short")):
        v.append({"name": f"orb_m{m}_c{c}_{ex}_{st}_{d}", "trigger": "range", "m": m, "confirm": c,
                  "exit": ex, "stop": st, "dir": d, "filter": None})
    for k, d in itertools.product((0.5, 1.0), ("long", "short")):
        v.append({"name": f"orb_volband_k{k}_{d}", "trigger": "volband", "k": k, "m": 0, "confirm": "bar",
                  "exit": "eod", "stop": "none", "dir": d, "filter": None})
    for k, d in itertools.product((0.5, 1.0), ("long", "short")):
        v.append({"name": f"orb_todband_m15_k{k:g}_{d}", "trigger": "todband", "k": k,
                  "m": 15, "confirm": "bar", "exit": "eod", "stop": "range",
                  "dir": d, "filter": None})
    for f, d in itertools.product(("hi_open_vol", "narrow", "relvol", "mkt"), ("long", "short")):
        v.append({"name": f"orb_m15_cbar_eod_range_{d}_F{f}", "trigger": "range", **PRIMARY, "dir": d, "filter": f})
    return v


def baseline_of(v):
    """Name of the unfiltered variant a filter is compared against."""
    if not v.get("filter"):
        return None
    return f"orb_m15_cbar_eod_range_{v['dir']}"


def _first_true(mask):
    has = mask.any(axis=1)
    idx = np.where(has, mask.argmax(axis=1), -1)
    return idx


def _breakout(dm, v, ev1, cutoff):
    D, M = dm.C.shape
    cols = np.arange(M)[None, :]
    if v["trigger"] == "range":
        m = _bars(v["m"])
        rh = dm.H[:, :m].max(axis=1)
        rl = dm.L[:, :m].min(axis=1)
        if v["confirm"] == "bar":
            closes = dm.C
            eligible = (cols >= m) & (cols + 1 <= cutoff)
            sig_cols = np.broadcast_to(cols, closes.shape)
        else:   # closes of k-bar blocks (e.g. 15-minute closes) that start at/after the range end
            k = _bars(v["confirm"])
            ends = np.arange(k - 1, M, k)
            closes = dm.C[:, ends]
            sig_cols = np.broadcast_to(ends[None, :], closes.shape)
            eligible = (sig_cols - (k - 1) >= m) & (sig_cols + 1 <= cutoff)
        up = (closes > rh[:, None]) & eligible
        dn = (closes < rl[:, None]) & eligible
        stop_long, stop_short = rl, rh
    elif v["trigger"] == "volband":       # volatility band around the open, A&B-scaled
        sd = np.sqrt(np.nansum(ev1, axis=1))
        sd[~np.isfinite(ev1).all(axis=1)] = np.nan
        o = dm.O[:, 0]
        hi = o * (1 + v["k"] * sd)
        lo = o * (1 - v["k"] * sd)
        closes = dm.C
        sig_cols = np.broadcast_to(cols, closes.shape)
        eligible = (cols + 1 <= cutoff)
        up = (closes > hi[:, None]) & eligible
        dn = (closes < lo[:, None]) & eligible
        stop_long = stop_short = np.full(D, np.nan)
        rh = rl = np.full(D, np.nan)
    else:       # A&B time-of-day-normalised buffer beyond the opening range
        m = _bars(v["m"])
        rh = dm.H[:, :m].max(axis=1)
        rl = dm.L[:, :m].min(axis=1)
        # ev1 is an ex-ante, past-only variance estimate for each intraday time slot.
        # Since signals are computed at bar close and executed next bar open, using ev1[:, j]
        # for threshold j does not use any future information.
        sigma = np.sqrt(np.maximum(ev1, 0.0))
        hi = rh[:, None] * np.exp(v["k"] * sigma)
        lo = rl[:, None] * np.exp(-v["k"] * sigma)
        closes = dm.C
        sig_cols = np.broadcast_to(cols, closes.shape)
        eligible = (cols >= m) & (cols + 1 <= cutoff)
        up = (closes > hi) & eligible
        dn = (closes < lo) & eligible
        stop_long, stop_short = rl, rh
    any_ = up | dn
    first = _first_true(any_)
    rows = np.arange(D)
    side = np.zeros(D)
    ok = first >= 0
    side[ok] = np.where(up[rows[ok], first[ok]], 1.0, -1.0)
    sig_bar = np.full(D, -1)
    sig_bar[ok] = sig_cols[rows[ok], first[ok]]
    return side, sig_bar, stop_long, stop_short, rh, rl


def _simulate(dm, side, sig_bar, stop_px, exit_rule, eod_idx):
    D, M = dm.C.shape
    entry_idx = np.where(sig_bar >= 0, sig_bar + 1, -1)
    traded = entry_idx >= 0
    e = np.clip(entry_idx, 0, M - 1)
    rows = np.arange(D)
    entry_px = dm.O[rows, e]
    if exit_rule == "eod":
        x_idx = np.full(D, eod_idx)
    else:
        x_idx = np.minimum(e + data.bars_for(int(exit_rule)) - 1, eod_idx)
    traded &= x_idx >= e
    exit_px = dm.C[rows, x_idx]
    if stop_px is not None and np.isfinite(stop_px).any():
        cols = np.arange(M)[None, :]
        window = (cols >= e[:, None]) & (cols <= x_idx[:, None]) & traded[:, None]
        sp = stop_px[:, None]
        hit_long = (dm.L <= sp) & window & (side[:, None] > 0)
        hit_short = (dm.H >= sp) & window & (side[:, None] < 0)
        hit = hit_long | hit_short
        h_idx = _first_true(hit)
        has = (h_idx >= 0) & np.isfinite(stop_px)
        hi = np.clip(h_idx, 0, M - 1)
        o_at = dm.O[rows, hi]
        fill = np.where(side > 0, np.minimum(o_at, stop_px), np.maximum(o_at, stop_px))
        exit_px = np.where(has, fill, exit_px)
    gross = np.where(traded, side * (exit_px / entry_px - 1), 0.0)
    return gross, traded


def run(period="research", symbols=None, only=None, progress=True):
    vs = [v for v in variants() if not only or v["name"] in only]
    accs = {v["name"]: VariantAccumulator(INSTRUMENT) for v in vs}
    idx_dm, _ = data.load_matrix(config.INDEX_SYMBOL)
    idx_ret = idx_dm.C / idx_dm.O[:, [0]] - 1          # NIFTY return 09:15 open -> close of bar j
    symbols = symbols or universe.stock_symbols()
    cutoff = data.minute_of(config.ENTRY_CUTOFF)
    eod_idx = data.minute_of(config.EOD_EXIT_EQUITY)
    for i, sym in enumerate(symbols):
        try:
            dm, rep = data.load_matrix(sym)
        except Exception as ex:
            print(f"  skip {sym}: {ex}")
            continue
        if progress:
            print(f"  [{i+1}/{len(symbols)}] {sym}: {rep['days']} days")
        R1 = features.bar_returns(dm.O, dm.C)
        ev1 = features.expected_variance(R1)
        warm = np.isfinite(ev1).all(axis=1)
        active = data.period_mask(dm.dates, period) & warm & universe.liquid_mask(dm)
        # filter inputs (past-only)
        m = _bars(PRIMARY["m"])
        or_rv = (R1[:, :m] ** 2).sum(axis=1)
        or_ev = ev1[:, :m].sum(axis=1)
        hi_open_vol = or_rv > or_ev
        width = (dm.H[:, :m].max(axis=1) - dm.L[:, :m].min(axis=1)) / dm.O[:, 0] / np.sqrt(or_ev)
        width_med = pd.Series(width).shift(1).rolling(250, min_periods=60).median().values
        narrow = width < width_med
        orv = dm.V[:, :m].sum(axis=1)
        orv_med = pd.Series(orv).shift(1).rolling(60, min_periods=30).median().values
        relvol = orv > orv_med
        ix = idx_dm.dates.get_indexer(dm.dates)
        liq_lab = universe.liquidity_label(dm)
        cache = {}
        for v in vs:
            key = (v["trigger"], v["m"], v["confirm"], v.get("k"))
            if key not in cache:
                cache[key] = _breakout(dm, v, ev1, cutoff)
            side, sig_bar, sl, ss, rh, rl = cache[key]
            want = 1.0 if v["dir"] == "long" else -1.0
            take = side == want
            f = v.get("filter")
            if f == "hi_open_vol":
                take &= hi_open_vol
            elif f == "narrow":
                take &= narrow
            elif f == "relvol":
                take &= relvol
            elif f == "mkt":
                sb = np.clip(sig_bar, 0, config.BARS_PER_DAY - 1)
                mret = np.where(ix >= 0, idx_ret[np.clip(ix, 0, None), sb], np.nan)
                take &= np.sign(np.nan_to_num(mret)) == want
            sb = np.where(take, sig_bar, -1)
            stop_px = (sl if want > 0 else ss) if v["stop"] == "range" else None
            gross, traded = _simulate(dm, np.where(take, side, 0.0), sb, stop_px, v["exit"], eod_idx)
            acc = accs[v["name"]]
            acc.add(dm.dates, gross, traded.astype(int), active)
            acc.add_buckets("time_of_day", tod_label(np.clip(sb + 1, 0, config.BARS_PER_DAY - 1)), gross, traded, active)
            acc.add_buckets("liquidity", liq_lab, gross, traded, active)
    return {v["name"]: (v, accs[v["name"]].finalize()) for v in vs}
