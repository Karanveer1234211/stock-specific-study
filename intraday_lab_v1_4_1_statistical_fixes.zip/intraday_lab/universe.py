"""
intraday_lab / universe.py
Which symbols exist, and which are tradable on each day (point-in-time liquidity).

Survivorship warning: Kite only serves instruments that still exist, so a list of
today's symbols misses stocks that were delisted or merged. Results on stocks are
therefore biased upward somewhat. The index families do not have this problem.
"""
import numpy as np
import pandas as pd
import config

INDEX_FILES = {config.INDEX_SYMBOL, config.BANK_INDEX_SYMBOL, "NIFTY50", "NIFTY BANK", "BANKNIFTY", "INDIA VIX"}


def coverage_table():
    """Per symbol: trading days in its file vs index trading days between its first and last day."""
    import data
    idx = pd.read_parquet(data.sym_file(config.INDEX_SYMBOL), columns=None)
    idx_days = _days(idx)
    rows = []
    for sym in data.list_symbols():
        try:
            try:
                raw = pd.read_parquet(data.sym_file(sym), columns=["timestamp"])
            except Exception:
                raw = pd.read_parquet(data.sym_file(sym))
            d = _days(raw)
        except Exception as ex:
            rows.append({"symbol": sym, "error": str(ex)})
            continue
        if not len(d):
            rows.append({"symbol": sym, "days": 0, "coverage": 0.0})
            continue
        span = idx_days[(idx_days >= d.min()) & (idx_days <= d.max())]
        rows.append({"symbol": sym, "first": d.min().date(), "last": d.max().date(), "days": len(d),
                     "index_days_in_span": len(span),
                     "coverage": len(d.intersection(span)) / max(len(span), 1)})
    return pd.DataFrame(rows)


def _days(df):
    ts = pd.Series(pd.to_datetime(df["timestamp"] if "timestamp" in df.columns else df.index))
    if ts.dt.tz is not None:
        ts = ts.dt.tz_convert("Asia/Kolkata").dt.tz_localize(None)
    return pd.DatetimeIndex(ts.dt.normalize().unique()).sort_values()


_STOCKS = None


def stock_symbols():
    """Stocks with continuous history (coverage >= MIN_COVERAGE). Pick-window-only files are left out."""
    global _STOCKS
    if _STOCKS is None:
        t = coverage_table()
        t = t[~t["symbol"].isin(INDEX_FILES)]
        ok = t[t.get("coverage", 0) >= config.MIN_COVERAGE]
        skipped = len(t) - len(ok)
        if skipped:
            print(f"  universe: {len(ok)} stocks with >= {config.MIN_COVERAGE:.0%} day coverage; "
                  f"{skipped} left out (pick-window or gappy files) - see 'python run.py coverage'")
        _STOCKS = ok["symbol"].tolist()
        if not _STOCKS:
            raise SystemExit("No stock has continuous history in the 3-minute cache. Fill it first - see README "
                             "('Filling the 3-minute cache'). The NIFTY families still run.")
    return _STOCKS


def trailing_turnover_cr(dm):
    """Median daily turnover (Rs crore) over the previous LIQ_LOOKBACK days (past only)."""
    turnover = pd.Series((dm.C * dm.V).sum(axis=1), index=dm.dates)
    med = turnover.rolling(config.LIQ_LOOKBACK, min_periods=config.LIQ_LOOKBACK // 2).median().shift(1)
    return med.to_numpy() / 1e7


def liquid_mask(dm):
    """True on day t if the trailing median daily turnover >= LIQ_FLOOR_CR."""
    return np.nan_to_num(trailing_turnover_cr(dm)) >= config.LIQ_FLOOR_CR


def liquidity_label(dm):
    """Per-day liquidity bucket from trailing turnover (declared edges in config.LIQ_BUCKETS_CR)."""
    t = np.nan_to_num(trailing_turnover_cr(dm))
    lo, hi = config.LIQ_BUCKETS_CR
    return np.where(t < lo, f"1 <{lo:g}cr", np.where(t < hi, f"2 {lo:g}-{hi:g}cr", f"3 >{hi:g}cr")).astype(object)
