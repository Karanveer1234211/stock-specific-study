#!/usr/bin/env python3
"""
engine_stage_c.py - Stage C1 of the 10-stock behavioural engine: the cost check (STAGE_C_DECLARATION.json).

    python engine_stage_c.py --root %CACHE_DAILY_ROOT%                      (stocks from engine_stocks.txt)
    python engine_stage_c.py --root %CACHE_DAILY_ROOT% --stocks my10.txt

The question, in plain words: Stage B found that three state representations (grid12, gmm4, hmm4) know a little about
which way a stock goes next. Is that ever enough to pay for a trade? For every decision point we turn the state into an
expected move in bp for the next hour (H60) and to 15:03 (EOD), shrink it by how much such predictions actually came
true on EARLIER test windows (calibration), and take one trade per stock and session at the first point where the
expected move is at least the 12.49 bp a trade costs. Those trades are then priced on the test windows of folds 2-5
(2023-04 .. 2024-12), which neither the state models nor the calibration saw. Nothing after 2024-12-31 is read.

Writes only <root>\\research2\\engine\\C_<date>_<n>\\, appends 6 lines to <root>\\research2\\engine\\experiments.jsonl
and one line to <root>\\panel\\research_ledger.jsonl.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import platform
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import engine_core as E                  # noqa: E402
import engine_models as EM               # noqa: E402
import engine_stage_b as SB              # noqa: E402

BM = E.BM
CODE_VERSION = "engine_stage_c v1.0"
CFG = E.CFG
CDECL_RAW = (HERE / "STAGE_C_DECLARATION.json").read_bytes()
CDECL = json.loads(CDECL_RAW.decode("utf-8"))
CCFG = CDECL["config"]
CDECL_SHA = hashlib.sha256(CDECL_RAW).hexdigest()[:16]
REPS = list(CCFG["representations"])
HORIZONS = dict(CCFG["horizons"])                     # name -> outcome column
TARGETS = ["y_up"] + list(HORIZONS.values())
COST = float(CCFG["cost_bps"])
_log = SB._log


def check_declarations() -> None:
    if CDECL["requires"]["engine_declaration"] != E.DECL_SHA:
        raise E.PreconditionError(f"STAGE_C_DECLARATION requires engine declaration {CDECL['requires']['engine_declaration']}, "
                                  f"found {E.DECL_SHA}: use the ENGINE_DECLARATION.json Stage B ran under")
    if abs(COST - E.TRADE_COST_BPS) > 0.01:
        raise E.PreconditionError(f"Stage C cost {COST} bp differs from the engine's {E.TRADE_COST_BPS:.3f} bp")
    bad = [r for r in REPS if r not in CFG["representations"] or r.startswith("knn")]
    if bad:
        raise E.PreconditionError(f"Stage C representations not available as states: {bad}")


# ----------------------------------------------------------------------
# Stage B must have passed for these representations on this stock list
# ----------------------------------------------------------------------
def find_stage_b(root: Path, stocks_hash: str) -> dict:
    base = root / "research2" / "engine"
    seen = []
    for f in sorted(base.glob("B_*/summary.json")):
        try:
            s = json.loads(f.read_text(encoding="utf-8"))
        except Exception:
            continue
        if s.get("declaration") != E.DECL_SHA or s.get("stocks_hash") != stocks_hash or s.get("rerun_of"):
            continue
        seen.append(f.parent.name)
        R = {r["rep"]: r for r in s.get("representations", [])}
        ok = [r for r in REPS if r in R and R[r].get("informative") and R[r].get("stable")]
        if s.get("verdict") == "STATES INFORMATIVE" and ok == REPS:
            return {"run": f.parent.name, "verdict": s["verdict"], "preferred": s.get("preferred"),
                    "survivors": [r for r, v in R.items() if v.get("informative") and v.get("stable")]}
        raise E.PreconditionError(f"Stage B run {f.parent.name} on this stock list is '{s.get('verdict')}' with informative and "
                                  f"stable {[r for r, v in R.items() if v.get('informative') and v.get('stable')]}; Stage C is "
                                  f"declared for {REPS} after STATES INFORMATIVE - it does not apply")
    raise E.PreconditionError(f"no fresh Stage B run under declaration {E.DECL_SHA} for this stock list in {base} "
                              f"(found: {seen or 'none'}) - run engine_stage_b.py first")


# ----------------------------------------------------------------------
# out-of-sample state predictions per fold (the same states and tables as Stage B, plus y_eod)
# ----------------------------------------------------------------------
def baseline(tr: pd.DataFrame, te: pd.DataFrame, targets: List[str]) -> Tuple[np.ndarray, np.ndarray]:
    """R0 as in Stage B: the training mean per stock and time-of-day bucket (then the stock's mean, then everyone's)."""
    out = []
    for D in (tr, te):
        B = np.empty((len(D), len(targets)))
        for j, t in enumerate(targets):
            cell = tr.groupby(["sym", "tod"])[t].mean()
            st = tr.groupby("sym")[t].mean()
            v = pd.MultiIndex.from_arrays([D["sym"], D["tod"]])
            x = cell.reindex(v).to_numpy(float)
            x = np.where(np.isfinite(x), x, st.reindex(D["sym"]).to_numpy(float))
            B[:, j] = np.where(np.isfinite(x), x, float(tr[t].mean()))
        out.append(B)
    return out[0], out[1]


def fold_predictions(obs: pd.DataFrame, f: int, fold: list, log=_log) -> pd.DataFrame:
    a, b, c, d = (pd.Timestamp(x) for x in fold)
    tr = obs[(obs["day"] >= a) & (obs["day"] <= b)].reset_index(drop=True)
    te = obs[(obs["day"] >= c) & (obs["day"] <= d)].reset_index(drop=True)
    if not len(tr) or not len(te):
        return pd.DataFrame()
    n_sym = int(obs["sym"].max()) + 1
    lam = float(CFG["shrink_lambda"])
    b_tr, b_te = baseline(tr, te, TARGETS)
    Dtr = tr[TARGETS].to_numpy(float) - b_tr
    prep = EM.Prep(float(CFG["clip_z"]), float(CFG["pca_var"]), int(CFG["pca_min"]), int(CFG["pca_max"])).fit(tr[E.FEATURES].to_numpy(float))
    Ztr, Zte = prep.transform(tr[E.FEATURES].to_numpy(float)), prep.transform(te[E.FEATURES].to_numpy(float))
    out = pd.DataFrame({"fold": f, "day": te["day"].to_numpy(), "sym": te["sym"].to_numpy(), "k": te["k"].to_numpy(),
                        "atr": te["atr"].to_numpy(float)})
    for j, t in enumerate(TARGETS):
        out[t] = te[t].to_numpy(float)
        out["R0_" + t] = b_te[:, j]
    seed = int(CFG["seed"])
    for rep in REPS:
        t0 = time.time()
        m = SB.Rep(rep, prep, seed).fit(tr, Ztr)
        P_tr, P_te = m.proba(tr, Ztr), m.proba(te, Zte)
        tab, _, _ = SB.state_tables(P_tr, Dtr, tr["sym"].to_numpy(), n_sym, lam)
        D = np.einsum("nk,nkt->nt", P_te, tab[te["sym"].to_numpy()])
        for j, t in enumerate(TARGETS):
            out[f"{rep}_D_{t}"] = np.nan_to_num(D[:, j])
        if m.m is not None:
            nv_tr, nv_te = m.novelty(Ztr), m.novelty(Zte)
            out[rep + "_novel"] = nv_te > np.percentile(nv_tr, 100 - float(CFG["novelty_pct"]))
        log(f"    fold {f + 1} {rep}: fit {time.time() - t0:.1f} s")
    return out


# ----------------------------------------------------------------------
# calibration on earlier folds only, expected moves in bp, the trade rule
# ----------------------------------------------------------------------
def fit_slopes(y: np.ndarray, X: np.ndarray) -> np.ndarray:
    """Least squares without intercept of y on the columns of X, each slope clipped to the declared range."""
    y, X = np.asarray(y, float), np.asarray(X, float).reshape(len(y), -1)
    m = np.isfinite(y) & np.isfinite(X).all(1)
    if m.sum() < X.shape[1] * 10 or not np.any(X[m]):
        return np.zeros(X.shape[1])
    coef = np.linalg.lstsq(X[m], y[m], rcond=None)[0]
    return np.clip(np.nan_to_num(coef), float(CCFG["slope_min"]), float(CCFG["slope_max"]))


def calibrate(P: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame]:
    """Adds G_<rep>_<h> (calibrated expected long move, bp), Graw_<rep>_<h> (a = c = 1) and pcal_<rep> (calibrated barrier
    probability) to every row of a fold >= eval_from_fold, using slopes fitted on the earlier folds' rows only."""
    P = P.copy()
    first = int(CCFG["eval_from_fold"]) - 1
    folds = sorted(P["fold"].unique())
    rows = []
    bp = P["atr"].to_numpy(float) * 1e4
    for rep in REPS:
        for h, t in HORIZONS.items():
            P[f"Graw_{rep}_{h}"] = (P["R0_" + t].to_numpy(float) + P[f"{rep}_D_{t}"].to_numpy(float)) * bp
            P[f"G_{rep}_{h}"] = np.nan
        P[f"pcal_{rep}"] = np.nan
    for j in folds:
        if j < first:
            continue
        prior, cur = (P["fold"] < j).to_numpy(), (P["fold"] == j).to_numpy()
        for rep in REPS:
            for h, t in HORIZONS.items():
                a, c = fit_slopes(P.loc[prior, t], P.loc[prior, ["R0_" + t, f"{rep}_D_{t}"]].to_numpy(float))
                G = (a * P.loc[cur, "R0_" + t].to_numpy(float) + c * P.loc[cur, f"{rep}_D_{t}"].to_numpy(float)) * bp[cur]
                P.loc[cur, f"G_{rep}_{h}"] = G
                rows.append({"fold": int(j) + 1, "rep": rep, "target": h, "a_R0": float(a), "c_state": float(c),
                             "fitted_on_rows": int(prior.sum())})
            yu, r0u, du = (P.loc[prior, x].to_numpy(float) for x in ("y_up", "R0_y_up", f"{rep}_D_y_up"))
            cu = fit_slopes(yu - r0u, du)[0]
            P.loc[cur, f"pcal_{rep}"] = np.clip(P.loc[cur, "R0_y_up"].to_numpy(float) + cu * P.loc[cur, f"{rep}_D_y_up"].to_numpy(float),
                                                0.01, 0.99)
            rows.append({"fold": int(j) + 1, "rep": rep, "target": "barrier", "a_R0": 1.0, "c_state": float(cu),
                         "fitted_on_rows": int(prior.sum())})
    return P, pd.DataFrame(rows)


def take_trades(Ev: pd.DataFrame, rep: str, h: str) -> pd.DataFrame:
    """One trade per stock and session at the first decision point with |G| >= the cost; side = sign(G)."""
    t = HORIZONS[h]
    G = Ev[f"G_{rep}_{h}"].to_numpy(float)
    y = Ev[t].to_numpy(float)
    q = np.isfinite(G) & (np.abs(G) >= COST) & np.isfinite(y) & np.isfinite(Ev["atr"].to_numpy(float))
    S = Ev.loc[q, ["fold", "day", "sym", "k", "atr", t]].assign(G=G[q])
    nv = rep + "_novel"
    if nv in Ev.columns:
        S["novel"] = Ev.loc[q, nv].to_numpy(bool)
    S = S.sort_values(["day", "sym", "k"], kind="stable").drop_duplicates(["day", "sym"], keep="first")
    S["side"] = np.sign(S["G"]).astype(int)
    S["gross_bp"] = S["side"] * S[t] * S["atr"] * 1e4
    S["net_bp"] = S["gross_bp"] - COST
    S.insert(0, "horizon", h)
    S.insert(0, "rep", rep)
    return S.rename(columns={t: "y"}).reset_index(drop=True)


def mean_stats(days: np.ndarray, T: pd.DataFrame, col: str, idx: np.ndarray) -> Tuple[float, float, float, float]:
    """Mean per trade of `col`, its 95% session-block-bootstrap interval and one-sided p (mean <= 0)."""
    nd = len(days)
    di = np.searchsorted(days, T["day"].to_numpy())
    S = np.bincount(di, weights=T[col].to_numpy(float), minlength=nd)
    N = np.bincount(di, minlength=nd).astype(float)
    if N.sum() == 0:
        return np.nan, np.nan, np.nan, np.nan
    m = S.sum() / N.sum()
    with np.errstate(invalid="ignore", divide="ignore"):
        bs = S[idx].sum(1) / N[idx].sum(1)
    bs = bs[np.isfinite(bs)]
    lo, hi = np.percentile(bs, [2.5, 97.5]) if len(bs) else (np.nan, np.nan)
    return float(m), float(lo), float(hi), SB._p_one_sided(float(m), bs)


def evaluate(P: pd.DataFrame) -> Tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict]:
    """The 6 tests, the trades, the deciles and the reported-only numbers on the folds after the first."""
    Ev = P[P["fold"] >= int(CCFG["eval_from_fold"]) - 1].reset_index(drop=True)
    days = np.sort(Ev["day"].unique())
    idx = SB._boot_idx(len(days))
    tests, trades, dec = [], [], []
    stress = float(CCFG["cost_stress"])
    for rep in REPS:
        for h, t in HORIZONS.items():
            T = take_trades(Ev, rep, h)
            T["net_stress_bp"] = T["gross_bp"] - stress * COST
            trades.append(T)
            r = {"rep": rep, "horizon": h, "trades": int(len(T)), "stock_sessions": int(Ev.groupby(["day", "sym"]).ngroups),
                 "mean_abs_G": float(T["G"].abs().mean()) if len(T) else np.nan}
            for col, nm in (("gross_bp", "gross"), ("net_bp", "net"), ("net_stress_bp", "net_stress")):
                m, lo, hi, p = mean_stats(days, T, col, idx) if len(T) else (np.nan,) * 4
                r.update({nm: m, nm + "_lo": lo, nm + "_hi": hi, nm + "_p": p})
            r["hit_rate"] = float((T["gross_bp"] > 0).mean()) if len(T) else np.nan
            G, Gr = Ev[f"G_{rep}_{h}"].abs().to_numpy(float), Ev[f"Graw_{rep}_{h}"].abs().to_numpy(float)
            r.update({"share_G_ge_cost": float(np.nanmean(G >= COST)), "median_G": float(np.nanmedian(G)),
                      "p99_G": float(np.nanpercentile(G, 99)), "max_G": float(np.nanmax(G)),
                      "share_Graw_ge_cost": float(np.nanmean(Gr >= COST)), "median_Graw": float(np.nanmedian(Gr)),
                      "p99_Graw": float(np.nanpercentile(Gr, 99)), "max_Graw": float(np.nanmax(Gr))})
            if "novel" in T.columns and len(T):
                r["novel_trades"] = int(T["novel"].sum())
                r["novel_net"] = float(T.loc[T["novel"], "net_bp"].mean()) if T["novel"].any() else np.nan
                r["other_net"] = float(T.loc[~T["novel"], "net_bp"].mean()) if (~T["novel"]).any() else np.nan
            tests.append(r)
            # realised gross going with G's sign, by decile of |G|
            fin = np.isfinite(G) & np.isfinite(Ev[t].to_numpy(float))
            if fin.sum() >= int(CCFG["deciles"]):
                rk = pd.Series(G[fin]).rank(method="first").to_numpy()
                q = np.minimum((rk - 1) * int(CCFG["deciles"]) // fin.sum(), int(CCFG["deciles"]) - 1).astype(int)
                sg = np.sign(Ev[f"G_{rep}_{h}"].to_numpy(float)[fin])
                g = sg * Ev[t].to_numpy(float)[fin] * Ev["atr"].to_numpy(float)[fin] * 1e4
                for k in range(int(CCFG["deciles"])):
                    s = q == k
                    dec.append({"rep": rep, "horizon": h, "decile": k + 1, "n": int(s.sum()), "mean_abs_G": float(G[fin][s].mean()),
                                "realised_gross_with_sign": float(g[s].mean())})
    R = pd.DataFrame(tests)
    ph = SB.holm(np.where(R["trades"] >= int(CCFG["min_trades"]), R["net_p"].to_numpy(float), np.nan))
    R["net_p_holm"] = ph
    R["pass"] = (R["trades"] >= int(CCFG["min_trades"])) & (R["net_lo"] > 0) & (R["net_p_holm"] <= float(CFG["alpha"]))
    R["survives_stress"] = R["pass"] & (R["net_stress_lo"] > 0)
    # reported only: the calibrated barrier probability vs R0
    extra = {"eval_days": int(len(days)), "eval_rows": int(len(Ev)), "eval_period": [str(pd.Timestamp(days[0]).date()), str(pd.Timestamp(days[-1]).date())] if len(days) else None}
    yu = Ev["y_up"].to_numpy(float)
    res = np.isfinite(yu)
    di = np.searchsorted(days, Ev["day"].to_numpy())
    e0 = np.bincount(di[res], weights=(yu[res] - Ev["R0_y_up"].to_numpy(float)[res]) ** 2, minlength=len(days))
    for rep in REPS:
        pc = Ev[f"pcal_{rep}"].to_numpy(float)
        e1 = np.bincount(di[res], weights=(yu[res] - pc[res]) ** 2, minlength=len(days))
        sk, lo, hi, p, _ = SB.skill_stats(e1, e0, idx)
        extra[f"brier_cal_{rep}"] = {"skill": sk, "lo": lo, "hi": hi, "p": p}
    TR = pd.concat(trades, ignore_index=True) if trades else pd.DataFrame()
    return R, TR, pd.DataFrame(dec), extra


# ----------------------------------------------------------------------
# report
# ----------------------------------------------------------------------
_f, _u, _ci = SB._f, SB._u, SB._ci

VERDICT_TEXT = {
    "COST CLEARED": "At least one state representation, calibrated only on earlier data, picks trades that earn more than the "
                    "12.49 bp they cost on test windows it never saw. This earns the rest of Stage C (the evidence store) and "
                    "then Stage D for the passing representation and exit only, each with its own frozen rules first. It is "
                    "NOT a strategy and NOT money: one fixed entry, no stop, development data the project has searched before.",
    "BELOW COST": "No state representation, honestly calibrated, picks trades that pay for themselves after the 12.49 bp a "
                  "trade costs. The direction these states know about is real but smaller than the cost of acting on it. "
                  "For these stocks with these states the engine's answer is NO TRADE, and the direction track stops here. "
                  "The rules are not changed to get a pass.",
}


def write_report(out: Path, R: pd.DataFrame, CAL: pd.DataFrame, DEC: pd.DataFrame, TR: pd.DataFrame, extra: dict, v: str,
                 info: dict, stocks: List[Tuple[str, Optional[str]]]) -> None:
    names = [s for s, _ in stocks]
    L = ["# Stage C1 - the cost check", "",
         f"{CODE_VERSION} | engine_core {E.CODE_VERSION.split()[-1]} | Stage C declaration {CDECL_SHA} | engine declaration "
         f"{E.DECL_SHA} | {info['at']} | stocks {', '.join(names)} (list {info['stocks_hash']}) | Stage B run {info['stage_b']['run']} | "
         f"development {CFG['dev_start']}..{CFG['dev_end']}; nothing later is read", ""]
    if info["rerun"]:
        L += [f"**RERUN #{len(info['rerun']) + 1}** of this declaration on this stock list (earlier: {', '.join(info['rerun'])}). "
              "Not fresh evidence; the first run's verdict stands.", ""]
    L += [f"## VERDICT: {v}", "", VERDICT_TEXT[v], "",
          f"Tested on the test windows of folds {CCFG['eval_from_fold']}-{len(CFG['folds'])} "
          f"({extra['eval_period'][0] if extra['eval_period'] else '-'} .. {extra['eval_period'][1] if extra['eval_period'] else '-'}, "
          f"{extra['eval_days']} sessions). A trade = the first decision point of a stock's session whose calibrated expected move "
          f"is at least {COST:.2f} bp, in the direction of that move; net = gross - {COST:.2f} bp. [ ] = 95% block-bootstrap "
          f"interval over sessions; Holm p corrects for the {len(R)} tests; a pass needs {CCFG['min_trades']}+ trades, a lower "
          "bound above 0 and Holm p <= 0.05.", "",
          "| representation | exit | trades | expected move bp (mean) | gross bp / trade | net bp / trade | Holm p | hit rate | net at 1.5x costs | PASS |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in R.iterrows():
        if r["trades"] == 0:
            L.append(f"| {r['rep']} | {r['horizon']} | 0 | - | - | - | - | - | - | no (no decision point expects {COST:.2f} bp) |")
            continue
        L.append(f"| {r['rep']} | {r['horizon']} | {r['trades']:,} | {_u(r['mean_abs_G'], 1)} | {_ci(r['gross'], r['gross_lo'], r['gross_hi'], 1)} | "
                 f"{_ci(r['net'], r['net_lo'], r['net_hi'], 1)} | {_u(r['net_p_holm'], 3)} | {_u(r['hit_rate'] * 100, 0)}% | "
                 f"{_ci(r['net_stress'], r['net_stress_lo'], r['net_stress_hi'], 1)} | "
                 f"{'**YES**' + ('' if r['survives_stress'] else ' (not at 1.5x costs)') if r['pass'] else ('no (fewer than ' + str(CCFG['min_trades']) + ' trades)' if r['trades'] < CCFG['min_trades'] else 'no')} |")
    L += ["", "## How close do the states come to the cost?", "",
          f"The expected move of every decision point in the test windows, in bp. 'Calibrated' is what the trade rule uses; "
          f"'raw' takes the state tables at face value (no calibration). The cost is {COST:.2f} bp.", "",
          "| representation | exit | calibrated: share >= cost | median | 99th pct | max | raw: share >= cost | median | 99th pct | max |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in R.iterrows():
        L.append(f"| {r['rep']} | {r['horizon']} | {r['share_G_ge_cost'] * 100:.2f}% | {_u(r['median_G'], 1)} | {_u(r['p99_G'], 1)} | "
                 f"{_u(r['max_G'], 1)} | {r['share_Graw_ge_cost'] * 100:.2f}% | {_u(r['median_Graw'], 1)} | {_u(r['p99_Graw'], 1)} | "
                 f"{_u(r['max_Graw'], 1)} |")
    if len(DEC):
        L += ["", "## Do bigger expected moves come true? (realised gross bp going with the expected direction, by decile of the expected move)", "",
              "| representation | exit | " + " | ".join(f"D{k}" for k in range(1, int(CCFG["deciles"]) + 1)) + " |",
              "|---|---|" + "---|" * int(CCFG["deciles"])]
        for (rep, h), g in DEC.groupby(["rep", "horizon"], sort=False):
            L.append(f"| {rep} | {h} | " + " | ".join(f"{x:+.1f}" for x in g.sort_values("decile")["realised_gross_with_sign"]) + " |")
        L += ["", "D1 = the smallest tenth of expected moves, D10 = the largest. A usable signal rises from D1 to D10 and ends well above "
              f"{COST:.2f} bp."]
    if len(CAL):
        L += ["", "## Calibration (fitted on earlier test windows only)", "",
              "How much of each prediction came true before: c = the share of the state's predicted deviation that was realised "
              "(1 = all of it, 0 = none); a = the same for the stock's time-of-day baseline.", "",
              "| representation | target | " + " | ".join(f"fold {j}" for j in sorted(CAL["fold"].unique())) + " |",
              "|---|---|" + "---|" * CAL["fold"].nunique()]
        for (rep, tg), g in CAL.groupby(["rep", "target"], sort=False):
            g = g.sort_values("fold")
            cells = [f"c {x:.2f}" if tg == "barrier" else f"a {y_:.2f}, c {x:.2f}" for x, y_ in zip(g["c_state"], g["a_R0"])]
            L.append(f"| {rep} | {tg} | " + " | ".join(cells) + " |")
        L += ["", "| representation | calibrated barrier-probability Brier skill vs the time-of-day baseline |", "|---|---|"]
        for rep in REPS:
            b = extra[f"brier_cal_{rep}"]
            L.append(f"| {rep} | {_ci(b['skill'], b['lo'], b['hi'], 4)} |")
    if len(TR):
        L += ["", "## Trades by stock (net bp per trade; all tests)", "", "| stock | " + " | ".join(f"{r} {h}" for r in REPS for h in HORIZONS) + " |",
              "|---|" + "---|" * (len(REPS) * len(HORIZONS))]
        for s, nm in enumerate(names):
            cells = []
            for rep in REPS:
                for h in HORIZONS:
                    g = TR[(TR["rep"] == rep) & (TR["horizon"] == h) & (TR["sym"] == s)]
                    cells.append(f"{len(g)}: {g['net_bp'].mean():+.1f}" if len(g) else "0")
            L.append(f"| {nm} | " + " | ".join(cells) + " |")
        nv = R.dropna(subset=["novel_trades"]) if "novel_trades" in R.columns else pd.DataFrame()
        if len(nv):
            L += ["", "Novel observations (unlike the training data) among the trades: " + "; ".join(
                f"{r['rep']} {r['horizon']}: {int(r['novel_trades'])} trades, net {_f(r['novel_net'], 1)} vs {_f(r['other_net'], 1)} bp on the rest"
                for _, r in nv.iterrows())]
    L += ["", "## Limitations (stated before the run)", ""] + [f"- {x}" for x in CDECL["limitations"]] + [
          f"- Experiments: this run adds {len(R)} tests to experiments.jsonl (cumulative count {info['experiments_total']}).", ""]
    (out / "report.md").write_text("\n".join(L), encoding="utf-8")


# ----------------------------------------------------------------------
# run
# ----------------------------------------------------------------------
def previous_runs(root: Path, stocks_hash: str) -> List[str]:
    f = root / "panel" / "research_ledger.jsonl"
    out = []
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if rec.get("family") == E.DECL["family_id"] and rec.get("stage") == "C1" and rec.get("declaration") == CDECL_SHA \
                    and rec.get("stocks_hash") == stocks_hash:
                out.append(str(rec.get("run")))
    return out


def run(root: Path, stocks: List[Tuple[str, Optional[str]]], dq, IC, reconcile, log=_log) -> Tuple[Path, str]:
    E.check_reuse()
    check_declarations()
    sh = E.stocks_hash(stocks)
    sb = find_stage_b(root, sh)
    prev_runs = previous_runs(root, sh)
    log(f"{CODE_VERSION} (Stage C declaration {CDECL_SHA}, engine {E.DECL_SHA}): {len(stocks)} stocks; Stage B run {sb['run']}; "
        f"{', '.join(REPS)} x {', '.join(HORIZONS)}; cost {COST:.2f} bp a trade")
    if prev_runs:
        log(f"  WARNING: RERUN #{len(prev_runs) + 1} for this declaration and stock list (earlier: {', '.join(prev_runs)}) - not fresh evidence")
    obs, pinfo = SB.load_panel(root, stocks, dq, IC, reconcile, log)
    log(f"  {len(obs):,} decision points over {obs['day'].nunique():,} sessions")
    parts = []
    for f, fold in enumerate(CFG["folds"]):
        log(f"  fold {f + 1}: train {fold[0]}..{fold[1]}, test {fold[2]}..{fold[3]}")
        Pf = fold_predictions(obs, f, fold, log)
        if len(Pf):
            parts.append(Pf)
    P, CAL = calibrate(pd.concat(parts, ignore_index=True))
    R, TR, DEC, extra = evaluate(P)
    v = "COST CLEARED" if bool(R["pass"].any()) else "BELOW COST"
    base = root / "research2" / "engine"
    base.mkdir(parents=True, exist_ok=True)
    day = dt.date.today().strftime("%Y%m%d")
    n = 1
    while (base / f"C_{day}_{n:03d}").exists():
        n += 1
    out = base / f"C_{day}_{n:03d}"
    out.mkdir()
    ex = base / "experiments.jsonl"
    n_before = sum(1 for _ in ex.open(encoding="utf-8")) if ex.exists() else 0
    info = {"at": f"{dt.datetime.now():%Y-%m-%d %H:%M}", "stocks_hash": sh, "rerun": prev_runs, "panel": pinfo, "stage_b": sb,
            "experiments_total": n_before + len(R)}
    write_report(out, R, CAL, DEC, TR, extra, v, info, stocks)
    R.to_csv(out / "tests.csv", index=False)
    if len(TR):
        TR.assign(symbol=[stocks[int(s)][0] for s in TR["sym"]]).to_csv(out / "trades.csv", index=False)
    else:
        pd.DataFrame(columns=["rep", "horizon", "day", "symbol", "k", "G", "side", "gross_bp", "net_bp"]).to_csv(out / "trades.csv", index=False)
    DEC.to_csv(out / "deciles.csv", index=False)
    CAL.to_csv(out / "calibration.csv", index=False)
    summ = {"tool": CODE_VERSION, "core": E.CODE_VERSION, "features": E.FEATURE_VERSION, "declaration": CDECL_SHA,
            "engine_declaration": E.DECL_SHA, "verdict": v, "stage_b": sb, "stocks": stocks, "stocks_hash": sh, "rerun_of": prev_runs,
            "evaluation": extra, "panel": pinfo, "tests": json.loads(R.to_json(orient="records"))}
    (out / "summary.json").write_text(json.dumps(summ, indent=2, default=str), encoding="utf-8")
    h = hashlib.sha256(pd.util.hash_pandas_object(obs[["sym", "k"] + E.FEATURES + E.OUTCOMES], index=False).to_numpy().tobytes())
    h.update(np.asarray(pd.DatetimeIndex(obs["day"]).asi8).tobytes())
    prov = {"tool": CODE_VERSION, "declaration": CDECL_SHA, "engine_declaration": E.DECL_SHA, "data_fingerprint": h.hexdigest()[:16],
            "code_sha256_16": {**{p: BM._sha_path(HERE / p) for p in ("engine_stage_c.py", "engine_stage_b.py", "engine_core.py", "engine_models.py")},
                              "bigmove_study.py": BM._sha_path(BM.__file__)},
            "python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__,
            "platform": platform.platform(), "seed": CFG["seed"]}
    BM.seal_outputs(out, prov)
    with ex.open("a", encoding="utf-8") as fh:
        for j, r in R.iterrows():
            fh.write(json.dumps({"n": n_before + j + 1, "at": dt.datetime.now().isoformat(), "stage": "C1", "run": out.name,
                                 "declaration": CDECL_SHA, "engine_declaration": E.DECL_SHA, "stocks_hash": sh, "rerun": bool(prev_runs),
                                 "hypothesis": f"{r['rep']} states, calibrated on earlier folds, pick {r['horizon']} trades (first point with an "
                                               f"expected move >= {COST:.2f} bp) that earn more than their cost",
                                 "representation": r["rep"], "horizon": r["horizon"], "features": E.FEATURE_VERSION,
                                 "periods": {"evaluated": extra["eval_period"]}, "costs": f"{COST:.2f} bp a trade",
                                 "results": {k: r[k] for k in ("trades", "gross", "net", "net_lo", "net_p_holm", "share_G_ge_cost", "max_G")},
                                 "pass": bool(r["pass"]),
                                 "rejected_because": None if r["pass"] else (
                                     "no decision point expects a move that clears the cost" if r["trades"] == 0 else
                                     f"fewer than {CCFG['min_trades']} trades" if r["trades"] < CCFG["min_trades"] else
                                     "net after costs not above zero")}, default=float) + "\n")
    BM.write_ledger(root, {"kind": "stage", "tool": CODE_VERSION, "family": E.DECL["family_id"], "stage": "C1", "declaration": CDECL_SHA,
                           "engine_declaration": E.DECL_SHA, "run": out.name, "stocks": [s for s, _ in stocks], "stocks_hash": sh,
                           "trials": len(R), "periods": {"development": [CFG["dev_start"], CFG["dev_end"]]}, "post_2024_used": False,
                           "fresh": not prev_runs, "previous_runs": prev_runs, "verdict": v, "stage_b_run": sb["run"]})
    return out, v


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Stage C1: the cost check of the engine's surviving states")
    ap.add_argument("--root", required=True)
    ap.add_argument("--stocks", default=str(HERE / "engine_stocks.txt"))
    a = ap.parse_args(argv)
    root = Path(a.root)
    if not root.is_dir():
        raise E.PreconditionError(f"--root {root} is not a folder - run 'call env_daily.bat' and pass --root %CACHE_DAILY_ROOT%")
    stocks = E.read_stocks(Path(a.stocks))
    import data_quality as dq
    import intraday_cache as IC
    tol_p, tol_v = IC.DECL["reconcile_price_tol"], IC.DECL["reconcile_volume_tol"]
    reconcile = lambda Xg, d: IC.reconcile_symbol(Xg, d, tol_p, tol_v)
    t0 = time.time()
    out, v = run(root, stocks, dq, IC, reconcile)
    _log(f"VERDICT: {v}  ({time.time() - t0:.0f} s)")
    print(f"  report: {out / 'report.md'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
