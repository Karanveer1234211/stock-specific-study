#!/usr/bin/env python3
"""
tests/test_stage_c.py - synthetic tests of engine_stage_c (the cost check). No real data. Prints VERIFIED on success.

 1. BY HAND: the declarations agree (engine fingerprint, 12.49 bp); calibration slopes are recovered and clipped to [0, 1];
    the trade rule takes the FIRST point of a stock's session whose expected move clears the cost, in its direction, and
    prices it gross - 12.49 bp.
 2. CHRONOLOGY: a fold's calibration slopes do not change when that fold's or any later fold's outcomes change (they do
    when an earlier fold's do); Stage C's state deviations are exactly Stage B's.
 3. WORLDS (6 stocks, 5 folds): a market with strong planted trend / reversion behaviour -> COST CLEARED; a market with
    no direction to find -> BELOW COST.
 4. REFUSALS: no Stage B run, a Stage B run that did not pass, or one where a declared representation did not survive.
 5. GLUE: main() with stand-in modules writes only research2\\engine\\C_* plus 6 experiment lines (numbered after
    Stage B's) and one ledger line; changing every 2025 bar and daily row changes nothing; the second run is RERUN.
"""

from __future__ import annotations

import contextlib
import io
import json
import shutil
import sys
import tempfile
import time
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))
sys.path.insert(0, str(HERE))
sys.path.append(str(HERE.parent.parent))

import engine_core as E                        # noqa: E402
import engine_stage_b as SB                    # noqa: E402
import engine_stage_c as SC                    # noqa: E402
import test_engine as T                        # noqa: E402
from engine_world import World, reconcile_like_ic   # noqa: E402

FAILS = []


def check(cond, msg):
    print(("  ok  " if cond else "  FAIL") + f"  {msg}", flush=True)
    if not cond:
        FAILS.append(msg)


def stage_b_stub(root: Path, stocks, verdict="STATES INFORMATIVE", survivors=("grid12", "gmm4", "hmm4"), name="B_20261012_001"):
    """What a passing Stage B leaves behind (the worlds below are judged by Stage C alone, whatever Stage B would say)."""
    d = root / "research2" / "engine" / name
    d.mkdir(parents=True, exist_ok=True)
    reps = [{"rep": r, "informative": r in survivors, "stable": True} for r in E.CFG["representations"]]
    (d / "summary.json").write_text(json.dumps({"declaration": E.DECL_SHA, "stocks_hash": E.stocks_hash(stocks), "rerun_of": [],
                                                "verdict": verdict, "preferred": "grid12", "representations": reps}), encoding="utf-8")


# ----------------------------------------------------------------------
# 1. by hand
# ----------------------------------------------------------------------
def by_hand():
    print("1. by hand")
    SC.check_declarations()
    check(SC.CDECL["requires"]["engine_declaration"] == E.DECL_SHA and abs(SC.COST - E.TRADE_COST_BPS) < 0.01 and SC.REPS == ["grid12", "gmm4", "hmm4"],
          f"Stage C declaration {SC.CDECL_SHA} requires engine {E.DECL_SHA}, cost {SC.COST} bp, representations {SC.REPS}")
    rng = np.random.default_rng(1)
    r0, d = rng.normal(0, 1, 20000), rng.normal(0, 1, 20000)
    a, c = SC.fit_slopes(0.5 * r0 + 0.3 * d + rng.normal(0, 1, 20000), np.c_[r0, d])
    check(abs(a - 0.5) < 0.03 and abs(c - 0.3) < 0.03, f"calibration recovers slopes 0.5 / 0.3 ({a:.3f}, {c:.3f})")
    a, c = SC.fit_slopes(-0.4 * d + 3.0 * r0 + rng.normal(0, 0.1, 20000), np.c_[r0, d])
    check(a == 1.0 and c == 0.0, f"slopes are clipped to [0, 1]: a 3.0 -> {a}, c -0.4 -> {c}")
    check(list(SC.fit_slopes(np.ones(5), np.ones((5, 2)))) == [0.0, 0.0], "too few rows to calibrate -> slopes 0 (no trade)")
    day = pd.Timestamp("2023-05-02")
    Ev = pd.DataFrame({"fold": 1, "day": day, "sym": [0, 0, 0, 1, 1, 0], "k": [4, 9, 14, 4, 9, 4], "atr": 0.02,
                       "y_ret": [0.5, -0.4, 1.0, 0.2, 0.3, 0.1], "y_eod": 0.0,
                       "G_grid12_H60": [5.0, -15.0, 20.0, 12.0, 11.0, 30.0]})
    Ev.loc[5, "day"] = pd.Timestamp("2023-05-03")
    Tr = SC.take_trades(Ev, "grid12", "H60")
    t0 = Tr[(Tr["sym"] == 0) & (Tr["day"] == day)]
    check(len(Tr) == 2 and len(t0) == 1 and int(t0["k"].iloc[0]) == 9 and int(t0["side"].iloc[0]) == -1 and
          abs(float(t0["gross_bp"].iloc[0]) - 0.4 * 0.02 * 1e4) < 1e-9 and abs(float(t0["net_bp"].iloc[0]) - (80.0 - SC.COST)) < 1e-9,
          "first point with |expected move| >= 12.49 bp only (5 no, -15 yes -> short, later +20 ignored; 12 and 11 bp never); "
          "gross = -(-0.4 ATR x 2%) = +80 bp, net = 80 - 12.49")
    days = np.array([day, pd.Timestamp("2023-05-03")], dtype="datetime64[ns]")
    idx = np.array([[0, 1], [1, 1], [0, 0]])
    m, lo, hi, p = SC.mean_stats(days, Tr, "net_bp", idx)
    check(abs(m - Tr["net_bp"].mean()) < 1e-9, "net per trade = the mean over trades")


# ----------------------------------------------------------------------
# 2. chronology and agreement with Stage B
# ----------------------------------------------------------------------
def chronology():
    print("2. chronology and agreement with Stage B")
    rng = np.random.default_rng(5)
    n = 5000
    P = pd.DataFrame({"fold": np.repeat(np.arange(5), n), "day": pd.Timestamp("2023-01-02"), "sym": 0, "k": 4, "atr": 0.02})
    for t in SC.TARGETS:
        P["R0_" + t] = rng.normal(0, 0.05, len(P)) + (0.5 if t == "y_up" else 0.0)
        for rep in SC.REPS:
            P[f"{rep}_D_{t}"] = rng.normal(0, 0.05, len(P))
        P[t] = (P["R0_" + t] + 0.4 * P[f"grid12_D_{t}"] + rng.normal(0, 0.1, len(P))) if t != "y_up" else \
            (rng.random(len(P)) < 0.5 + 0.4 * P[f"grid12_D_{t}"]).astype(float)
    _, C1 = SC.calibrate(P)
    P2 = P.copy()
    late = P2["fold"] >= 2
    for t in SC.TARGETS:
        P2.loc[late, t] = rng.normal(0, 3, int(late.sum())) if t != "y_up" else 1.0
    _, C2 = SC.calibrate(P2)
    k = ["fold", "rep", "target"]
    f3 = lambda C: C[C["fold"] == 3].set_index(k)[["a_R0", "c_state"]]
    check(f3(C1).equals(f3(C2)), "fold 3's slopes are unchanged when the outcomes of fold 3 and later change")
    P3 = P.copy()
    early = P3["fold"] == 0
    P3.loc[early, "y_ret"] = -P3.loc[early, "y_ret"]
    _, C3 = SC.calibrate(P3)
    check(not f3(C1).equals(f3(C3)), "... and they do change when an earlier fold's outcomes change")
    g = C1[(C1["rep"] == "grid12") & (C1["target"] == "H60")]
    check(g["fold"].tolist() == [2, 3, 4, 5] and (g["c_state"] > 0.25).all() and (g["c_state"] < 0.55).all(),
          f"fold 1 only feeds calibration; slopes for folds 2-5 near the planted 0.4 ({g['c_state'].round(3).tolist()})")
    # the same states as Stage B
    w = T.small_world(True, 9, 3, "2023-12-31")
    tmp = Path(tempfile.mkdtemp())
    try:
        T.write_root(tmp, w)
        dq, ic = T.stand_ins()
        obs, _ = SB.load_panel(tmp, [(s, w.sector[s]) for s in w.stocks], dq, ic, reconcile_like_ic, log=lambda m: None)
        fold = E.CFG["folds"][0]
        saved = SB.REPS
        SB.REPS = ["grid12", "gmm4", "hmm4"]
        try:
            Pb, _, _, _ = SB.run_fold(obs, 0, fold, {}, log=lambda m: None)
        finally:
            SB.REPS = saved
        Pc = SC.fold_predictions(obs, 0, fold, log=lambda m: None)
        same = all(np.allclose(Pc[f"{r}_D_y_ret"], Pb[r + "_ret"]) for r in SC.REPS) and \
            all(np.array_equal(Pc[r + "_novel"].to_numpy(), Pb[r + "_novel"].to_numpy()) for r in ("gmm4", "hmm4"))
        check(same and np.allclose(Pc["R0_y_up"], Pb["b_y_up"]), "Stage C's states, next-hour deviations, baselines and novelty flags are Stage B's")
        check(Pc["y_eod"].notna().mean() > 0.99 and Pc[[f"{r}_D_y_eod" for r in SC.REPS]].abs().to_numpy().max() > 0,
              "the 15:03 exit has its own outcome and state deviations")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ----------------------------------------------------------------------
# 3. worlds
# ----------------------------------------------------------------------
def stage_c_world(w: World):
    tmp = Path(tempfile.mkdtemp())
    try:
        T.write_root(tmp, w)
        stocks = [(s, w.sector[s]) for s in w.stocks]
        stage_b_stub(tmp, stocks)
        dq, ic = T.stand_ins()
        buf = io.StringIO()
        t0 = time.time()
        with contextlib.redirect_stdout(buf):
            out, v = SC.run(tmp, stocks, dq, ic, reconcile_like_ic)
        R = pd.read_csv(out / "tests.csv")
        return v, R, time.time() - t0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def worlds():
    print("3. worlds (6 stocks, 5 folds each)")
    v, R, s = stage_c_world(World(n=6, seed=21, planted=True, kappa_t=0.35, kappa_r=0.35, end="2025-03-31"))
    best = R.sort_values("net", ascending=False).iloc[0]
    check(v == "COST CLEARED", f"STRONG planted behaviour -> {v}; best {best['rep']} {best['horizon']}: {int(best['trades'])} trades, "
          f"net {best['net']:+.1f} [{best['net_lo']:+.1f}, {best['net_hi']:+.1f}] bp; passing: "
          f"{', '.join(R.loc[R['pass'], 'rep'] + ' ' + R.loc[R['pass'], 'horizon']) or 'none'} ({s:.0f} s)")
    v, R, s = stage_c_world(World(n=6, seed=31, planted=False, end="2025-03-31"))
    check(v == "BELOW COST" and not R["pass"].any(), f"NO direction to find -> {v}; trades per test {R['trades'].tolist()}, "
          f"best net {R['net'].max():+.1f} bp; calibrated expected move >= cost on {R['share_G_ge_cost'].max() * 100:.2f}% of points at most ({s:.0f} s)")


# ----------------------------------------------------------------------
# 4. refusals
# ----------------------------------------------------------------------
def refusals():
    print("4. refusals")
    w = T.small_world(True, 9, 3, "2023-12-31")
    stocks = [(s, w.sector[s]) for s in w.stocks]
    for label, setup in (("no Stage B run", None),
                         ("Stage B said VOLATILITY ONLY", dict(verdict="VOLATILITY ONLY", survivors=())),
                         ("hmm4 did not survive Stage B", dict(survivors=("grid12", "gmm4")))):
        tmp = Path(tempfile.mkdtemp())
        try:
            if setup is not None:
                stage_b_stub(tmp, stocks, **setup)
            try:
                SC.find_stage_b(tmp, E.stocks_hash(stocks))
                check(False, f"refused: {label}")
            except SystemExit as e:
                check(True, f"refused: {label} ({str(e)[:90]}...)")
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
    tmp = Path(tempfile.mkdtemp())
    try:
        stage_b_stub(tmp, stocks)
        sb = SC.find_stage_b(tmp, E.stocks_hash(stocks))
        check(sb["run"] == "B_20261012_001", "a passing Stage B run on the same stock list is found")
        try:
            SC.find_stage_b(tmp, E.stocks_hash(stocks[:2]))
            check(False, "a Stage B run on a different stock list does not count")
        except SystemExit:
            check(True, "a Stage B run on a different stock list does not count")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ----------------------------------------------------------------------
# 5. glue
# ----------------------------------------------------------------------
def glue():
    print("5. glue (main() with stand-in modules)")
    tmp = Path(tempfile.mkdtemp())
    try:
        w = World(n=3, seed=13, planted=True, start_3m="2021-09-01", end="2025-02-28")
        T.write_root(tmp, w)
        stocks = [("S000", "NIFTY BANK"), ("S001", None), ("S002", None)]
        sf = tmp / "stocks.txt"
        sf.write_text("S000, NIFTY BANK\nS001\nS002\n", encoding="utf-8")
        stage_b_stub(tmp, stocks)
        ex = tmp / "research2" / "engine" / "experiments.jsonl"
        ex.write_text("".join(json.dumps({"n": i + 1, "stage": "B"}) + "\n" for i in range(8)), encoding="utf-8")
        (tmp / "panel" / "research_ledger.jsonl").write_text('{"family": "other", "run": "X"}\n', encoding="utf-8")
        before = T.tree(tmp)
        dq, ic = T.stand_ins()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc = T.with_modules(dq, ic, lambda: SC.main(["--root", str(tmp), "--stocks", str(sf)]))
        after = T.tree(tmp)
        new = sorted(set(after) - set(before))
        changed = sorted(k.replace("\\", "/") for k in before if after.get(k) != before[k])
        check(rc == 0 and all(k.replace("\\", "/").startswith("research2/engine/C_") for k in new) and
              changed == ["panel/research_ledger.jsonl", "research2/engine/experiments.jsonl"],
              f"ran (exit {rc}); wrote only research2\\engine\\C_* ({len(new)} files), the experiments file and the ledger ({changed})")
        lines = [json.loads(x) for x in ex.read_text(encoding="utf-8").splitlines()]
        check(len(lines) == 14 and [x["n"] for x in lines[8:]] == list(range(9, 15)) and all(x["stage"] == "C1" for x in lines[8:]),
              "6 experiments appended, numbered 9..14 after Stage B's 8")
        led = [json.loads(x) for x in (tmp / "panel" / "research_ledger.jsonl").read_text(encoding="utf-8").splitlines()]
        check(led[-1]["stage"] == "C1" and led[-1]["post_2024_used"] is False and led[-1]["fresh"] and led[-1]["stage_b_run"] == "B_20261012_001",
              "one ledger line: stage C1, nothing after 2024 used, fresh, names the Stage B run")
        runs = sorted((tmp / "research2" / "engine").glob("C_*"))
        need = {"report.md", "summary.json", "tests.csv", "trades.csv", "deciles.csv", "calibration.csv", "outputs.sha256"}
        rep = (runs[0] / "report.md").read_text(encoding="utf-8")
        check(len(runs) == 1 and need <= {p.name for p in runs[0].iterdir()} and "VERDICT" in rep and "RERUN" not in rep,
              "output set complete; the report has a verdict, not a rerun")
        T.write_root(tmp, w, T.late_change)
        with contextlib.redirect_stdout(buf):
            T.with_modules(dq, ic, lambda: SC.main(["--root", str(tmp), "--stocks", str(sf)]))
        runs = sorted((tmp / "research2" / "engine").glob("C_*"))
        a, b = pd.read_csv(runs[0] / "tests.csv"), pd.read_csv(runs[1] / "tests.csv")
        same = a.round(10).equals(b.round(10)) and pd.read_csv(runs[0] / "trades.csv").equals(pd.read_csv(runs[1] / "trades.csv"))
        check(len(runs) == 2 and same, "every 2025 bar and daily row changed -> identical tests and trades")
        rep2 = (runs[1] / "report.md").read_text(encoding="utf-8")
        led = [json.loads(x) for x in (tmp / "panel" / "research_ledger.jsonl").read_text(encoding="utf-8").splitlines()]
        check("RERUN" in rep2 and led[-1]["fresh"] is False and led[-1]["previous_runs"] == [runs[0].name],
              "the second run is stamped RERUN (report and ledger)")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def main() -> int:
    t0 = time.time()
    print(f"{SC.CODE_VERSION} tests (Stage C declaration {SC.CDECL_SHA}, engine declaration {E.DECL_SHA})")
    only = sys.argv[1:]
    for nm, fn in (("hand", by_hand), ("chronology", chronology), ("worlds", worlds), ("refusals", refusals), ("glue", glue)):
        if not only or nm in only:
            fn()
    print(f"\n{len(FAILS)} failure(s) in {time.time() - t0:.0f} s")
    for f in FAILS:
        print("  FAIL:", f)
    if not FAILS and not only:
        print("VERIFIED")
    return 1 if FAILS else 0


if __name__ == "__main__":
    sys.exit(main())
