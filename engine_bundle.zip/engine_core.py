#!/usr/bin/env python3
"""
engine_core.py - shared point-in-time building blocks of the 10-stock behavioural engine (ENGINE_DECLARATION.json).

engine_stage_a.py (data integrity) and engine_stage_b.py (state discovery) both build on this file, so the audit and the
study use the same sessions, the same features and the same outcomes. Nothing here fits a model.

  read_stocks       the stock list (engine_stocks.txt): symbol, optional sector index
  load_daily        the daily cache rows of one name (optionally cut at a date)
  load_bars         the 3-minute bars of one name, IST without a zone (optionally cut at a date)
  grid_bars         only rows on the 3-minute session grid, one row per timestamp (the last one kept)
  daily_context     daily and weekly context known at the OPEN of each daily row's session (earlier rows only)
  build_symbol      one stock: sessions, the clean-session rule, context, features at every decision point
  outcomes          what happened after each decision - a separate function; never an input to a feature
  pit_check         scrambles everything after a decision and checks that no feature at or before it moves

Decision k = the close of bar k (k = 4, 9, ..., 104: 09:30 to 14:30). Entry = the open of the next bar that exists,
no later than the 14:30 bar. Daily values come from rows BEFORE the session; weekly values from COMPLETED weeks.
Reuses bigmove_study v1.1 (bar matrix, usable sessions, IST conversion, VWAP, time exit, costs).
"""

from __future__ import annotations

import hashlib
import json
import sys
from pathlib import Path
from typing import Callable, Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE.parent) not in sys.path:
    sys.path.append(str(HERE.parent))     # bigmove_deploy (PYTHONPATH should already have it)

import bigmove_study as BM                # tested v1.1: bar matrix, usable sessions, IST, VWAP, time exit, costs

CODE_VERSION = "engine_core v1.0"
FEATURE_VERSION = "features_v1"
DECL_RAW = (HERE / "ENGINE_DECLARATION.json").read_bytes()
DECL = json.loads(DECL_RAW.decode("utf-8"))
CFG = DECL["config"]
DECL_SHA = hashlib.sha256(DECL_RAW).hexdigest()[:16]
NB, BAR = int(CFG["session_bars"]), int(CFG["bar_min"])
DEC_BARS = np.arange(int(CFG["decision_first_bar"]), int(CFG["decision_last_bar"]) + 1, int(CFG["decision_step"]))
E_LAST = int(CFG["entry_last_bar"])       # 105: the 14:30 bar, the last allowed entry
X_BAR = int(CFG["exit_bar"])              # 116: the 15:03 bar, whose open is the time exit
COST_BPS = BM.cash_cost_bps(float(CFG["notional_rs"]))
TRADE_COST_BPS = COST_BPS + float(CFG["slip_entry_bps"]) + float(CFG["slip_time_bps"])     # 12.49 bp a time-exit trade
DEV = (pd.Timestamp(CFG["dev_start"]), pd.Timestamp(CFG["dev_end"]))
INDEX = {"NIFTY 50": (("NIFTY 50", "NIFTY50"), "NIFTY50"),
         "NIFTY BANK": (("NIFTY BANK", "NIFTYBANK", "BANKNIFTY"), "NIFTYBANK"),
         "NIFTY IT": (("NIFTY IT", "NIFTYIT"), "NIFTYIT")}
SQ5, SQ20 = np.sqrt(5.0), np.sqrt(20.0)

FEATURES = ["d_volz", "d_ret1", "d_rng1", "d_comp", "d_clv", "d_mom5", "d_mom20", "d_hi20", "d_lo20", "d_rsi", "d_rvol",
            "w_ret1", "w_trend", "w_pos", "w_rsi", "w_rngx", "w_wtd", "gap",
            "i_ret", "i_ret3", "i_ret10", "i_vwap", "i_pos", "i_rng", "i_or", "i_pdh", "i_pdl", "i_rvol", "i_vlast", "i_rv",
            "i_eff", "i_vx", "i_rsi", "i_body", "i_uwick", "i_lwick",
            "n_ret", "n_gap", "n_eff", "rs_n", "s_ret", "rs_s", "al_d", "al_w"]
DAILY_COLS = ["d_volz", "d_ret1", "d_rng1", "d_comp", "d_clv", "d_mom5", "d_mom20", "d_hi20", "d_lo20", "d_rsi", "d_rvol"]
WEEKLY_COLS = ["w_ret1", "w_trend", "w_pos", "w_rsi", "w_rngx"]
OUTCOMES = ["y_up", "y_ret", "y_eod", "y_rng", "y_mfe", "y_mae", "y_t"]


class PreconditionError(SystemExit):
    pass


def check_reuse() -> None:
    """The reused bigmove_study must apply exactly the rules this declaration states."""
    want = {"session_bars": BM.NB, "bar_min": BM.BAR, "min_bar_share": BM.CFG["min_bar_share"], "exit_bar": BM.X_BAR,
            "entry_last_bar": BM.E_LAST}
    bad = [k for k, v in want.items() if float(CFG[k]) != float(v)]
    if bad or abs(COST_BPS - float(CFG["cost_bps_expected"])) > 0.005:
        raise PreconditionError(f"bigmove_study's rules differ from ENGINE_DECLARATION ({bad or ''} cost {COST_BPS:.3f} bp): "
                                f"use bigmove_study v1.1 with BIGMOVE_DECLARATION.json")


# ----------------------------------------------------------------------
# inputs
# ----------------------------------------------------------------------
def read_stocks(path: Path) -> List[Tuple[str, Optional[str]]]:
    """engine_stocks.txt: one stock per line, optionally ', NIFTY BANK' or ', NIFTY IT' as its sector index; '#' comments."""
    if not Path(path).exists():
        raise PreconditionError(f"no stock list at {path}: write the 10 symbols there, one per line (see engine_stocks.txt)")
    out, seen = [], set()
    for line in Path(path).read_text(encoding="utf-8").splitlines():
        s = line.split("#", 1)[0].strip()
        if not s:
            continue
        parts = [p.strip() for p in s.split(",")]
        sym, sec = parts[0].upper(), (parts[1].upper() if len(parts) > 1 and parts[1].strip() else None)
        if sec is not None and sec not in INDEX:
            raise PreconditionError(f"{path}: sector index '{parts[1]}' for {sym} is not one of {sorted(INDEX)}")
        if sym in seen:
            raise PreconditionError(f"{path}: {sym} is listed twice")
        seen.add(sym)
        out.append((sym, sec))
    if not out:
        raise PreconditionError(f"{path} lists no stocks: write the 10 symbols there, one per line")
    return out


def stocks_hash(stocks: List[Tuple[str, Optional[str]]]) -> str:
    return hashlib.sha256(json.dumps(stocks).encode("utf-8")).hexdigest()[:16]


def _days(ts) -> pd.Series:
    return BM.ist_naive(ts).dt.normalize()


def load_daily(root: Path, name: str, dq, end: Optional[pd.Timestamp] = None) -> Optional[pd.DataFrame]:
    """Daily cache rows of `name`: timestamp (as stored), day, open, high, low, close, volume; one row per day (the last
    kept), sorted; rows after `end` dropped right here."""
    fp = Path(dq._paths(root, name)[0])
    if not fp.exists():
        return None
    d = pd.read_parquet(fp)
    keep = [c for c in ("timestamp", "open", "high", "low", "close", "volume") if c in d.columns]
    d = d[keep].copy()
    if "volume" not in d.columns:
        d["volume"] = 0.0
    d["day"] = _days(d["timestamp"]).to_numpy()
    d = d.sort_values("day").drop_duplicates("day", keep="last").reset_index(drop=True)
    if end is not None:
        d = d[d["day"] <= end].reset_index(drop=True)
    for c in ("open", "high", "low", "close", "volume"):
        d[c] = d[c].astype(float)
    return d


def bar_file(root: Path, IC, name: str) -> Optional[Path]:
    """The 3-minute file of a stock, or of an index under any of its spellings."""
    names = INDEX[name][0] if name in INDEX else (name,)
    for nm in names:
        f = IC.store(root) / f"{nm}_{IC.BAR_MIN}m.parquet"
        if f.exists():
            return f
    return None


def load_bars(f: Optional[Path], start: Optional[pd.Timestamp] = None, end: Optional[pd.Timestamp] = None) -> Optional[pd.DataFrame]:
    """3-minute rows with IST timestamps without a zone (a zoned file is converted, never just stripped); rows after the
    end of `end`'s day dropped right here."""
    if f is None:
        return None
    X = pd.read_parquet(f)
    X = X[[c for c in ("timestamp", "open", "high", "low", "close", "volume") if c in X.columns]].copy()
    if "volume" not in X.columns:
        X["volume"] = 0.0
    X["timestamp"] = BM.ist_naive(X["timestamp"]).to_numpy()
    if end is not None:
        X = X[X["timestamp"] < end + pd.Timedelta(days=1)]
    if start is not None:
        X = X[X["timestamp"] >= start]
    return X.reset_index(drop=True)


def grid_bars(X: pd.DataFrame) -> pd.DataFrame:
    """Only rows on the session grid (09:15 + 3k minutes, k < 125, seconds 0) with all four prices, one row per timestamp
    (the last kept), sorted. Stage A counts what this drops."""
    t = X["timestamp"]
    m = (t.dt.hour * 60 + t.dt.minute - 555).to_numpy()
    ok = (m >= 0) & (m < NB * BAR) & (m % BAR == 0) & (t.dt.second.to_numpy() == 0) & (t.dt.weekday.to_numpy() < 5)
    ok &= X[["open", "high", "low", "close"]].notna().all(axis=1).to_numpy()
    return X[ok].drop_duplicates("timestamp", keep="last").sort_values("timestamp").reset_index(drop=True)


# ----------------------------------------------------------------------
# daily and weekly context (known at the open of each row's session)
# ----------------------------------------------------------------------
def rsi(x: pd.Series, n: int) -> pd.Series:
    d = x.diff()
    g = d.clip(lower=0).ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()
    l_ = (-d).clip(lower=0).ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean()
    with np.errstate(invalid="ignore", divide="ignore"):
        return 100.0 - 100.0 / (1.0 + g / l_)


def split_like(ratio: np.ndarray) -> np.ndarray:
    """A move of at least `a_jump_min` whose ratio sits within `a_split_tol` of a split / bonus / consolidation ratio."""
    r = np.asarray(ratio, float)
    hit = np.zeros(len(r), bool)
    with np.errstate(invalid="ignore", divide="ignore"):
        for q in CFG["a_split_ratios"]:
            hit |= (np.abs(r * q - 1) <= CFG["a_split_tol"]) | (np.abs(r / q - 1) <= CFG["a_split_tol"])
        return hit & (np.abs(r - 1) >= CFG["a_jump_min"])


def daily_context(daily: pd.DataFrame) -> pd.DataFrame:
    """One row per daily row t: what is known at the OPEN of day t - the previous official close, high, low, ATR (Wilder,
    14, as a fraction of price), 20-session median traded value, the daily features as of the previous close, the
    weekly features of the last COMPLETED week (every session of it before day t) and the week-to-date return through
    the previous close. Also 'split_jump': this row's open vs the previous close looks like a corporate action."""
    d = daily.reset_index(drop=True)
    O, H, L, C, V = (d[c].astype(float) for c in ("open", "high", "low", "close", "volume"))
    pc = C.shift(1)
    n = int(CFG["atr_period"])
    tr = pd.concat([H - L, (H - pc).abs(), (L - pc).abs()], axis=1).max(axis=1, skipna=False)
    tr.iloc[0] = H.iloc[0] - L.iloc[0]
    atr = tr.ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean() / C
    rng = (H - L) / C
    f = pd.DataFrame(index=d.index)
    with np.errstate(invalid="ignore", divide="ignore"):
        la = np.log(atr)
        f["d_volz"] = la - la.rolling(int(CFG["vol_regime_window"]), min_periods=int(CFG["vol_regime_min"])).mean()
        f["d_ret1"] = (C / pc - 1) / atr
        f["d_rng1"] = rng / atr
        f["d_comp"] = rng.rolling(5, min_periods=5).mean() / rng.rolling(20, min_periods=20).mean()
        f["d_clv"] = np.where(H > L, (C - L) / (H - L), 0.5)
        f["d_mom5"] = (C / C.shift(5) - 1) / (atr * SQ5)
        f["d_mom20"] = (C / C.shift(20) - 1) / (atr * SQ20)
        f["d_hi20"] = (C / H.rolling(20, min_periods=20).max() - 1) / atr
        f["d_lo20"] = (C / L.rolling(20, min_periods=20).min() - 1) / atr
        f["d_rsi"] = rsi(C, int(CFG["rsi_period"]))
        f["d_rvol"] = np.log(V / V.rolling(20, min_periods=20).mean())
    f["atr"] = atr
    f["value20"] = (C * V).rolling(int(CFG["value_window"]), min_periods=int(CFG["value_window"])).median()
    f["pdc"], f["pdh"], f["pdl"] = C, H, L
    ctx = f.shift(1)                                         # row t: as of the close of row t-1
    # weekly: weeks keyed by their Monday; for row t only weeks keyed before t's week (all their rows are before t)
    wk = (d["day"] - pd.to_timedelta(d["day"].dt.weekday, unit="D")).to_numpy("datetime64[ns]")
    g = pd.DataFrame({"wk": wk, "H": H, "L": L, "C": C, "atr": atr}).groupby("wk", sort=True)
    W = pd.DataFrame({"H": g["H"].max(), "L": g["L"].min(), "C": g["C"].last(), "atr": g["atr"].last()})
    with np.errstate(invalid="ignore", divide="ignore"):
        wr = (W["H"] - W["L"]) / W["C"]
        k = int(CFG["weekly_range_weeks"])
        WF = pd.DataFrame({
            "w_ret1": (W["C"] / W["C"].shift(1) - 1) / (W["atr"] * SQ5),
            "w_trend": (W["C"] / W["C"].rolling(int(CFG["weekly_sma"]), min_periods=int(CFG["weekly_sma"])).mean() - 1) / (W["atr"] * SQ5),
            "w_pos": (W["C"] - W["L"].rolling(k, min_periods=k).min()) / (W["H"].rolling(k, min_periods=k).max() - W["L"].rolling(k, min_periods=k).min()),
            "w_rsi": rsi(W["C"], int(CFG["rsi_period"])),
            "w_rngx": wr / wr.rolling(k, min_periods=k).mean(),
            "w_close": W["C"]}, index=W.index)
    keys = WF.index.to_numpy("datetime64[ns]")
    j = np.searchsorted(keys, wk, side="left") - 1           # the last week keyed strictly before this row's week
    has = j >= 0
    for c in WEEKLY_COLS:
        v = WF[c].to_numpy(float)
        ctx[c] = np.where(has, v[np.maximum(j, 0)], np.nan)
    wclose = np.where(has, WF["w_close"].to_numpy(float)[np.maximum(j, 0)], np.nan)
    same_week_prev = np.r_[False, wk[1:] == wk[:-1]]         # the previous row is in this row's (current) week
    with np.errstate(invalid="ignore", divide="ignore"):
        ctx["w_wtd"] = np.where(same_week_prev, (pc.to_numpy(float) / wclose - 1) / ctx["atr"].to_numpy(float), 0.0)
    ctx.loc[~has, "w_wtd"] = np.nan
    ctx["split_jump"] = split_like((O / pc).to_numpy(float))
    ctx["day"] = d["day"].to_numpy()
    return ctx.replace([np.inf, -np.inf], np.nan)


def context_clean(ctx: pd.DataFrame) -> np.ndarray:
    """False for a row whose previous `a_context_days` calendar days (itself included) hold a split-like jump in the daily
    file: the daily and weekly features across it mix two price bases."""
    days = pd.DatetimeIndex(ctx["day"])
    ev = days[np.asarray(ctx["split_jump"], bool)]
    if not len(ev):
        return np.ones(len(days), bool)
    evn = ev.to_numpy("datetime64[ns]")
    lo = np.searchsorted(evn, (days - pd.Timedelta(days=int(CFG["a_context_days"]))).to_numpy("datetime64[ns]"), side="left")
    hi = np.searchsorted(evn, days.to_numpy("datetime64[ns]"), side="right")
    return hi <= lo


# ----------------------------------------------------------------------
# one name's sessions
# ----------------------------------------------------------------------
def _rowmax_acc(A: np.ndarray) -> np.ndarray:
    return np.fmax.accumulate(np.where(np.isfinite(A), A, -np.inf), axis=1)


def _rowmin_acc(A: np.ndarray) -> np.ndarray:
    return np.fmin.accumulate(np.where(np.isfinite(A), A, np.inf), axis=1)


def ffill_rows(A: np.ndarray) -> np.ndarray:
    return pd.DataFrame(A).ffill(axis=1).to_numpy(float)


def slot_baseline(M: np.ndarray, ok: np.ndarray) -> np.ndarray:
    """Per session and bar: mean of M over the previous `intraday_history` sessions that are `ok` (at least
    `intraday_min_history`); today's session never counts."""
    Mu = np.where(np.asarray(ok, bool)[:, None], M, np.nan)
    return pd.DataFrame(Mu).shift(1).rolling(int(CFG["intraday_history"]), min_periods=int(CFG["intraday_min_history"])).mean().to_numpy(float)


def index_panel(daily: Optional[pd.DataFrame], X: Optional[pd.DataFrame]) -> Optional[dict]:
    """An index's sessions: first open, forward-filled closes, usable flag, ATR and previous close (from its daily file)."""
    if X is None or not len(X):
        return None
    days, B = BM.bar_matrix(grid_bars(X))
    if not len(days):
        return None
    ip = {"days": pd.DatetimeIndex(days), "O0": B["open"][:, 0], "Cf": ffill_rows(B["close"]), "usable": BM.usable_sessions(B),
          "atr": np.full(len(days), np.nan), "pdc": np.full(len(days), np.nan)}
    if daily is not None and len(daily):
        ctx = daily_context(daily)
        m = pd.Series(np.arange(len(daily)), index=pd.DatetimeIndex(daily["day"]))
        r = m.reindex(ip["days"]).to_numpy()
        ok = np.isfinite(r)
        ri = np.where(ok, r, 0).astype(int)
        ip["atr"] = np.where(ok, ctx["atr"].to_numpy(float)[ri], np.nan)
        ip["pdc"] = np.where(ok, ctx["pdc"].to_numpy(float)[ri], np.nan)
    return ip


def _align_index(ip: Optional[dict], days: pd.DatetimeIndex) -> Optional[dict]:
    """An index panel's values on a stock's session days (NaN where the index session is missing or not usable)."""
    if ip is None:
        return None
    pos = pd.Series(np.arange(len(ip["days"])), index=ip["days"]).reindex(days).to_numpy()
    ok = np.isfinite(pos)
    p = np.where(ok, pos, 0).astype(int)
    ok &= ip["usable"][p]
    D = len(days)
    out = {}
    with np.errstate(invalid="ignore", divide="ignore"):
        ret = ip["Cf"][p] / ip["O0"][p][:, None] - 1
        d = np.abs(np.diff(np.concatenate([ip["O0"][p][:, None], ip["Cf"][p]], axis=1), axis=1))
        eff = np.abs(ip["Cf"][p] - ip["O0"][p][:, None]) / np.cumsum(d, axis=1)
        out["ret"] = np.where(ok[:, None], ret, np.nan)
        out["ret_atr"] = out["ret"] / ip["atr"][p][:, None]
        out["gap"] = np.where(ok, (ip["O0"][p] / ip["pdc"][p] - 1) / ip["atr"][p], np.nan)
        out["eff"] = np.where(ok[:, None], eff, np.nan)
    return out if D else None


def session_frame(days: np.ndarray, B: Dict[str, np.ndarray], daily: pd.DataFrame, ctx: pd.DataFrame,
                  calendar: Optional[pd.DatetimeIndex], recon: Optional[pd.DataFrame]) -> pd.DataFrame:
    """One row per 3-minute session with the clean-session rule's parts and the daily context row it uses. The parts
    are whole-session HYGIENE (as in bigmove_study v1.1 and Stage 0): they decide whether a session is studied, never a
    feature value."""
    days = pd.DatetimeIndex(days)
    D = len(days)
    rowmap = pd.Series(np.arange(len(daily)), index=pd.DatetimeIndex(daily["day"]))
    trow = rowmap.reindex(days).to_numpy()
    has_row = np.isfinite(trow)
    t = np.where(has_row, trow, 0).astype(int)
    S = pd.DataFrame({"day": days})
    S["row"] = np.where(has_row, t, -1)
    S["in_calendar"] = days.isin(calendar) if calendar is not None else np.ones(D, bool)
    S["usable"] = BM.usable_sessions(B) if D else np.zeros(0, bool)
    S["bars"] = np.isfinite(B["close"]).sum(1) if D else np.zeros(0, int)
    if recon is not None and len(recon):
        R = recon.assign(day=pd.to_datetime(recon["day"]).dt.normalize()).drop_duplicates("day", keep="last").set_index("day")
        for c in ("ok", "price_ok", "volume_ok", "basis_mismatch"):
            S["rec_" + c] = R[c].reindex(days).fillna(False).astype(bool).to_numpy() if c in R.columns else False
        S["rec_ratio"] = R["ratio"].reindex(days).to_numpy(float) if "ratio" in R.columns else np.nan
    else:
        for c in ("ok", "price_ok", "volume_ok", "basis_mismatch"):
            S["rec_" + c] = False
        S["rec_ratio"] = np.nan
    cv = lambda c: np.where(has_row, ctx[c].to_numpy(float)[t], np.nan)
    pdc, atr, val = cv("pdc"), cv("atr"), cv("value20")
    O0 = B["open"][:, 0] if D else np.zeros(0)
    with np.errstate(invalid="ignore", divide="ignore"):
        S["gap_raw"] = O0 / pdc - 1
        S["liquid"] = (pdc >= CFG["min_price"]) & (val >= CFG["min_value_cr"] * 1e7) & (atr > 0)
        S["basis_guard"] = np.abs(S["gap_raw"].to_numpy(float)) <= CFG["max_abs_gap"]
    cc = context_clean(ctx)
    S["context_clean"] = np.where(has_row, cc[t], False)
    S["clean"] = (has_row & S["in_calendar"] & S["usable"] & S["rec_ok"] & S["liquid"] & S["basis_guard"] & S["context_clean"]
                  & np.isfinite(atr) & np.isfinite(pdc))
    return S


# ----------------------------------------------------------------------
# features at every decision point (bars 0..k of the session only)
# ----------------------------------------------------------------------
def intraday_features(days: np.ndarray, B: Dict[str, np.ndarray], S: pd.DataFrame, ctx: pd.DataFrame,
                      mkt: Optional[dict], sec: Optional[dict]) -> pd.DataFrame:
    """One row per clean session and decision bar k whose bar k exists: day, k, the session's position i, and FEATURES.
    Inputs at decision k: bars 0..k of the session, the session's context row (previous close and earlier), earlier
    sessions' bars for the same-time baselines, and the indices' bars 0..k."""
    D = len(days)
    if D == 0:
        return pd.DataFrame(columns=["day", "k", "i"] + FEATURES)
    O, H, L, C, V = (np.asarray(B[k], float) for k in ("open", "high", "low", "close", "volume"))
    clean = S["clean"].to_numpy(bool)
    t = S["row"].to_numpy(int)
    has = t >= 0
    cv = lambda c: np.where(has, ctx[c].to_numpy(float)[np.maximum(t, 0)], np.nan)
    atr, pdc, pdh, pdl = cv("atr"), cv("pdc"), cv("pdh"), cv("pdl")
    O0 = O[:, 0]
    Cf = ffill_rows(C)
    Vz = np.where(np.isfinite(V), V, 0.0)
    cumV = np.cumsum(Vz, axis=1)
    hi, lo = _rowmax_acc(H), _rowmin_acc(L)
    vwap = BM.session_vwap(H, L, C, V)
    vwap = np.where(np.isfinite(vwap), vwap, Cf)             # no volume yet: the price itself
    with np.errstate(invalid="ignore", divide="ignore"):
        prev = np.concatenate([O0[:, None], Cf[:, :-1]], axis=1)
        r = np.log(Cf / prev)
        rv = np.sqrt(np.cumsum(np.where(np.isfinite(r), r * r, 0.0), axis=1))
        path = np.cumsum(np.abs(np.where(np.isfinite(Cf - prev), Cf - prev, 0.0)), axis=1)
        eff = np.where(path > 0, np.abs(Cf - O0[:, None]) / path, 0.0)
        side = np.sign(Cf - vwap)
        flips = (side[:, 1:] * side[:, :-1]) < 0
        vx = np.concatenate([np.zeros((D, 1)), np.cumsum(flips, axis=1)], axis=1) / (np.arange(NB)[None, :] + 1)
        dC = np.diff(Cf, axis=1)
        n = int(CFG["rsi_period"])
        gpos = pd.DataFrame(np.clip(dC, 0, None).T).ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean().T.to_numpy(float)
        gneg = pd.DataFrame(np.clip(-dC, 0, None).T).ewm(alpha=1.0 / n, adjust=False, min_periods=n).mean().T.to_numpy(float)
        rsi_i = np.concatenate([np.full((D, 1), np.nan), 100.0 - 100.0 / (1.0 + gpos / gneg)], axis=1)
    vbase = slot_baseline(V, clean)
    cvbase = slot_baseline(cumV, clean)
    rvbase = slot_baseline(rv, clean)
    r_or = int(CFG["or_bars"])
    orh, orl = BM._rowmax(H[:, :r_or]), BM._rowmin(L[:, :r_or])
    dctx = {c: cv(c) for c in DAILY_COLS + WEEKLY_COLS + ["w_wtd"]}
    M = _align_index(mkt, pd.DatetimeIndex(days))
    Sx = _align_index(sec, pd.DatetimeIndex(days))
    parts = []
    with np.errstate(invalid="ignore", divide="ignore"):
        gap = (O0 / pdc - 1) / atr
        for k in DEC_BARS:
            ok = clean & np.isfinite(C[:, k])
            if not ok.any():
                continue
            ck = C[:, k]
            F = {"day": np.asarray(days)[ok], "k": np.full(ok.sum(), k, np.int16), "i": np.flatnonzero(ok)}
            for c in DAILY_COLS + WEEKLY_COLS + ["w_wtd"]:
                F[c] = dctx[c][ok]
            F["gap"] = gap[ok]
            ret = ck / O0 - 1
            F["i_ret"] = (ret / atr)[ok]
            F["i_ret3"] = ((ck / Cf[:, k - 3] - 1) / atr)[ok]
            F["i_ret10"] = ((ck / (Cf[:, k - 10] if k >= 10 else O0) - 1) / atr)[ok]
            F["i_vwap"] = ((ck / vwap[:, k] - 1) / atr)[ok]
            span = hi[:, k] - lo[:, k]
            F["i_pos"] = np.where(span > 0, (ck - lo[:, k]) / span, 0.5)[ok]
            F["i_rng"] = (span / O0 / atr)[ok]
            F["i_or"] = (np.where(ck > orh, ck / orh - 1, np.where(ck < orl, ck / orl - 1, 0.0)) / atr)[ok]
            F["i_pdh"] = ((ck / pdh - 1) / atr)[ok]
            F["i_pdl"] = ((ck / pdl - 1) / atr)[ok]
            F["i_rvol"] = np.log(cumV[:, k] / cvbase[:, k])[ok]
            F["i_vlast"] = np.log(Vz[:, k - 2:k + 1].sum(1) / np.nansum(vbase[:, k - 2:k + 1], axis=1))[ok]
            F["i_rv"] = np.log(rv[:, k] / rvbase[:, k])[ok]
            F["i_eff"] = eff[:, k][ok]
            F["i_vx"] = vx[:, k][ok]
            F["i_rsi"] = rsi_i[:, k][ok]
            h3 = BM._rowmax(H[:, k - 2:k + 1])
            l3 = BM._rowmin(L[:, k - 2:k + 1])
            o3 = O[:, k - 2]
            o3 = np.clip(np.where(np.isfinite(o3), o3, Cf[:, k - 3]), l3, h3)      # a missing bar k-2: the close before it
            r3 = h3 - l3
            F["i_body"] = np.where(r3 > 0, (ck - o3) / r3, 0.0)[ok]
            F["i_uwick"] = np.where(r3 > 0, (h3 - np.maximum(o3, ck)) / r3, 0.0)[ok]
            F["i_lwick"] = np.where(r3 > 0, (np.minimum(o3, ck) - l3) / r3, 0.0)[ok]
            if M is not None:
                F["n_ret"] = M["ret_atr"][:, k][ok]
                F["n_gap"] = M["gap"][ok]
                F["n_eff"] = M["eff"][:, k][ok]
                F["rs_n"] = ((ret - M["ret"][:, k]) / atr)[ok]
            if Sx is not None:
                F["s_ret"] = Sx["ret_atr"][:, k][ok]
                F["rs_s"] = ((ret - Sx["ret"][:, k]) / atr)[ok]
            F["al_d"] = (ret / atr * dctx["d_mom20"])[ok]
            F["al_w"] = (ret / atr * dctx["w_trend"])[ok]
            parts.append(pd.DataFrame(F))
    if not parts:
        return pd.DataFrame(columns=["day", "k", "i"] + FEATURES)
    out = pd.concat(parts, ignore_index=True)
    for c in FEATURES:
        if c not in out.columns:
            out[c] = np.nan
    out = out[["day", "k", "i"] + FEATURES].replace([np.inf, -np.inf], np.nan)
    return out.sort_values(["day", "k"], kind="stable").reset_index(drop=True)


# ----------------------------------------------------------------------
# outcomes (after the decision; never an input to a feature)
# ----------------------------------------------------------------------
def outcomes(B: Dict[str, np.ndarray], atr: np.ndarray, i: np.ndarray, k: np.ndarray) -> pd.DataFrame:
    """For decision rows (session i, bar k): entry bar and price (the next bar that exists, by the 14:30 bar), and y_up,
    y_ret, y_eod, y_rng, y_mfe, y_mae, y_t (see the declaration's outcomes_v1). Rows without an entry are all NaN."""
    O, H, L, C = (np.asarray(B[c], float) for c in ("open", "high", "low", "close"))
    i, k = np.asarray(i, int), np.asarray(k, int)
    n = len(i)
    O_, H_, L_, Cf_ = O[i], H[i], L[i], ffill_rows(C[i])
    a = np.asarray(atr, float)[i]
    e = BM.first_true(np.isfinite(O_), k + 1, E_LAST)
    has = e >= 0
    rows = np.arange(n)
    ent = np.where(has, O_[rows, np.maximum(e, 0)], np.nan)
    cols = np.arange(NB)[None, :]
    hz = np.minimum(e + int(CFG["horizon_bars"]) - 1, X_BAR - 1)
    win = (cols >= e[:, None]) & (cols <= hz[:, None])
    tail = (cols >= e[:, None]) & (cols <= X_BAR - 1)
    b = float(CFG["barrier_atr"])
    with np.errstate(invalid="ignore", divide="ignore"):
        y_ret = (Cf_[rows, np.maximum(hz, 0)] / ent - 1) / a
        y_eod = (BM.time_exit_price(O_, C[i]) / ent - 1) / a
        hw = BM._rowmax(np.where(win, H_, np.nan))
        lw = BM._rowmin(np.where(win, L_, np.nan))
        y_rng = np.log(np.maximum((hw - lw) / ent / a, 1e-4))
        y_mfe = (BM._rowmax(np.where(tail, H_, np.nan)) / ent - 1) / a
        y_mae = (1 - BM._rowmin(np.where(tail, L_, np.nan)) / ent) / a
        up = BM.first_true(tail & (H_ >= (ent * (1 + b * a))[:, None]), 0, NB - 1)
        dn = BM.first_true(tail & (L_ <= (ent * (1 - b * a))[:, None]), 0, NB - 1)
    upi = np.where(up >= 0, up, 10 ** 6)
    dni = np.where(dn >= 0, dn, 10 ** 6)
    y_up = np.where(upi < dni, 1.0, np.where(dni < upi, 0.0, np.nan))
    amb = (up >= 0) & (up == dn)
    y_t = np.where(np.isfinite(y_up), np.minimum(upi, dni) - e, np.nan)
    out = pd.DataFrame({"e": np.where(has, e, -1), "entry": ent, "y_up": y_up, "y_amb": amb & has, "y_ret": y_ret, "y_eod": y_eod,
                        "y_rng": y_rng, "y_mfe": y_mfe, "y_mae": y_mae, "y_t": y_t})
    for c in OUTCOMES:
        out.loc[~has, c] = np.nan
    return out.replace([np.inf, -np.inf], np.nan)


# ----------------------------------------------------------------------
# one stock end to end
# ----------------------------------------------------------------------
def build_symbol(daily: pd.DataFrame, X: pd.DataFrame, calendar: Optional[pd.DatetimeIndex], reconcile: Callable,
                 mkt: Optional[dict], sec: Optional[dict], clean_fixed: Optional[np.ndarray] = None,
                 with_outcomes: bool = True) -> dict:
    """Sessions, the clean-session rule, daily context, features at every decision point and (optionally) outcomes.
    `reconcile(Xgrid, daily)` is intraday_cache's reconcile_symbol with the declared tolerances. `clean_fixed` holds the
    clean flags fixed (the point-in-time check)."""
    Xg = grid_bars(X)
    days, B = BM.bar_matrix(Xg)
    ctx = daily_context(daily)
    rec = reconcile(Xg, daily) if len(Xg) else pd.DataFrame()
    S = session_frame(days, B, daily, ctx, calendar, rec)
    if clean_fixed is not None:
        S["clean"] = np.asarray(clean_fixed, bool)
    Fe = intraday_features(days, B, S, ctx, mkt, sec)
    out = {"days": pd.DatetimeIndex(days), "B": B, "S": S, "ctx": ctx, "F": Fe, "Xg": Xg}
    if with_outcomes:
        atr = np.where(S["row"].to_numpy(int) >= 0, ctx["atr"].to_numpy(float)[np.maximum(S["row"].to_numpy(int), 0)], np.nan)
        Y = outcomes(B, atr, Fe["i"].to_numpy(int), Fe["k"].to_numpy(int)) if len(Fe) else pd.DataFrame(columns=["e", "entry", "y_amb"] + OUTCOMES)
        out["Y"] = Y
        out["atr_s"] = atr
    return out


# ----------------------------------------------------------------------
# the point-in-time check (Stage A runs it on real data; the tests run it on synthetic data)
# ----------------------------------------------------------------------
def scramble_after(daily: Optional[pd.DataFrame], X: pd.DataFrame, day: pd.Timestamp, k: int, rng) -> Tuple[Optional[pd.DataFrame], pd.DataFrame]:
    """Copies in which everything not known at the close of bar k on `day` is replaced: the session's bars after k (they
    stay valid bars), its own daily row and every later daily row, and every later session."""
    d2 = None
    if daily is not None:
        d2 = daily.copy()
        late = (d2["day"] >= day).to_numpy()
        f = rng.uniform(0.7, 1.3, size=late.sum())
        for c in ("open", "high", "low", "close"):
            d2.loc[late, c] = d2.loc[late, c].to_numpy(float) * f
        d2.loc[late, "volume"] = d2.loc[late, "volume"].to_numpy(float) * rng.uniform(0.2, 5.0, size=late.sum())
    X2 = X.copy()
    ts = X2["timestamp"]
    cut = day + pd.Timedelta(minutes=555 + BAR * (k + 1))   # the start of bar k+1
    lt = (ts >= cut).to_numpy()
    g = rng.uniform(0.7, 1.3, size=lt.sum())
    for c in ("open", "high", "low", "close"):
        X2.loc[lt, c] = X2.loc[lt, c].to_numpy(float) * g
    X2.loc[lt, "volume"] = X2.loc[lt, "volume"].to_numpy(float) * rng.uniform(0.2, 5.0, size=lt.sum())
    return d2, X2


def pit_check(daily: pd.DataFrame, X: pd.DataFrame, calendar, mkt_raw: Optional[tuple], sec_raw: Optional[tuple],
              base: dict, n_days: int, seed: int, dev_only: bool = True) -> dict:
    """On n_days random clean sessions (development window): pick a decision bar k, scramble everything after it (this
    stock and the indices), rebuild, and require every feature at decision bars <= k on that session to be identical.
    Clean flags are held fixed (they are session hygiene, not features). Returns counts and the first failures."""
    rng = np.random.default_rng(seed)
    F0 = base["F"]
    S0 = base["S"]
    cand = S0.loc[S0["clean"], "day"]
    if dev_only:
        cand = cand[(cand >= DEV[0]) & (cand <= DEV[1])]
    cand = cand[cand.isin(pd.DatetimeIndex(F0["day"]))]
    if not len(cand):
        return {"checked": 0, "failed": 0, "failures": []}
    pick = rng.choice(cand.to_numpy(), size=min(n_days, len(cand)), replace=False)
    fails, n = [], 0
    for dday in pick:
        dday = pd.Timestamp(dday)
        k = int(rng.choice(DEC_BARS))
        d2, X2 = scramble_after(daily, X, dday, k, rng)
        m2 = index_panel(*scramble_after(mkt_raw[0], mkt_raw[1], dday, k, rng)) if mkt_raw is not None and mkt_raw[1] is not None else None
        s2 = index_panel(*scramble_after(sec_raw[0], sec_raw[1], dday, k, rng)) if sec_raw is not None and sec_raw[1] is not None else None
        # clean flags held fixed (no reconciliation needed); the session list is the same (bars are changed, none removed)
        rb = build_symbol(d2, X2, calendar, lambda *_: pd.DataFrame(), m2, s2, clean_fixed=S0["clean"].to_numpy(bool),
                          with_outcomes=False)
        a = F0[(F0["day"] == dday) & (F0["k"] <= k)].reset_index(drop=True)
        b_ = rb["F"][(rb["F"]["day"] == dday) & (rb["F"]["k"] <= k)].reset_index(drop=True)
        n += 1
        same = len(a) == len(b_) and len(a) > 0 and np.allclose(a[FEATURES].to_numpy(float), b_[FEATURES].to_numpy(float),
                                                                 rtol=1e-9, atol=1e-12, equal_nan=True)
        if not same:
            bad = []
            if len(a) == len(b_) and len(a):
                d = ~np.isclose(a[FEATURES].to_numpy(float), b_[FEATURES].to_numpy(float), rtol=1e-9, atol=1e-12, equal_nan=True)
                bad = [FEATURES[j] for j in np.flatnonzero(d.any(0))]
            fails.append({"day": str(dday.date()), "k": k, "features": bad or "row count"})
    return {"checked": n, "failed": len(fails), "failures": fails[:10]}
