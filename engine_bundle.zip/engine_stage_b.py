#!/usr/bin/env python3
"""
engine_stage_b.py - Stage B of the 10-stock behavioural engine: state discovery (ENGINE_DECLARATION.json, stage_B).
No strategy is built or optimised here.

    python engine_stage_b.py --root %CACHE_DAILY_ROOT%                      (stocks from engine_stocks.txt)
    python engine_stage_b.py --root %CACHE_DAILY_ROOT% --stocks my10.txt

The question, in plain words: at each decision point (09:30, 09:45, ... 14:30) we describe the stock with ~44
point-in-time numbers (weekly, daily, opening, intraday, NIFTY and sector context). Several ways of turning those numbers
into "states" are learned on past data only (a simple human-made grid, k-means, a Gaussian mixture, a hidden Markov
model, and plain nearest-neighbour analogues). Each is then asked, on the next 6 months it has never seen: does knowing
the state predict what happens next - which way the price breaks (+0.3 ATR before -0.3 ATR), the next hour's return,
and how much it moves - better than the stock's own usual behaviour at that time of day? Five walk-forward folds inside
2021-10 .. 2024-12. Nothing after 2024-12-31 is read.

Writes only <root>\\research2\\engine\\B_<date>_<n>\\, appends one line per representation to
<root>\\research2\\engine\\experiments.jsonl and one line to <root>\\panel\\research_ledger.jsonl.
"""

from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import platform
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import engine_core as E                  # noqa: E402
import engine_models as EM               # noqa: E402

BM = E.BM
CODE_VERSION = "engine_stage_b v1.0"
CFG = E.CFG
REPS = list(CFG["representations"])
TARGETS = ["y_up", "y_ret", "y_rng"]
SIMPLICITY = {"grid12": 0, "kmeans4": 1, "kmeans8": 2, "gmm4": 3, "gmm8": 4, "hmm4": 5, "hmm8": 6, "knn100": 9}


def _log(msg: str) -> None:
    print(f"{dt.datetime.now():%H:%M:%S}  {msg}", flush=True)


def tod_bucket(k: np.ndarray) -> np.ndarray:
    return np.searchsorted(np.asarray(CFG["tod_edges"]), np.asarray(k), side="right") - 1


def n_states(rep: str) -> int:
    return 12 if rep == "grid12" else (0 if rep.startswith("knn") else int("".join(ch for ch in rep if ch.isdigit())))


# ----------------------------------------------------------------------
# the panel: every decision point of every stock, development window only
# ----------------------------------------------------------------------
def load_panel(root: Path, stocks: List[Tuple[str, Optional[str]]], dq, IC, reconcile, log=_log) -> Tuple[pd.DataFrame, dict]:
    end = E.DEV[1]
    nd = E.load_daily(root, "NIFTY50", dq, end)
    if nd is None or not len(nd):
        raise E.PreconditionError("no NIFTY50 daily file in the daily cache: it is the session calendar")
    cal = pd.DatetimeIndex(nd["day"])
    mkt = E.index_panel(nd, E.load_bars(E.bar_file(root, IC, "NIFTY 50"), end=end))
    if mkt is None:
        raise E.PreconditionError("no NIFTY 50 3-minute file: run intraday_cache.py update --symbols-file indices.txt")
    secs = {}
    for s in sorted({sec for _, sec in stocks if sec}):
        secs[s] = E.index_panel(E.load_daily(root, E.INDEX[s][1], dq, end), E.load_bars(E.bar_file(root, IC, s), end=end))
    parts, info = [], {"stocks": {}, "sectors": {s: (v is not None) for s, v in secs.items()}}
    for j, (sym, sec) in enumerate(stocks):
        daily = E.load_daily(root, sym, dq, end)
        X = E.load_bars(E.bar_file(root, IC, sym), end=end)
        if daily is None or X is None or not len(X):
            info["stocks"][sym] = {"error": "no daily file" if daily is None else "no 3-minute file"}
            log(f"  {sym}: {info['stocks'][sym]['error']} - left out")
            continue
        r = E.build_symbol(daily, X, cal, reconcile, mkt, secs.get(sec) if sec else None)
        F, Y, S = r["F"], r["Y"], r["S"]
        o = pd.concat([F.reset_index(drop=True), Y.reset_index(drop=True)], axis=1)
        o["atr"] = r["atr_s"][F["i"].to_numpy(int)] if len(F) else np.nan
        o["sym"] = j
        o = o[(o["day"] >= E.DEV[0]) & (o["day"] <= E.DEV[1]) & (o["e"] >= 0)]
        dev = S[(S["day"] >= E.DEV[0]) & (S["day"] <= E.DEV[1])]
        info["stocks"][sym] = {"sector": sec, "sessions_dev": int(len(dev)), "clean_dev": int(dev["clean"].sum()),
                               "decisions": int(len(o)), "y_up_resolved": float(o["y_up"].notna().mean()) if len(o) else np.nan,
                               "y_up_same_bar": int(o["y_amb"].sum()) if len(o) else 0}
        parts.append(o)
        log(f"  {sym}: {len(dev):,} development sessions, {int(dev['clean'].sum()):,} clean, {len(o):,} decision points")
    if not parts:
        raise E.PreconditionError("no stock has usable data in the development window")
    obs = pd.concat(parts, ignore_index=True).sort_values(["day", "sym", "k"], kind="stable").reset_index(drop=True)
    obs["tod"] = tod_bucket(obs["k"].to_numpy())
    return obs, info


# ----------------------------------------------------------------------
# one fold
# ----------------------------------------------------------------------
def baseline(tr: pd.DataFrame, te: pd.DataFrame) -> Tuple[np.ndarray, np.ndarray]:
    """R0: the training mean of each target per stock and time-of-day bucket (the stock's mean, then the overall mean,
    where a cell is empty). Returns (train baseline, test baseline), each rows x TARGETS."""
    out = []
    for D in (tr, te):
        B = np.empty((len(D), len(TARGETS)))
        for j, t in enumerate(TARGETS):
            cell = tr.groupby(["sym", "tod"])[t].mean()
            st = tr.groupby("sym")[t].mean()
            v = pd.MultiIndex.from_arrays([D["sym"], D["tod"]])
            x = cell.reindex(v).to_numpy(float)
            x = np.where(np.isfinite(x), x, st.reindex(D["sym"]).to_numpy(float))
            B[:, j] = np.where(np.isfinite(x), x, float(tr[t].mean()))
        out.append(B)
    return out[0], out[1]


def state_tables(P: np.ndarray, Dv: np.ndarray, sym: np.ndarray, n_sym: int, lam: float) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """Per stock and state, the shrunk mean deviation from R0 of each target: (sum + lam x pooled) / (soft count + lam),
    pooled = sum over stocks / (count + lam) (shrunk toward no effect). Returns (stock x state x target, soft counts
    stock x state x target, pooled state x target)."""
    K, T = P.shape[1], Dv.shape[1]
    fin = np.isfinite(Dv)
    D0 = np.where(fin, Dv, 0.0)
    sm, ct = np.zeros((n_sym, K, T)), np.zeros((n_sym, K, T))
    for s in range(n_sym):
        m = sym == s
        if m.any():
            sm[s] = P[m].T @ D0[m]
            ct[s] = P[m].T @ fin[m].astype(float)
    pooled = sm.sum(0) / (ct.sum(0) + lam)
    return (sm + lam * pooled[None]) / (ct + lam), ct, pooled


def sequences(df: pd.DataFrame, Z: np.ndarray) -> Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]:
    """Each stock-session's decision points as one sequence (S, 21, p) with an observed mask; and each row's (seq, step)."""
    key = df["sym"].to_numpy(np.int64) * 10 ** 6 + (pd.DatetimeIndex(df["day"]).asi8 // 86_400_000_000_000)
    uk, seq = np.unique(key, return_inverse=True)
    step = np.searchsorted(E.DEC_BARS, df["k"].to_numpy())
    Y = np.zeros((len(uk), len(E.DEC_BARS), Z.shape[1]))
    M = np.zeros((len(uk), len(E.DEC_BARS)), bool)
    Y[seq, step] = Z
    M[seq, step] = True
    return Y, M, seq, step


class Rep:
    """One representation fitted on one training window: probabilities on any rows, a novelty score, hard labels."""

    def __init__(self, name: str, prep: EM.Prep, seed: int):
        self.name, self.prep, self.seed = name, prep, seed
        self.K = n_states(name)

    def fit(self, tr: pd.DataFrame, Ztr: np.ndarray) -> "Rep":
        rng = np.random.default_rng(self.seed)
        a = dict(n_init=int(CFG["kmeans_init"]), iters=int(CFG["kmeans_iter"]))
        if self.name.startswith("kmeans"):
            self.m = EM.KMeans().fit(Ztr, self.K, rng, **a)
        elif self.name.startswith("gmm"):
            self.m = EM.GMM().fit(Ztr, self.K, rng, **a, max_iter=int(CFG["em_max_iter"]), tol=float(CFG["em_tol"]),
                                  var_floor=float(CFG["var_floor"]))
        elif self.name.startswith("hmm"):
            Y, M, _, _ = sequences(tr, Ztr)
            self.m = EM.HMM().fit(Y, M, self.K, rng, **a, max_iter=60, tol=float(CFG["em_tol"]), var_floor=float(CFG["var_floor"]))
        else:
            self.m = None
        return self

    def proba(self, df: pd.DataFrame, Z: np.ndarray) -> np.ndarray:
        if self.name == "grid12":
            return EM.grid12(df["i_ret"].to_numpy(float), df["i_vwap"].to_numpy(float), df["i_rv"].to_numpy(float),
                             float(CFG["grid_ret_atr"]))
        if self.name.startswith("hmm"):
            Y, M, seq, step = sequences(df, Z)
            return self.m.filter(Y, M)[seq, step]
        return self.m.proba(Z)

    def novelty(self, Z: np.ndarray) -> Optional[np.ndarray]:
        return None if self.m is None else self.m.novelty_score(Z)


def run_fold(obs: pd.DataFrame, f: int, fold: list, prev: Dict[str, Rep], log=_log) -> Tuple[pd.DataFrame, list, Dict[str, Rep], dict]:
    a, b, c, d = (pd.Timestamp(x) for x in fold)
    tr = obs[(obs["day"] >= a) & (obs["day"] <= b)].reset_index(drop=True)
    te = obs[(obs["day"] >= c) & (obs["day"] <= d)].reset_index(drop=True)
    if not len(tr) or not len(te):
        return pd.DataFrame(), [], prev, {}
    n_sym = int(obs["sym"].max()) + 1
    lam = float(CFG["shrink_lambda"])
    b_tr, b_te = baseline(tr, te)
    Dtr = tr[TARGETS].to_numpy(float) - b_tr
    prep = EM.Prep(float(CFG["clip_z"]), float(CFG["pca_var"]), int(CFG["pca_min"]), int(CFG["pca_max"])).fit(tr[E.FEATURES].to_numpy(float))
    Ztr, Zte = prep.transform(tr[E.FEATURES].to_numpy(float)), prep.transform(te[E.FEATURES].to_numpy(float))
    out = pd.DataFrame({"fold": f, "day": te["day"].to_numpy(), "sym": te["sym"].to_numpy(), "k": te["k"].to_numpy(),
                        "atr": te["atr"].to_numpy(float)})
    for j, t in enumerate(TARGETS):
        out[t] = te[t].to_numpy(float)
        out["b_" + t] = b_te[:, j]
    rows, models, cards = [], {}, {}
    seed = int(CFG["seed"])
    for rep in REPS:
        t0 = time.time()
        r = {"fold": f, "rep": rep, "train_rows": len(tr), "test_rows": len(te), "pca_parts": int(prep.comp.shape[0]),
             "pca_share": prep.explained}
        if rep.startswith("knn"):
            P_te = None
            pred = np.full((len(te), len(TARGETS)), np.nan)
            for s in range(n_sym):
                ms, mt = tr["sym"].to_numpy() == s, te["sym"].to_numpy() == s
                if mt.any():
                    pred[mt] = EM.knn_predict(Ztr[ms], Dtr[ms], Zte[mt], int(CFG["knn_k"]), lam)
            dev_tr = None
            r["fit_s"] = time.time() - t0
        else:
            m = Rep(rep, prep, seed).fit(tr, Ztr)
            P_tr, P_te = m.proba(tr, Ztr), m.proba(te, Zte)
            r["fit_s"] = time.time() - t0
            tab, cnt, pooled = state_tables(P_tr, Dtr, tr["sym"].to_numpy(), n_sym, lam)
            pred = np.einsum("nk,nkt->nt", P_te, tab[te["sym"].to_numpy()])
            dev_tr = np.einsum("nk,nkt->nt", P_tr, tab[tr["sym"].to_numpy()])
            lab_tr, lab_te = P_tr.argmax(1), P_te.argmax(1)
            sh_tr = np.bincount(lab_tr, minlength=m.K) / len(lab_tr)
            sh_te = np.bincount(lab_te, minlength=m.K) / len(lab_te)
            r["psi"] = EM.psi(sh_tr, sh_te)
            r["states_used"] = int((sh_te > 0.01).sum())
            same = (te["sym"].to_numpy()[1:] == te["sym"].to_numpy()[:-1]) & (te["day"].to_numpy()[1:] == te["day"].to_numpy()[:-1])
            r["persist"] = float((lab_te[1:] == lab_te[:-1])[same].mean()) if same.any() else np.nan
            r["persist_chance"] = float((sh_te ** 2).sum())
            if rep != "grid12":
                m2 = Rep(rep, prep, seed + 1).fit(tr, Ztr)
                r["seed_ari"] = EM.ari(lab_te, m2.proba(te, Zte).argmax(1))
                if rep in prev:
                    pz = prev[rep].prep.transform(te[E.FEATURES].to_numpy(float))
                    r["refit_ari"] = EM.ari(lab_te, prev[rep].proba(te, pz).argmax(1))
                nv_tr, nv_te = m.novelty(Ztr), m.novelty(Zte)
                cut = np.percentile(nv_tr, 100 - float(CFG["novelty_pct"]))
                out[rep + "_novel"] = nv_te > cut
            else:
                r["seed_ari"] = 1.0
                if rep in prev:
                    r["refit_ari"] = 1.0
            if rep.startswith(("gmm", "hmm")):                 # hard states (grid, k-means) have no probability to grade
                conf_tr, conf_te = P_tr.max(1), P_te.max(1)
                q1, q2 = np.percentile(conf_tr, [100 / 3, 200 / 3])
                out[rep + "_conf"] = np.where(conf_te <= q1, 0, np.where(conf_te <= q2, 1, 2))
            with np.errstate(invalid="ignore", divide="ignore"):
                ent = -(P_te * np.log(np.maximum(P_te, 1e-12))).sum(1) / np.log(m.K)
            out[rep + "_entropy"] = ent
            out[rep + "_state"] = lab_te
            models[rep] = m
            cards[rep] = {"tab": tab, "cnt": cnt, "pooled": pooled, "share": sh_tr,
                          "zmean": (P_tr.T @ prep.z(tr[E.FEATURES].to_numpy(float))) / np.maximum(P_tr.sum(0), 1e-9)[:, None]}
        # predictions = R0 + the state's deviation; the economic context uses training cut-offs
        out[rep + "_up"] = np.clip(b_te[:, 0] + np.nan_to_num(pred[:, 0]), 0.01, 0.99)
        out[rep + "_ret"] = np.nan_to_num(pred[:, 1])
        out[rep + "_rng"] = b_te[:, 2] + np.nan_to_num(pred[:, 2])
        if dev_tr is None:
            ms = [tr["sym"].to_numpy() == s for s in range(n_sym)]
            dev_tr = np.full((len(tr), len(TARGETS)), np.nan)
            sub = np.random.default_rng(seed).random(len(tr)) < min(1.0, 20000 / max(len(tr), 1))
            for s in range(n_sym):
                mm = ms[s] & sub
                if mm.any():
                    dev_tr[mm] = EM.knn_predict(Ztr[ms[s]], Dtr[ms[s]], Ztr[mm], int(CFG["knn_k"]) + 1, lam)
        q = float(CFG["econ_quantile"])
        lo, hi = np.nanpercentile(dev_tr[:, 1], [100 * q, 100 * (1 - q)])
        out[rep + "_side"] = np.where(out[rep + "_ret"] >= hi, 1, np.where(out[rep + "_ret"] <= lo, -1, 0))
        rows.append(r)
        log(f"    fold {f + 1} {rep}: fit {r['fit_s']:.1f} s" + (f", seed ARI {r['seed_ari']:.2f}" if "seed_ari" in r else ""))
    return out, rows, models, cards


# ----------------------------------------------------------------------
# pooled out-of-sample metrics
# ----------------------------------------------------------------------
def _boot_idx(n: int) -> np.ndarray:
    return BM._block_idx(n, int(CFG["boot_B"]), int(CFG["boot_block"]), np.random.default_rng(int(CFG["seed"])))


def _p_one_sided(stat: float, boots: np.ndarray) -> float:
    """(1 + resamples with stat* - stat >= stat) / (1 + B): how often a world whose true value is zero shows this much."""
    if not np.isfinite(stat):
        return np.nan
    return float((1 + np.sum(boots - stat >= stat)) / (1 + len(boots)))


def _spearman(x: np.ndarray, y: np.ndarray) -> float:
    rx, ry = pd.Series(x).rank().to_numpy(float), pd.Series(y).rank().to_numpy(float)
    rx, ry = rx - rx.mean(), ry - ry.mean()
    den = np.sqrt((rx ** 2).sum() * (ry ** 2).sum())
    return float(rx @ ry / den) if den > 0 else np.nan


def skill_stats(e1: np.ndarray, e0: np.ndarray, idx: np.ndarray) -> Tuple[float, float, float, float, np.ndarray]:
    """1 - sum(e1) / sum(e0) over days, its 95% day-block bootstrap interval, one-sided p and the resampled values."""
    s0 = e0.sum()
    sk = 1 - e1.sum() / s0 if s0 > 0 else np.nan
    bs = 1 - e1[idx].sum(1) / np.maximum(e0[idx].sum(1), 1e-300)
    lo, hi = np.percentile(bs, [2.5, 97.5])
    return float(sk), float(lo), float(hi), _p_one_sided(sk, bs), bs


def evaluate(P: pd.DataFrame) -> Tuple[pd.DataFrame, dict]:
    """Pooled walk-forward test metrics per representation (one row each) and the bootstrap draws for comparisons."""
    days = np.sort(P["day"].unique())
    di = np.searchsorted(days, P["day"].to_numpy())
    nd = len(days)
    idx = _boot_idx(nd)
    yu, yr, yg = P["y_up"].to_numpy(float), P["y_ret"].to_numpy(float), P["y_rng"].to_numpy(float)
    yd = yr - P["b_y_ret"].to_numpy(float)
    kk = P["k"].to_numpy(int)
    res_u = np.isfinite(yu)
    fin_g = np.isfinite(yg)
    per_day = lambda v, m: np.bincount(di[m], weights=v[m], minlength=nd)
    e0u = per_day((yu - P["b_y_up"].to_numpy(float)) ** 2, res_u)
    e0g = per_day((yg - P["b_y_rng"].to_numpy(float)) ** 2, fin_g)
    rows, draws = [], {}
    for rep in REPS:
        pu = P[rep + "_up"].to_numpy(float)
        e1u = per_day((yu - pu) ** 2, res_u)
        e1g = per_day((yg - P[rep + "_rng"].to_numpy(float)) ** 2, fin_g)
        bs_, lo_, hi_, p_, bsd = skill_stats(e1u, e0u, idx)
        gs, glo, ghi, gp, _ = skill_stats(e1g, e0g, idx)
        draws[rep] = bsd
        # rank IC across stocks at each decision time (never across the decision times of a session: their next-hour
        # windows overlap what later decisions already know), averaged per test session
        pr = P[rep + "_ret"].to_numpy(float)
        ic = np.full(nd, np.nan)
        okr = np.isfinite(yr)
        cs_ic = []
        for (j, _), g in pd.DataFrame({"di": di[okr], "k": kk[okr], "i": np.flatnonzero(okr)}).groupby(["di", "k"], sort=True):
            sel = g["i"].to_numpy()
            if len(sel) >= int(CFG["ic_min_obs"]) and np.ptp(pr[sel]) > 0:
                cs_ic.append((j, _spearman(pr[sel], yd[sel])))
        if cs_ic:
            cj, cv = np.array([c[0] for c in cs_ic]), np.array([c[1] for c in cs_ic], float)
            fin = np.isfinite(cv)
            n_c = np.bincount(cj[fin], minlength=nd)
            ic = np.where(n_c > 0, np.bincount(cj[fin], weights=cv[fin], minlength=nd) / np.maximum(n_c, 1), np.nan)
        icv = ic[np.isfinite(ic)]
        if len(icv) >= 20:
            ii = _boot_idx(len(icv))
            icb = icv[ii].mean(1)
            ic_m, (ic_lo, ic_hi), ic_p = float(icv.mean()), np.percentile(icb, [2.5, 97.5]), _p_one_sided(float(icv.mean()), icb)
        else:
            ic_m, ic_lo, ic_hi, ic_p = np.nan, np.nan, np.nan, np.nan
        # calibration and log loss of y_up
        y, p = yu[res_u], pu[res_u]
        p0 = P["b_y_up"].to_numpy(float)[res_u]
        ll = -np.mean(y * np.log(p) + (1 - y) * np.log(1 - p))
        ll0 = -np.mean(y * np.log(np.clip(p0, 0.01, 0.99)) + (1 - y) * np.log(1 - np.clip(p0, 0.01, 0.99)))
        bins = np.clip((p * 10).astype(int), 0, 9)
        n_b = np.bincount(bins, minlength=10)
        ece = float(sum(n_b[b] / len(p) * abs(p[bins == b].mean() - y[bins == b].mean()) for b in range(10) if n_b[b]))
        # economic context: with the prediction in the training top fifth, against it in the bottom fifth (gross bp)
        side = P[rep + "_side"].to_numpy(int)
        tk = (side != 0) & okr
        gross = side[tk] * yr[tk] * P["atr"].to_numpy(float)[tk] * 1e4
        r = {"rep": rep, "states": n_states(rep), "brier_skill": bs_, "brier_lo": lo_, "brier_hi": hi_, "brier_p": p_,
             "ic": ic_m, "ic_lo": float(ic_lo), "ic_hi": float(ic_hi), "ic_p": ic_p, "ic_days": int(len(icv)),
             "mag_skill": gs, "mag_lo": glo, "mag_hi": ghi, "mag_p": gp, "logloss": float(ll), "logloss_r0": float(ll0),
             "brier": float(e1u.sum() / res_u.sum()), "brier_r0": float(e0u.sum() / res_u.sum()), "ece": ece,
             "gross_bp": float(gross.mean()) if len(gross) else np.nan, "gross_n": int(len(gross)),
             "test_days": nd, "test_rows": int(len(P)), "resolved_up": int(res_u.sum())}
        # skill by state-confidence tercile and by novelty
        if rep + "_conf" in P.columns:
            cf = P[rep + "_conf"].to_numpy()
            for t, nm in enumerate(("low", "mid", "high")):
                m = res_u & (cf == t)
                r[f"conf_{nm}_n"] = int(m.sum())
                r[f"conf_{nm}_skill"] = float(1 - ((yu[m] - pu[m]) ** 2).sum() / ((yu[m] - P["b_y_up"].to_numpy(float)[m]) ** 2).sum()) if m.sum() > 50 else np.nan
        if rep + "_novel" in P.columns:
            nv = P[rep + "_novel"].to_numpy(bool)
            r["novel_share"] = float(nv.mean())
            m = res_u & nv
            r["novel_skill"] = float(1 - ((yu[m] - pu[m]) ** 2).sum() / ((yu[m] - P["b_y_up"].to_numpy(float)[m]) ** 2).sum()) if m.sum() > 50 else np.nan
        rows.append(r)
    R = pd.DataFrame(rows)
    return R, draws


def holm(p: np.ndarray) -> np.ndarray:
    p = np.where(np.isfinite(p), p, 1.0)
    m = len(p)
    o = np.argsort(p, kind="stable")
    adj = np.maximum.accumulate(np.minimum(1.0, (m - np.arange(m)) * p[o]))
    out = np.empty(m)
    out[o] = adj
    return out


def verdict(R: pd.DataFrame, FR: pd.DataFrame, draws: dict) -> Tuple[pd.DataFrame, str, Optional[str], List[str]]:
    """The declared gate: informative on direction (Holm over representations x 2 metrics), magnitude, stable;
    the stage verdict and the preferred representation."""
    a = float(CFG["alpha"])
    ph = holm(np.r_[R["brier_p"].to_numpy(float), R["ic_p"].to_numpy(float)])
    n = len(R)
    R["brier_p_holm"], R["ic_p_holm"] = ph[:n], ph[n:]
    R["mag_p_holm"] = holm(R["mag_p"].to_numpy(float))
    R["informative"] = ((R["brier_p_holm"] <= a) & (R["brier_lo"] > 0)) | ((R["ic_p_holm"] <= a) & (R["ic_lo"] > 0))
    R["magnitude"] = (R["mag_p_holm"] <= a) & (R["mag_lo"] > 0)
    g = FR.groupby("rep")
    st = pd.DataFrame({"seed_ari": g["seed_ari"].mean() if "seed_ari" in FR else np.nan,
                       "refit_ari": g["refit_ari"].mean() if "refit_ari" in FR else np.nan,
                       "psi_median": g["psi"].median() if "psi" in FR else np.nan,
                       "persist": g["persist"].mean() if "persist" in FR else np.nan,
                       "persist_chance": g["persist_chance"].mean() if "persist_chance" in FR else np.nan,
                       "fit_s": g["fit_s"].mean()})
    R = R.merge(st, left_on="rep", right_index=True, how="left")
    R["stable"] = (R["states"] > 0) & (R["seed_ari"] >= CFG["stable_seed_ari"]) & (R["refit_ari"] >= CFG["stable_refit_ari"]) & \
                  (R["psi_median"] <= CFG["stable_psi"])
    R["simplicity"] = R["rep"].map(SIMPLICITY)
    ok = R[R["informative"] & R["stable"]]
    notes = []
    preferred = None
    if len(ok):
        best = ok.sort_values("brier_skill", ascending=False).iloc[0]["rep"]
        for _, row in ok.sort_values("simplicity").iterrows():
            diff = draws[row["rep"]] - draws[best]
            if row["rep"] == best or np.percentile(diff, 97.5) >= 0:
                preferred = row["rep"]
                break
        v = "STATES INFORMATIVE"
    elif (R["magnitude"] & R["stable"]).any():
        v = "VOLATILITY ONLY"
    else:
        v = "NOTHING BEYOND BASELINE"
    knn = R[R["rep"].str.startswith("knn")]
    if len(knn) and bool(knn["informative"].any()) and v != "STATES INFORMATIVE":
        notes.append("the nearest-neighbour analogues ARE informative on direction while no stable state representation is: "
                     "there is information these states do not capture")
    inf_unstable = R[R["informative"] & ~R["stable"] & (R["states"] > 0)]["rep"].tolist()
    if inf_unstable:
        notes.append(f"informative but not stable (states do not recur reliably): {', '.join(inf_unstable)}")
    return R, v, preferred, notes


# ----------------------------------------------------------------------
# report
# ----------------------------------------------------------------------
def _f(x, d=3) -> str:
    return "-" if x is None or not np.isfinite(x) else f"{x:+.{d}f}"


def _u(x, d=2) -> str:
    return "-" if x is None or not np.isfinite(x) else f"{x:.{d}f}"


def _ci(m, lo, hi, d=3) -> str:
    return f"{_f(m, d)} [{_f(lo, d)}, {_f(hi, d)}]"


VERDICT_TEXT = {
    "STATES INFORMATIVE": "Learned states carry out-of-sample information about which way the price goes next, beyond each "
                          "stock's own time-of-day behaviour, and they are stable. This earns Stage C (confidence and evidence) "
                          "for the representations marked below. It is NOT evidence of a profitable trade.",
    "VOLATILITY ONLY": "States predict how MUCH the price moves next, but not which WAY, out of sample. Stop here: whether "
                       "magnitude alone (stops, sizing, no-trade filters) is worth a Stage C is Karan's decision.",
    "NOTHING BEYOND BASELINE": "No state representation predicts what happens next better than each stock's own time-of-day "
                               "behaviour, out of sample. Stop and reassess the research question; the declaration is not "
                               "changed to get a pass.",
}


def write_report(out: Path, R: pd.DataFrame, FR: pd.DataFrame, P: pd.DataFrame, cards: dict, v: str, preferred: Optional[str],
                 notes: List[str], info: dict, stocks: list) -> None:
    L = [f"# Stage B - behavioural state discovery", "",
         f"{CODE_VERSION} | {E.CODE_VERSION} | declaration {E.DECL_SHA} | {info['at']} | stocks {', '.join(s for s, _ in stocks)} "
         f"(list {info['stocks_hash']}) | development {CFG['dev_start']}..{CFG['dev_end']}; nothing later is read" +
         (f" | **RERUN #{len(info['rerun']) + 1}** (earlier: {', '.join(info['rerun'])}) - not fresh evidence" if info["rerun"] else ""), "",
         f"## VERDICT: {v}", "", VERDICT_TEXT[v], ""]
    if preferred:
        L += [f"Preferred representation (the simplest informative and stable one not significantly worse than the best): **{preferred}**.", ""]
    for nt in notes:
        L.append(f"Note: {nt}.")
    if notes:
        L.append("")
    L += ["In plain words: 'Brier skill' is how much better the state predicts which barrier (+0.3 ATR or -0.3 ATR) is hit "
          "first than the stock's own time-of-day rate does (0 = no better; 0.01 = 1% lower squared error). 'IC' is the rank "
          "correlation, across the stocks at the same decision time, between the predicted and the actual next-hour return "
          "(both relative to the stock's time-of-day baseline), averaged per session. 'Magnitude' is the same "
          "skill for how far the price ranges in the next hour. All are pooled over the 5 test windows, which the models "
          "never saw; [ ] = 95% block-bootstrap interval over test sessions; Holm p corrects for the 16 direction tests.", "",
          "| representation | states | Brier skill | Holm p | IC | Holm p | magnitude skill | seed ARI | refit ARI | PSI | persist (chance) | ECE | gross bp, n | fit s | informative | stable |",
          "|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in R.iterrows():
        L.append(f"| {r['rep']} | {r['states'] or '-'} | {_ci(r['brier_skill'], r['brier_lo'], r['brier_hi'], 4)} | {_u(r['brier_p_holm'], 3)} | "
                 f"{_ci(r['ic'], r['ic_lo'], r['ic_hi'], 3)} | {_u(r['ic_p_holm'], 3)} | {_ci(r['mag_skill'], r['mag_lo'], r['mag_hi'], 3)} | "
                 f"{_u(r['seed_ari'])} | {_u(r['refit_ari'])} | {_u(r['psi_median'], 3)} | {_u(r['persist'])} ({_u(r['persist_chance'])}) | "
                 f"{_u(r['ece'], 3)} | {_f(r['gross_bp'], 1)}, {r['gross_n']:,} | {_u(r['fit_s'], 1)} | {'YES' if r['informative'] else 'no'} | "
                 f"{'YES' if r['stable'] else ('n/a' if r['states'] == 0 else 'no')} |")
    L += ["", f"Reading the columns: seed ARI = agreement of two fits with different random starts (1 = the same states); refit ARI = "
          f"agreement of the previous window's model with this window's on the same test data; PSI = how much the states' shares "
          f"move from training to test (under {CFG['stable_psi']} is stable); persist = how often the state at one decision is "
          f"the same 15 minutes later (vs chance); ECE = calibration error of the predicted barrier probability; gross bp = "
          f"average gross return per observation of going with the prediction when it is in the training top fifth and against "
          f"it in the bottom fifth, 60-minute exit, NO costs - compare with {E.TRADE_COST_BPS:.2f} bp per trade. It is "
          f"context, not a strategy and not a gate.", ""]
    show = preferred or R.sort_values("brier_skill", ascending=False).iloc[0]["rep"]
    # state confidence vs prediction
    L += [f"## State confidence is not trade confidence ({show})", "",
          "Brier skill of the barrier prediction by state-confidence tercile (top state probability; training cut-offs), and on "
          "observations unlike the training data (novel: beyond its 1st percentile of likelihood / distance).", "",
          "| representation | low-confidence skill (n) | mid | high | novel share | novel skill |", "|---|---|---|---|---|---|"]
    for _, r in R[R["rep"].str.startswith(("gmm", "hmm", "kmeans"))].iterrows():
        if not r["rep"].startswith(("gmm", "hmm")):
            L.append(f"| {r['rep']} | hard states: no probability to grade | | | {_u(r.get('novel_share', np.nan), 3)} | {_f(r.get('novel_skill', np.nan), 4)} |")
            continue
        L.append(f"| {r['rep']} | {_f(r.get('conf_low_skill'), 4)} ({int(r.get('conf_low_n', 0) or 0):,}) | {_f(r.get('conf_mid_skill'), 4)} "
                 f"({int(r.get('conf_mid_n', 0) or 0):,}) | {_f(r.get('conf_high_skill'), 4)} ({int(r.get('conf_high_n', 0) or 0):,}) | "
                 f"{_u(r.get('novel_share', np.nan), 3)} | {_f(r.get('novel_skill', np.nan), 4)} |")
    # calibration of the shown representation
    pu, yu = P[show + "_up"].to_numpy(float), P["y_up"].to_numpy(float)
    m = np.isfinite(yu)
    bins = np.clip((pu[m] * 10).astype(int), 0, 9)
    L += ["", f"## Calibration of the predicted barrier probability ({show}, all test windows)", "",
          "| predicted | n | mean predicted | observed |", "|---|---|---|---|"]
    for b in range(10):
        s = bins == b
        if s.sum():
            L.append(f"| {b / 10:.1f}-{(b + 1) / 10:.1f} | {int(s.sum()):,} | {pu[m][s].mean():.3f} | {yu[m][s].mean():.3f} |")
    rr = R.set_index("rep").loc[show]
    L += ["", f"Brier {rr['brier']:.4f} vs R0 {rr['brier_r0']:.4f}; log loss {rr['logloss']:.4f} vs R0 {rr['logloss_r0']:.4f}; "
          f"ECE {rr['ece']:.3f}. These probabilities are the state's average outcome on past data, shrunk; they are NOT yet "
          f"calibrated probabilities (that is Stage C, on a separate slice).", ""]
    # state cards
    if show in cards:
        c = cards[show]
        L += [f"## State cards ({show}, last fold's model, training window)", "",
              "Each state's share of training decisions and the 4 features furthest from typical (robust z, + = above usual). "
              "Outcome columns: the pooled shrunk deviation from the time-of-day baseline (barrier probability in points, "
              "next-hour return in ATR).", "", "| state | share | what it looks like | barrier prob. dev. | next-hour ret dev. (ATR) |",
              "|---|---|---|---|---|"]
        for k in range(len(c["share"])):
            z = c["zmean"][k]
            top = np.argsort(-np.abs(z))[:4]
            look = ", ".join(f"{E.FEATURES[j]} {z[j]:+.1f}" for j in top)
            L.append(f"| {k} | {c['share'][k]:.3f} | {look} | {c['pooled'][k, 0]:+.4f} | {c['pooled'][k, 1]:+.4f} |")
    L += ["", "## Per fold", "", "| fold | train | test | representation | test rows | seed ARI | refit ARI | PSI | fit s |", "|---|---|---|---|---|---|---|---|---|"]
    folds = CFG["folds"]
    for _, r in FR.iterrows():
        fo = folds[int(r["fold"])]
        L.append(f"| {int(r['fold']) + 1} | {fo[0]}..{fo[1]} | {fo[2]}..{fo[3]} | {r['rep']} | {int(r['test_rows']):,} | {_u(r.get('seed_ari', np.nan))} | "
                 f"{_u(r.get('refit_ari', np.nan))} | {_u(r.get('psi', np.nan), 3)} | {_u(r['fit_s'], 1)} |")
    L += ["", "## Data", ""]
    for sym, d in info["panel"]["stocks"].items():
        if "error" in d:
            L.append(f"- {sym}: LEFT OUT ({d['error']})")
        else:
            L.append(f"- {sym}{' (' + d['sector'] + ')' if d.get('sector') else ''}: {d['clean_dev']:,} clean of {d['sessions_dev']:,} "
                     f"development sessions; {d['decisions']:,} decision points; barrier resolved {d['y_up_resolved'] * 100:.1f}% "
                     f"({d['y_up_same_bar']:,} hit both barriers inside one bar - order unknown, left out)")
    L += ["", "## Limitations (stated before the run)", "",
          "- In-sample to the project: 2021-10..2024-12 was already searched by BIGMOVE discovery and Stage 0. The walk-forward "
          "test windows are out of sample for these models only.",
          "- Decision points 15 minutes apart with 60-minute outcomes overlap; the bootstrap resamples whole sessions in blocks "
          "of 10, which keeps that overlap inside each resample.",
          "- Information is not money: a state can predict direction a little and still lose after 12.49 bp a trade. Stage B "
          "prices nothing.",
          f"- Experiments: this run adds {len(R)} representations to experiments.jsonl (cumulative count {info['experiments_total']}); "
          f"prior research before the engine: {E.DECL['data_exposure_audit']['cumulative_prior_trials']}.", ""]
    (out / "report.md").write_text("\n".join(L), encoding="utf-8")


# ----------------------------------------------------------------------
# run
# ----------------------------------------------------------------------
def previous_runs(root: Path, stocks_hash: str) -> List[str]:
    f = root / "panel" / "research_ledger.jsonl"
    out = []
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if rec.get("family") == E.DECL["family_id"] and rec.get("stage") == "B" and rec.get("declaration") == E.DECL_SHA \
                    and rec.get("stocks_hash") == stocks_hash:
                out.append(str(rec.get("run")))
    return out


def run(root: Path, stocks: List[Tuple[str, Optional[str]]], dq, IC, reconcile, log=_log) -> Tuple[Path, str]:
    E.check_reuse()
    sh = E.stocks_hash(stocks)
    prev_runs = previous_runs(root, sh)
    log(f"{CODE_VERSION} (declaration {E.DECL_SHA}): {len(stocks)} stocks; development {CFG['dev_start']}..{CFG['dev_end']}; "
        f"{len(REPS)} representations x {len(CFG['folds'])} folds")
    if len(stocks) != 10:
        log(f"  NOTE: {len(stocks)} stocks listed, the engine is declared for 10")
    if prev_runs:
        log(f"  WARNING: RERUN #{len(prev_runs) + 1} for this declaration and stock list (earlier: {', '.join(prev_runs)}) - not fresh evidence")
    obs, pinfo = load_panel(root, stocks, dq, IC, reconcile, log)
    log(f"  {len(obs):,} decision points over {obs['day'].nunique():,} sessions")
    parts, frows, prev, cards = [], [], {}, {}
    for f, fold in enumerate(CFG["folds"]):
        log(f"  fold {f + 1}: train {fold[0]}..{fold[1]}, test {fold[2]}..{fold[3]}")
        Pf, rows, prev_new, cards_f = run_fold(obs, f, fold, prev, log)
        if len(Pf):
            parts.append(Pf)
            frows += rows
            prev = prev_new
            cards = cards_f
    P = pd.concat(parts, ignore_index=True)
    FR = pd.DataFrame(frows)
    R, draws = evaluate(P)
    R, v, preferred, notes = verdict(R, FR, draws)
    base = root / "research2" / "engine"
    base.mkdir(parents=True, exist_ok=True)
    day = dt.date.today().strftime("%Y%m%d")
    n = 1
    while (base / f"B_{day}_{n:03d}").exists():
        n += 1
    out = base / f"B_{day}_{n:03d}"
    out.mkdir()
    ex = base / "experiments.jsonl"
    n_before = sum(1 for _ in ex.open(encoding="utf-8")) if ex.exists() else 0
    info = {"at": f"{dt.datetime.now():%Y-%m-%d %H:%M}", "stocks_hash": sh, "rerun": prev_runs, "panel": pinfo,
            "experiments_total": n_before + len(R)}
    write_report(out, R, FR, P, cards, v, preferred, notes, info, stocks)
    R.to_csv(out / "representations.csv", index=False)
    FR.to_csv(out / "folds.csv", index=False)
    cal = []
    for rep in REPS:
        pu, yu = P[rep + "_up"].to_numpy(float), P["y_up"].to_numpy(float)
        m = np.isfinite(yu)
        b = np.clip((pu[m] * 10).astype(int), 0, 9)
        for j in range(10):
            s = b == j
            if s.sum():
                cal.append({"rep": rep, "bin": j, "n": int(s.sum()), "predicted": float(pu[m][s].mean()), "observed": float(yu[m][s].mean())})
    pd.DataFrame(cal).to_csv(out / "calibration.csv", index=False)
    srows = []
    for rep, c in cards.items():
        for k in range(len(c["share"])):
            z = c["zmean"][k]
            srows.append({"rep": rep, "state": k, "share": c["share"][k], "dev_up": c["pooled"][k, 0], "dev_ret": c["pooled"][k, 1],
                          "dev_rng": c["pooled"][k, 2], **{"z_" + E.FEATURES[j]: z[j] for j in range(len(E.FEATURES))}})
    pd.DataFrame(srows).to_csv(out / "states.csv", index=False)
    summ = {"tool": CODE_VERSION, "core": E.CODE_VERSION, "features": E.FEATURE_VERSION, "declaration": E.DECL_SHA, "verdict": v,
            "preferred": preferred, "notes": notes, "stocks": stocks, "stocks_hash": sh, "rerun_of": prev_runs,
            "periods": {"development": [CFG["dev_start"], CFG["dev_end"]], "folds": CFG["folds"]}, "panel": pinfo,
            "representations": json.loads(R.to_json(orient="records"))}
    (out / "summary.json").write_text(json.dumps(summ, indent=2, default=str), encoding="utf-8")
    h = hashlib.sha256(pd.util.hash_pandas_object(obs[["sym", "k"] + E.FEATURES + E.OUTCOMES], index=False).to_numpy().tobytes())
    h.update(np.asarray(pd.DatetimeIndex(obs["day"]).asi8).tobytes())
    try:
        import pyarrow
        pa_v = pyarrow.__version__
    except Exception:
        pa_v = None
    prov = {"tool": CODE_VERSION, "declaration": E.DECL_SHA, "data_fingerprint": h.hexdigest()[:16],
            "code_sha256_16": {**{p: BM._sha_path(HERE / p) for p in ("engine_stage_b.py", "engine_core.py", "engine_models.py")},
                              "bigmove_study.py": BM._sha_path(BM.__file__)},
            "python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__, "pyarrow": pa_v,
            "platform": platform.platform(), "seed": CFG["seed"]}
    BM.seal_outputs(out, prov)
    cfg_hash = hashlib.sha256(json.dumps(CFG, sort_keys=True).encode()).hexdigest()[:16]
    with ex.open("a", encoding="utf-8") as fh:
        for j, r in R.iterrows():
            fh.write(json.dumps({"n": n_before + j + 1, "at": dt.datetime.now().isoformat(), "stage": "B", "run": out.name,
                                 "declaration": E.DECL_SHA, "stocks_hash": sh, "rerun": bool(prev_runs),
                                 "hypothesis": f"{r['rep']} states carry out-of-sample information on y_up / y_ret beyond the stock's time-of-day baseline",
                                 "representation": r["rep"], "features": E.FEATURE_VERSION, "config_hash": cfg_hash,
                                 "periods": {"folds": CFG["folds"]}, "costs": "none (Stage B prices nothing)",
                                 "results": {k: r[k] for k in ("brier_skill", "brier_lo", "brier_p_holm", "ic", "ic_lo", "ic_p_holm",
                                                               "mag_skill", "mag_lo", "seed_ari", "refit_ari", "psi_median", "gross_bp")},
                                 "informative": bool(r["informative"]), "stable": bool(r["stable"]),
                                 "rejected_because": None if (r["informative"] and r["stable"]) else
                                 ("not informative on direction" if not r["informative"] else "not stable")}, default=float) + "\n")
    BM.write_ledger(root, {"kind": "stage", "tool": CODE_VERSION, "family": E.DECL["family_id"], "stage": "B", "declaration": E.DECL_SHA,
                           "run": out.name, "stocks": [s for s, _ in stocks], "stocks_hash": sh, "trials": len(R),
                           "periods": {"development": [CFG["dev_start"], CFG["dev_end"]]}, "post_2024_used": False,
                           "fresh": not prev_runs, "previous_runs": prev_runs, "verdict": v, "preferred": preferred})
    return out, v


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Stage B: behavioural state discovery (no strategy)")
    ap.add_argument("--root", required=True)
    ap.add_argument("--stocks", default=str(HERE / "engine_stocks.txt"))
    a = ap.parse_args(argv)
    root = Path(a.root)
    if not root.is_dir():
        raise E.PreconditionError(f"--root {root} is not a folder - run 'call env_daily.bat' and pass --root %CACHE_DAILY_ROOT%")
    stocks = E.read_stocks(Path(a.stocks))
    import data_quality as dq
    import intraday_cache as IC
    tol_p, tol_v = IC.DECL["reconcile_price_tol"], IC.DECL["reconcile_volume_tol"]
    reconcile = lambda Xg, d: IC.reconcile_symbol(Xg, d, tol_p, tol_v)
    t0 = time.time()
    out, v = run(root, stocks, dq, IC, reconcile)
    _log(f"VERDICT: {v}  ({time.time() - t0:.0f} s)")
    print(f"  report: {out / 'report.md'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
