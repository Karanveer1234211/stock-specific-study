#!/usr/bin/env python3
"""
tests/test_engine.py - the behavioural engine's synthetic test suite (engine_core, engine_models, engine_stage_a,
engine_stage_b). No real data. Prints VERIFIED on success.

 1. BY HAND: costs; decision bars; the stock list; the session grid; daily context = the previous close only; weekly
    context = completed weeks only (changing Wednesday and later leaves a Wednesday's weekly features alone); split-like
    ratios; intraday features on a hand-built session; entry at the next bar's open (a missing bar -> the one after);
    the barrier race (up first, down first, both inside one bar = unknown); the 60-minute return.
 2. LOOK-AHEAD: on a synthetic stock, scrambling everything after a decision (the session's later bars, its daily row,
    every later day, NIFTY and the sector index too) changes no feature at or before it, on 40 random days; three planted
    leaks are caught (a VWAP over the whole session, daily context not shifted, weekly context that includes the current
    week); HMM filtered probabilities ignore later observations; a fold's models do not change when its test window
    changes.
 3. MODELS: k-means and the Gaussian mixture recover planted clusters; the HMM recovers a sticky two-state chain; ARI and
    PSI behave; shrinkage pulls thin stock-states to the pooled value and thin pooled states to zero.
 4. STAGE B WORLDS (6 stocks, 2021-09..2025-03, 5 walk-forward folds):
      PLANTED  trend and VWAP-reversion regimes with a moderate drift -> STATES INFORMATIVE
      NONE x2  the same regimes' volatility and volume, no drift -> no representation informative on direction
 5. STAGE A: a clean market passes; planted defects are each found exactly (duplicates, off-grid rows, a holiday session,
    a missing session, a short session, high below the body, a 3-minute file on an old split basis, an unadjusted split in
    a daily file, a UTC-zoned file that must NOT be a defect).
 6. GLUE: both main() functions with stand-in data_quality / intraday_cache modules write only research2\\engine\\ plus
    ledger lines; Stage B run twice with every 2025 bar and daily row changed gives identical results and the second is
    stamped RERUN.
"""

from __future__ import annotations

import contextlib
import io
import json
import shutil
import sys
import tempfile
import time
import types
from pathlib import Path

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent))           # open_close
sys.path.insert(0, str(HERE))
sys.path.append(str(HERE.parent.parent))       # bigmove_deploy (PYTHONPATH should already have it)

import engine_core as E                        # noqa: E402
import engine_models as EM                     # noqa: E402
import engine_stage_a as SA                    # noqa: E402
import engine_stage_b as SB                    # noqa: E402
from engine_world import World, reconcile_like_ic, calendar   # noqa: E402

BM = E.BM
NB = E.NB
FAILS = []


def check(cond, msg):
    print(("  ok  " if cond else "  FAIL") + f"  {msg}", flush=True)
    if not cond:
        FAILS.append(msg)


def with_day(d: pd.DataFrame) -> pd.DataFrame:
    d = d.copy()
    d["day"] = pd.to_datetime(d["timestamp"]).dt.normalize()
    return d


# ----------------------------------------------------------------------
# 1. by hand
# ----------------------------------------------------------------------
def flat_session(day, p=100.0, v=40000.0):
    ts = pd.Timestamp(day) + pd.to_timedelta(555 + 3 * np.arange(NB), unit="m")
    return pd.DataFrame({"timestamp": ts, "open": p, "high": p * 1.005, "low": p * 0.995, "close": p, "volume": v})


def daily_from_bars(X: pd.DataFrame) -> pd.DataFrame:
    """Daily rows as the exchange makes them: first open, high, low, the 15:00-15:30 VWAP as the close, total volume."""
    day = X["timestamp"].dt.normalize()
    g = X.groupby(day)
    late = X[X["timestamp"].dt.hour >= 15]
    tp = (late["high"] + late["low"] + late["close"]) / 3
    vw = (tp * late["volume"]).groupby(late["timestamp"].dt.normalize()).sum() / late["volume"].groupby(late["timestamp"].dt.normalize()).sum()
    return pd.DataFrame({"timestamp": g["open"].first().index, "open": g["open"].first().to_numpy(), "high": g["high"].max().to_numpy(),
                         "low": g["low"].min().to_numpy(), "close": vw.reindex(g["open"].first().index).to_numpy(),
                         "volume": g["volume"].sum().to_numpy()})


def by_hand():
    print("1. by hand")
    check(abs(E.TRADE_COST_BPS - 12.49) < 0.01, f"cost a time-exit trade = {E.TRADE_COST_BPS:.3f} bp")
    check(list(E.DEC_BARS) == list(range(4, 105, 5)) and E.E_LAST == 105 and E.X_BAR == 116,
          "decisions at the close of bars 4, 9, ..., 104 (09:30-14:30); last entry the 14:30 bar; time exit 15:03")
    tmp = Path(tempfile.mkdtemp())
    try:
        f = tmp / "s.txt"
        f.write_text("# my ten\nhdfcbank, NIFTY BANK\nINFY,nifty it\nRELIANCE\n\n", encoding="utf-8")
        st = E.read_stocks(f)
        check(st == [("HDFCBANK", "NIFTY BANK"), ("INFY", "NIFTY IT"), ("RELIANCE", None)], f"stock list read: {st}")
        f.write_text("A\nA\n", encoding="utf-8")
        try:
            E.read_stocks(f)
            check(False, "a stock listed twice is refused")
        except SystemExit:
            check(True, "a stock listed twice is refused")
        f.write_text("A, NIFTY PHARMA\n", encoding="utf-8")
        try:
            E.read_stocks(f)
            check(False, "an unknown sector index is refused")
        except SystemExit:
            check(True, "an unknown sector index is refused")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)
    # the grid
    X = flat_session("2022-03-02")
    extra = pd.DataFrame({"timestamp": pd.DatetimeIndex([pd.Timestamp(x) for x in ("2022-03-02 09:16", "2022-03-02 15:30", "2022-03-05 10:00", "2022-03-02 09:18:30")]),
                          "open": 1.0, "high": 1.0, "low": 1.0, "close": 1.0, "volume": 1.0})
    dup = X.iloc[[10]].assign(close=111.0)
    G = E.grid_bars(pd.concat([X, extra, dup], ignore_index=True))
    check(len(G) == NB and float(G.loc[G["timestamp"] == X["timestamp"].iloc[10], "close"].iloc[0]) == 111.0,
          "grid keeps the 125 session bars, drops off-grid / after 15:27 / weekend / seconds rows, keeps the last duplicate")
    # daily context
    days = calendar("2022-01-03", "2022-06-30")
    rng = np.random.default_rng(3)
    c = 100 * np.exp(np.cumsum(rng.normal(0, 0.01, len(days))))
    d = pd.DataFrame({"timestamp": days, "open": c * 0.999, "high": c * 1.01, "low": c * 0.99, "close": c, "volume": 1e6})
    d = with_day(d)
    ctx = E.daily_context(d)
    t = 60
    check(ctx["pdc"].iloc[t] == d["close"].iloc[t - 1] and ctx["pdh"].iloc[t] == d["high"].iloc[t - 1],
          "daily context of day t = the previous row's close / high")
    tr = np.maximum(d["high"] - d["low"], np.maximum((d["high"] - d["close"].shift(1)).abs(), (d["low"] - d["close"].shift(1)).abs()))
    tr.iloc[0] = d["high"].iloc[0] - d["low"].iloc[0]
    a = np.nan
    for j in range(len(d) - 1):                                   # through the previous row only
        a = tr.iloc[j] if j == 0 else (a * 13 + tr.iloc[j]) / 14
    check(abs(ctx["atr"].iloc[-1] - a / d["close"].iloc[-2]) < 1e-12 and np.isnan(ctx["atr"].iloc[13]) and np.isfinite(ctx["atr"].iloc[14]),
          "ATR of day t = Wilder 14-session ATR through day t-1 as a fraction of t-1's close; known from the 15th session")
    wd = pd.DatetimeIndex(d["day"])
    wed = np.flatnonzero((wd.weekday == 2) & (np.arange(len(d)) > 80))[0]
    d2 = d.copy()
    d2.loc[wed:, ["open", "high", "low", "close"]] *= 1.37
    c2 = E.daily_context(d2)
    same = all(np.isclose(ctx[col].iloc[wed], c2[col].iloc[wed], equal_nan=True) for col in E.WEEKLY_COLS + ["w_wtd"] + E.DAILY_COLS)
    check(same, "changing Wednesday and every later row leaves Wednesday's daily and weekly context unchanged")
    mon = wed - 2 if wd[wed - 2].weekday() == 0 else None
    if mon is not None:
        check(ctx["w_wtd"].iloc[mon] == 0.0, "week-to-date return on a Monday = 0")
    wk_start = wed - wd[wed].weekday()
    prev_week_close = d["close"].iloc[wk_start - 1]
    want = (d["close"].iloc[wed - 1] / prev_week_close - 1) / ctx["atr"].iloc[wed]
    check(abs(ctx["w_wtd"].iloc[wed] - want) < 1e-9, "week-to-date on a Wednesday = Tuesday's close vs last Friday's close, in ATR")
    check(list(E.split_like(np.array([0.5, 0.48, 1.1, 0.334, 2.01, 0.2, 0.75, 0.8]))) == [True, False, False, True, True, True, False, True],
          "split-like ratios: 1:2, 1:3, 2:1, 1:5 and a 1:4 bonus (x0.8) yes; 0.48, +10% and -25% no")
    # intraday features and outcomes on a hand-built session
    day = pd.Timestamp("2022-06-01")
    hist = [flat_session(dd) for dd in calendar("2022-04-01", "2022-05-31")]
    X = flat_session(day)
    X.loc[3, ["high", "close"]] = [101.0, 101.0]
    X.loc[4, ["open", "high", "low", "close"]] = [101.0, 101.5, 100.9, 101.2]
    Xa = pd.concat(hist + [X], ignore_index=True)
    dd = calendar("2021-01-01", "2022-03-31")
    dl = pd.DataFrame({"timestamp": dd, "open": 100.0, "high": 100.5, "low": 99.5, "close": 100.0, "volume": NB * 40000.0})
    dl = with_day(pd.concat([dl, daily_from_bars(Xa)], ignore_index=True))
    r = E.build_symbol(dl, Xa, None, reconcile_like_ic, None, None)
    F = r["F"]
    f4 = F[(F["day"] == day) & (F["k"] == 4)]
    atr = float(r["atr_s"][-1])
    check(len(f4) == 1 and abs(float(f4["i_ret"].iloc[0]) - (101.2 / 100.0 - 1) / atr) < 1e-12,
          f"i_ret at 09:30 = (close of bar 4 / first open - 1) / ATR (ATR {atr:.4f})")
    check(abs(float(f4["i_or"].iloc[0])) < 1e-12, "i_or = 0 while the close is inside the 09:15-09:30 range (bar 4 is part of it)")
    vw = BM.session_vwap(*(r["B"][k][-1:, :5] for k in ("high", "low", "close", "volume")))[0, 4]
    check(abs(float(f4["i_vwap"].iloc[0]) - (101.2 / vw - 1) / atr) < 1e-12, "i_vwap uses the VWAP of bars 0-4 only")
    # outcomes: up barrier first
    B = {k: v[-1:].copy() for k, v in r["B"].items()}
    b = 0.3 * atr * 100.0
    for k in range(5, NB):
        B["open"][0, k] = B["close"][0, k] = 100.0
        B["high"][0, k], B["low"][0, k] = 100.01, 99.99
    B["high"][0, 12] = 100.0 + b + 0.01
    Y = E.outcomes(B, np.array([atr / 100.0 * 100.0]), np.array([0]), np.array([9]))
    check(int(Y["e"].iloc[0]) == 10 and float(Y["entry"].iloc[0]) == 100.0 and Y["y_up"].iloc[0] == 1.0 and Y["y_t"].iloc[0] == 2,
          "decision at bar 9 -> entry at bar 10's open; +0.3 ATR reached at bar 12 first -> y_up 1, 2 bars")
    B2 = {k: v.copy() for k, v in B.items()}
    for kk in B2:
        B2[kk][0, 10] = np.nan
    Y = E.outcomes(B2, np.array([atr]), np.array([0]), np.array([9]))
    check(int(Y["e"].iloc[0]) == 11, "bar 10 missing -> entry at bar 11's open")
    B3 = {k: v.copy() for k, v in B.items()}
    B3["low"][0, 12] = 100.0 - b - 0.01
    Y = E.outcomes(B3, np.array([atr]), np.array([0]), np.array([9]))
    check(np.isnan(Y["y_up"].iloc[0]) and bool(Y["y_amb"].iloc[0]), "both barriers inside one bar -> unknown order, left out and counted")
    B4 = {k: v.copy() for k, v in B.items()}
    B4["low"][0, 11] = 100.0 - b - 0.01
    Y = E.outcomes(B4, np.array([atr]), np.array([0]), np.array([9]))
    check(Y["y_up"].iloc[0] == 0.0, "-0.3 ATR first -> y_up 0")
    B5 = {k: v.copy() for k, v in B.items()}
    B5["close"][0, 29] = 100.5
    Y = E.outcomes(B5, np.array([atr]), np.array([0]), np.array([9]))
    check(abs(Y["y_ret"].iloc[0] - (100.5 / 100.0 - 1) / atr) < 1e-12, "y_ret = close of the 20th bar after entry (bar 29) vs entry, in ATR")
    Y = E.outcomes(B, np.array([atr]), np.array([0]), np.array([104]))
    check(int(Y["e"].iloc[0]) == 105, "a 14:30 decision enters at the 14:30 bar")
    B6 = {k: v.copy() for k, v in B.items()}
    B6["open"][0, 105] = np.nan
    Y = E.outcomes(B6, np.array([atr]), np.array([0]), np.array([104]))
    check(int(Y["e"].iloc[0]) == -1 and np.isnan(Y["y_ret"].iloc[0]), "no bar to enter by 14:30 -> no outcome")


# ----------------------------------------------------------------------
# 2. look-ahead
# ----------------------------------------------------------------------
_W = {}


def small_world(planted=True, seed=5, n=3, end="2023-06-30"):
    key = (planted, seed, n, end)
    if key not in _W:
        _W[key] = World(n=n, seed=seed, planted=planted, start_3m="2021-09-01", end=end)
    return _W[key]


def stock_inputs(w: World, sym: str):
    nd, nb = with_day(w.daily("NIFTY 50")), w.bars("NIFTY 50")
    sd, sx = with_day(w.daily("NIFTY BANK")), w.bars("NIFTY BANK")
    sec = w.sector[sym]
    mkt = E.index_panel(nd, nb)
    sp = E.index_panel(sd, sx) if sec else None
    daily, X = with_day(w.daily(sym)), w.bars(sym)
    base = E.build_symbol(daily, X, pd.DatetimeIndex(w.cal), reconcile_like_ic, mkt, sp, with_outcomes=False)
    return daily, X, (nd, nb), ((sd, sx) if sec else None), base


def lookahead():
    print("2. look-ahead")
    w = small_world()
    daily, X, mraw, sraw, base = stock_inputs(w, "S000")             # S000 has a sector index
    t0 = time.time()
    res = E.pit_check(daily, X, pd.DatetimeIndex(w.cal), mraw, sraw, base, 40, 11, dev_only=False)
    check(res["checked"] == 40 and res["failed"] == 0, f"scrambling everything after a decision changes nothing at or before it: "
          f"{res['checked'] - res['failed']} of {res['checked']} days ({time.time() - t0:.0f} s) {res['failures'][:2]}")
    # planted leaks must be caught
    orig_vwap, orig_ctx = BM.session_vwap, E.daily_context

    def vwap_leak(H, L, C, V):
        v = orig_vwap(H, L, C, V)
        return np.repeat(v[:, -1:], v.shape[1], axis=1)              # the whole session's VWAP at every bar

    def ctx_noshift(daily_):
        c = orig_ctx(daily_)
        c2 = orig_ctx(pd.concat([daily_.iloc[1:], daily_.iloc[-1:]], ignore_index=True))   # row t sees row t's own close
        for col in E.DAILY_COLS:
            c[col] = c2[col].to_numpy()
        return c

    def ctx_week_leak(daily_):
        c = orig_ctx(daily_)
        d = daily_.reset_index(drop=True)
        wk = d["day"] - pd.to_timedelta(d["day"].dt.weekday, unit="D")
        last = d.groupby(wk)["close"].transform("last")              # the CURRENT week's close
        c["w_ret1"] = (last / d["close"].shift(1) - 1).to_numpy()
        return c

    for name, patch in (("a VWAP over the whole session", ("vwap", vwap_leak)), ("daily context not shifted", ("ctx", ctx_noshift)),
                        ("weekly context including the current week", ("ctx", ctx_week_leak))):
        try:
            if patch[0] == "vwap":
                BM.session_vwap = patch[1]
            else:
                E.daily_context = patch[1]
            daily, X, mraw, sraw, base = stock_inputs(w, "S002")
            res = E.pit_check(daily, X, pd.DatetimeIndex(w.cal), mraw, sraw, base, 12, 5, dev_only=False)
        finally:
            BM.session_vwap, E.daily_context = orig_vwap, orig_ctx
        check(res["failed"] > 0, f"planted leak caught: {name} ({res['failed']} of {res['checked']} days fail)")
    # HMM: filtered probabilities ignore later observations
    rng = np.random.default_rng(2)
    Y = rng.normal(0, 1, (300, 21, 3))
    M = rng.random((300, 21)) > 0.05
    h = EM.HMM().fit(Y, M, 3, rng, max_iter=10)
    A1 = h.filter(Y, M)
    Y2 = Y.copy()
    Y2[:, 12:] = rng.normal(5, 3, Y2[:, 12:].shape)
    A2 = h.filter(Y2, M)
    check(np.allclose(A1[:, :12], A2[:, :12]) and not np.allclose(A1[:, 12:], A2[:, 12:]),
          "HMM filtered state probabilities at a step do not change when later observations change")
    # a fold's models do not change when its test window changes
    w6 = small_world(True, 9, 3, "2023-12-31")
    tmp = Path(tempfile.mkdtemp())
    try:
        write_root(tmp, w6)
        dq, ic = stand_ins()
        obs, _ = SB.load_panel(tmp, [(s, w6.sector[s]) for s in w6.stocks], dq, ic, reconcile_like_ic, log=lambda m: None)
        fold = ["2021-10-01", "2022-09-30", "2022-10-01", "2023-03-31"]
        saved = SB.REPS
        SB.REPS = ["grid12", "gmm4", "hmm4"]
        try:
            _, _, _, c1 = SB.run_fold(obs, 0, fold, {}, log=lambda m: None)
            o2 = obs.copy()
            te = (o2["day"] >= pd.Timestamp(fold[2])).to_numpy()
            o2.loc[te, E.FEATURES] = o2.loc[te, E.FEATURES].to_numpy(float) * 3 + 1
            o2.loc[te, "y_up"] = 1.0 - o2.loc[te, "y_up"]
            P2, _, _, c2 = SB.run_fold(o2, 0, fold, {}, log=lambda m: None)
        finally:
            SB.REPS = saved
        same = all(np.allclose(c1[r]["tab"], c2[r]["tab"]) and np.allclose(c1[r]["zmean"], c2[r]["zmean"]) for r in c1)
        check(same and len(c1) == 3, "a fold's state models and outcome tables are unchanged when its test window's features and outcomes change")
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


# ----------------------------------------------------------------------
# 3. models
# ----------------------------------------------------------------------
def models():
    print("3. models")
    rng = np.random.default_rng(4)
    mu = np.array([[0, 0, 0], [5, 5, 0], [0, 6, 6]], float)
    lab = rng.integers(3, size=3000)
    Y = mu[lab] + rng.normal(0, 1, (3000, 3))
    km = EM.KMeans().fit(Y, 3, rng)
    g = EM.GMM().fit(Y, 3, rng)
    check(EM.ari(lab, km.proba(Y).argmax(1)) > 0.95 and EM.ari(lab, g.proba(Y).argmax(1)) > 0.95,
          f"k-means and GMM recover 3 planted clusters (ARI {EM.ari(lab, km.proba(Y).argmax(1)):.3f}, {EM.ari(lab, g.proba(Y).argmax(1)):.3f})")
    check(abs(g.proba(Y).sum(1) - 1).max() < 1e-9, "GMM state probabilities sum to 1")
    far = g.novelty_score(np.array([[30.0, -30.0, 30.0]]))[0] > np.percentile(g.novelty_score(Y), 99.9)
    check(bool(far), "a point far from the training data is novel")
    # sticky two-state HMM
    S, T = 400, 21
    st = np.zeros((S, T), int)
    st[:, 0] = rng.integers(2, size=S)
    for t in range(1, T):
        flip = rng.random(S) < 0.08
        st[:, t] = np.where(flip, 1 - st[:, t - 1], st[:, t - 1])
    Yh = np.where(st[:, :, None] == 1, 1.2, -1.2) + rng.normal(0, 1.0, (S, T, 2))
    M = np.ones((S, T), bool)
    h = EM.HMM().fit(Yh, M, 2, rng)
    A = h.filter(Yh, M).argmax(2)
    gm = EM.GMM().fit(Yh.reshape(-1, 2), 2, rng).proba(Yh.reshape(-1, 2)).argmax(1)
    a_h, a_g = EM.ari(st.ravel(), A.ravel()), EM.ari(st.ravel(), gm)
    check(np.diag(h.A).min() > 0.8 and a_h > a_g, f"HMM learns the sticky chain (diagonal {np.diag(h.A).round(2)}) and its filtered "
          f"states beat a mixture that ignores time (ARI {a_h:.3f} vs {a_g:.3f})")
    x = rng.integers(4, size=500)
    check(EM.ari(x, x) == 1.0 and EM.ari(x, (x + 1) % 4) == 1.0 and abs(EM.ari(x, rng.integers(4, size=500))) < 0.05,
          "ARI: identical and relabelled partitions = 1, independent ones about 0")
    check(EM.psi([0.5, 0.5], [0.5, 0.5]) == 0.0 and EM.psi([0.5, 0.5], [0.9, 0.1]) > 0.25, "PSI: 0 for the same shares, large for a shift")
    # shrinkage
    P = np.zeros((1010, 2))
    P[:1000, 0] = 1
    P[1000:, 1] = 1
    D = np.zeros((1010, 1))
    D[:1000, 0] = 0.1
    D[1000:, 0] = 1.0
    sym = np.r_[np.zeros(500, int), np.ones(500, int), np.zeros(10, int)]
    tab, cnt, pooled = SB.state_tables(P, D, sym, 2, 200.0)
    check(abs(pooled[0, 0] - 100 / 1200) < 1e-12 and abs(pooled[1, 0] - 10 / 210) < 1e-12,
          f"pooled state value = sum / (count + 200): a common state keeps most of its 0.1, a 10-observation state's 1.0 shrinks to {pooled[1, 0]:.3f}")
    check(abs(tab[1, 1, 0] - pooled[1, 0]) < 1e-12, "a stock that never visited a state gets the pooled value")


# ----------------------------------------------------------------------
# 4. Stage B worlds
# ----------------------------------------------------------------------
def stand_ins():
    dq = types.ModuleType("data_quality")
    dq._paths = lambda root, s: (Path(root) / f"{s}_daily.parquet", Path(root) / f"{s}_daily.ok.json")
    ic = types.ModuleType("intraday_cache")
    ic.store, ic.BAR_MIN = (lambda root: Path(root) / "intraday_3m"), 3
    ic.DECL = {"reconcile_price_tol": 0.005, "reconcile_volume_tol": 0.10}
    ic.reconcile_symbol = reconcile_like_ic

    def reconcile_index(intra, daily, tol):
        X = intra.sort_values("timestamp")
        g = X.groupby(X["timestamp"].dt.normalize())
        J = pd.DataFrame({"i_open": g["open"].first(), "i_high": g["high"].max(), "i_low": g["low"].min()})
        late = X[X["timestamp"].dt.hour * 60 + X["timestamp"].dt.minute >= 900]
        J["i_c"] = ((late["high"] + late["low"] + late["close"]) / 3).groupby(late["timestamp"].dt.normalize()).mean()
        d = daily.set_index(pd.to_datetime(daily["timestamp"]).dt.normalize())
        J = J.join(d[["open", "high", "low", "close"]], how="left")
        rel = lambda a, b: (J[a] / J[b] - 1).abs()
        J["ok"] = ((rel("i_open", "open") <= tol) & (rel("i_high", "high") <= tol) & (rel("i_low", "low") <= tol) &
                   (rel("i_c", "close") <= tol)).fillna(False)
        return J.rename_axis("day").reset_index()
    ic.reconcile_index = reconcile_index
    return dq, ic


DAILY_NAME = {"NIFTY 50": "NIFTY50", "NIFTY BANK": "NIFTYBANK"}


def write_root(tmp: Path, w: World, alter=None, zone=None):
    (tmp / "intraday_3m").mkdir(exist_ok=True)
    (tmp / "panel").mkdir(exist_ok=True)
    for nm in w.names:
        d, X = w.daily(nm), w.bars(nm)
        if alter is not None:
            d, X = alter(nm, d, X)
        if zone and nm in zone:
            X = X.assign(timestamp=X["timestamp"].dt.tz_localize("Asia/Kolkata").dt.tz_convert("UTC"))
        d.to_parquet(tmp / f"{DAILY_NAME.get(nm, nm)}_daily.parquet", index=False)
        X.to_parquet(tmp / "intraday_3m" / f"{nm}_3m.parquet", index=False)


def late_change(nm, d, X):
    """Every daily row and bar after 2024-12-31 multiplied by 0.61 (and volumes by 3)."""
    d = d.copy()
    X = X.copy()
    lt = pd.to_datetime(d["timestamp"]) > pd.Timestamp("2024-12-31")
    for c in ("open", "high", "low", "close"):
        d.loc[lt, c] = d.loc[lt, c] * 0.61
    d.loc[lt, "volume"] = d.loc[lt, "volume"] * 3
    lx = X["timestamp"] >= pd.Timestamp("2025-01-01")
    for c in ("open", "high", "low", "close"):
        X.loc[lx, c] = X.loc[lx, c] * 0.61
    X.loc[lx, "volume"] = X.loc[lx, "volume"] * 3
    return d, X


def stage_b_world(w: World, label: str, quiet=True):
    tmp = Path(tempfile.mkdtemp())
    try:
        write_root(tmp, w)
        dq, ic = stand_ins()
        buf = io.StringIO()
        t0 = time.time()
        with contextlib.redirect_stdout(buf):
            out, v = SB.run(tmp, [(s, w.sector[s]) for s in w.stocks], dq, ic, reconcile_like_ic)
        R = pd.read_csv(out / "representations.csv")
        return v, R, time.time() - t0
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def worlds():
    print("4. Stage B worlds (6 stocks, 5 folds each)")
    v, R, s = stage_b_world(World(n=6, seed=21, planted=True, kappa_t=0.12, kappa_r=0.12, end="2025-03-31"), "PLANTED")
    best = R.sort_values("brier_skill", ascending=False).iloc[0]
    check(v == "STATES INFORMATIVE", f"PLANTED (moderate drift) -> {v}; best {best['rep']} Brier skill {best['brier_skill']:+.4f} "
          f"[{best['brier_lo']:+.4f}, {best['brier_hi']:+.4f}]; informative: {', '.join(R.loc[R['informative'], 'rep'])} ({s:.0f} s)")
    for seed in (31, 32):
        v, R, s = stage_b_world(World(n=6, seed=seed, planted=False, end="2025-03-31"), "NONE")
        inf = R.loc[R["informative"], "rep"].tolist()
        check(v != "STATES INFORMATIVE" and not inf, f"NONE seed {seed} -> {v}; direction-informative: {inf or 'none'}; best Brier skill "
              f"{R['brier_skill'].max():+.4f}, magnitude skill up to {R['mag_skill'].max():+.3f} ({s:.0f} s)")


# ----------------------------------------------------------------------
# 5. Stage A
# ----------------------------------------------------------------------
def defects(nm, d, X):
    """S000: 5 duplicate rows, 3 off-grid rows, a session on a holiday, a missing session, a short session, 3 bars with the
    high below the body. S001: 3-minute bars before 2022-06-01 on the old (2x) split basis. S002: an unadjusted 1:2 split
    in BOTH files from 2023-03-01 (the daily file shows the jump)."""
    d, X = d.copy(), X.copy()
    have = set(pd.to_datetime(d["timestamp"]).dt.normalize())
    on_cal = lambda s: next(x for x in pd.bdate_range(s, periods=30) if x in have)            # the first session on or after s
    if nm == "S000":
        X = pd.concat([X, X.iloc[1000:1005]], ignore_index=True)
        off = X.iloc[2000:2003].copy()
        off["timestamp"] = off["timestamp"] + pd.Timedelta(minutes=1)
        X = pd.concat([X, off], ignore_index=True)
        hol = next(x for x in pd.bdate_range("2022-07-01", periods=200) if x not in have and x - pd.offsets.BDay(1) in have)
        src = X[X["timestamp"].dt.normalize() == hol - pd.offsets.BDay(1)].copy()               # a session on a holiday
        src["timestamp"] = src["timestamp"] + (hol - (hol - pd.offsets.BDay(1)))
        X = pd.concat([X, src], ignore_index=True)
        X = X[X["timestamp"].dt.normalize() != on_cal("2022-11-15")]                             # missing session
        short = (X["timestamp"].dt.normalize() == on_cal("2023-02-15")) & (X["timestamp"].dt.hour.isin([11, 12, 13]))
        X = X[~short]                                                                             # 60 bars gone: short session
        i = X.index[(X["timestamp"].dt.normalize() == on_cal("2023-08-10"))][[20, 30, 40]]
        X.loc[i, "high"] = X.loc[i, ["open", "close"]].max(axis=1) - 0.5
    if nm == "S001":
        lt = X["timestamp"] < pd.Timestamp("2022-06-01")
        X.loc[lt, ["open", "high", "low", "close"]] *= 2.0
        X.loc[lt, "volume"] /= 2.0
    if nm == "S002":
        lt = pd.to_datetime(d["timestamp"]) >= pd.Timestamp("2023-03-01")
        d.loc[lt, ["open", "high", "low", "close"]] *= 0.5
        d.loc[lt, "volume"] *= 2
        lx = X["timestamp"] >= pd.Timestamp("2023-03-01")
        X.loc[lx, ["open", "high", "low", "close"]] *= 0.5
        X.loc[lx, "volume"] *= 2
    return d, X


def stage_a():
    print("5. Stage A")
    saved = E.CFG["a_pit_days"]
    E.CFG["a_pit_days"] = 6                                       # the suite checks fewer days per stock (section 2 checks 40)
    try:
        w = World(n=4, seed=8, planted=True, start_3m="2021-09-01", end="2025-02-28", missing_bars=0.0, missing_sessions=0.0)
        for label, alter, zone in (("clean", None, ("S003",)), ("defects", defects, ("S003",))):
            tmp = Path(tempfile.mkdtemp())
            try:
                write_root(tmp, w, alter, zone)
                dq, ic = stand_ins()
                buf = io.StringIO()
                with contextlib.redirect_stdout(buf):
                    out, ok = SA.run(tmp, [(s, w.sector[s]) for s in w.stocks], dq, ic, reconcile_like_ic)
                R = pd.read_csv(out / "stocks.csv").set_index("symbol")
                EV = pd.read_csv(out / "events.csv") if (out / "events.csv").stat().st_size > 2 else pd.DataFrame(columns=["symbol", "event"])
                if label == "clean":
                    check(ok and (R["status"] == "PASS").all(), f"clean market: every stock PASS ({dict(R['status'])}), "
                          f"clean share {R['clean_share_dev'].min() * 100:.1f}%+, weekly agree {R['weekly_agree'].min() * 100:.1f}%+")
                    check(R.loc["S003", "tz"] == "UTC" and R.loc["S003", "off_grid"] == 0 and R.loc["S003", "status"] == "PASS",
                          "a UTC-zoned 3-minute file is converted to IST: no off-grid rows, PASS")
                    check(int(R["pit_failed"].sum()) == 0 and (R["pit_checked"] == 6).all(), "point-in-time check passes on every stock")
                    continue
                s0 = R.loc["S000"]
                check(s0["duplicate"] == 5 and s0["off_grid"] == 3, f"S000: 5 duplicates and 3 off-grid rows found ({s0['duplicate']}, {s0['off_grid']})")
                check(s0["extra_sessions"] == 1 and s0["missing_sessions_dev"] == 1 and s0["short_sessions_dev"] == 1,
                      f"S000: the holiday session, the missing session and the short session found "
                      f"({s0['extra_sessions']}, {s0['missing_sessions_dev']}, {s0['short_sessions_dev']})")
                check(s0["high_below_body"] == 3, f"S000: 3 bars with the high below the body ({s0['high_below_body']})")
                check(s0["status"] == "PASS", f"S000's small defects stay under the gate's limits: {s0['status']} {s0['reasons'] or ''}")
                s1 = R.loc["S001"]
                seg = EV[(EV["symbol"] == "S001") & (EV["event"] == "basis_segment")]
                check(len(seg) == 1 and abs(float(seg["ratio"].iloc[0]) - 0.5) < 0.02 and seg["to"].iloc[0] == "2022-05-31" and
                      s1["status"] == "FIX NEEDED", f"S001: the old-basis 3-minute stretch is one basis segment to 2022-05-31 at ratio "
                      f"{float(seg['ratio'].iloc[0]) if len(seg) else float('nan'):.3f} -> FIX NEEDED ({s1['reasons']})")
                s2 = R.loc["S002"]
                ev2 = EV[(EV["symbol"] == "S002")]
                check(set(ev2["event"]) >= {"daily_split_like_jump", "bars_split_like_jump"} and
                      (ev2.loc[ev2["event"] == "daily_split_like_jump", "day"] == "2023-03-01").all() and s2["status"] == "FIX NEEDED",
                      f"S002: the unadjusted split shows in both files on 2023-03-01 -> FIX NEEDED ({s2['reasons']})")
                check(R.loc["S003", "status"] == "PASS" and not ok, "S003 untouched still PASS; the stage is FIX NEEDED")
            finally:
                shutil.rmtree(tmp, ignore_errors=True)
    finally:
        E.CFG["a_pit_days"] = saved


# ----------------------------------------------------------------------
# 6. glue
# ----------------------------------------------------------------------
def tree(root: Path) -> dict:
    return {str(p.relative_to(root)): p.stat().st_size for p in root.rglob("*") if p.is_file()}


def with_modules(dq, ic, fn):
    saved = {m: sys.modules.get(m) for m in ("data_quality", "intraday_cache")}
    sys.modules.update({"data_quality": dq, "intraday_cache": ic})
    try:
        return fn()
    finally:
        for m, v in saved.items():
            if v is None:
                sys.modules.pop(m, None)
            else:
                sys.modules[m] = v


def glue():
    print("6. glue (both main() functions, stand-in modules)")
    saved = E.CFG["a_pit_days"]
    E.CFG["a_pit_days"] = 3
    tmp = Path(tempfile.mkdtemp())
    try:
        w = World(n=3, seed=13, planted=True, start_3m="2021-09-01", end="2025-02-28")
        write_root(tmp, w)
        (tmp / "panel" / "research_ledger.jsonl").write_text('{"family": "other", "run": "X"}\n', encoding="utf-8")
        sf = tmp / "stocks.txt"
        sf.write_text("S000, NIFTY BANK\nS001\nS002\n", encoding="utf-8")
        before = tree(tmp)
        dq, ic = stand_ins()
        buf = io.StringIO()
        with contextlib.redirect_stdout(buf):
            rc_a = with_modules(dq, ic, lambda: SA.main(["--root", str(tmp), "--stocks", str(sf)]))
            rc_b = with_modules(dq, ic, lambda: SB.main(["--root", str(tmp), "--stocks", str(sf)]))
        after = tree(tmp)
        new = sorted(set(after) - set(before))
        changed = sorted(k for k in before if after.get(k) != before[k])
        ok_paths = all(k.replace("\\", "/").startswith("research2/engine/") for k in new)
        check(rc_a == 0 and rc_b == 0 and ok_paths and changed == [str(Path("panel") / "research_ledger.jsonl")],
              f"both ran (exit {rc_a}, {rc_b}); wrote only research2\\engine\\ ({len(new)} files) and the ledger (changed: {changed})")
        led = [json.loads(x) for x in (tmp / "panel" / "research_ledger.jsonl").read_text(encoding="utf-8").splitlines()]
        check(len(led) == 3 and led[1]["stage"] == "A" and led[2]["stage"] == "B" and led[2]["post_2024_used"] is False and led[2]["fresh"],
              "one ledger line per stage; Stage B records that nothing after 2024 was used")
        ex = (tmp / "research2" / "engine" / "experiments.jsonl").read_text(encoding="utf-8").splitlines()
        check(len(ex) == len(SB.REPS) and json.loads(ex[-1])["n"] == len(SB.REPS), f"{len(ex)} experiments recorded, numbered 1..{len(SB.REPS)}")
        runs = sorted((tmp / "research2" / "engine").glob("B_*"))
        a_runs = sorted((tmp / "research2" / "engine").glob("A_*"))
        need_a = {"report.md", "summary.json", "stocks.csv", "events.csv", "sessions.csv", "reconcile_by_year.csv", "outputs.sha256"}
        need_b = {"report.md", "summary.json", "representations.csv", "folds.csv", "calibration.csv", "states.csv", "outputs.sha256"}
        check(len(a_runs) == 1 and need_a <= {p.name for p in a_runs[0].iterdir()} and len(runs) == 1 and need_b <= {p.name for p in runs[0].iterdir()},
              "Stage A and Stage B output sets complete")
        rep = (runs[0] / "report.md").read_text(encoding="utf-8")
        check("VERDICT" in rep and "RERUN" not in rep, "Stage B report has a verdict, not a rerun")
        write_root(tmp, w, late_change)
        with contextlib.redirect_stdout(buf):
            with_modules(dq, ic, lambda: SB.main(["--root", str(tmp), "--stocks", str(sf)]))
        runs = sorted((tmp / "research2" / "engine").glob("B_*"))
        a, b = pd.read_csv(runs[0] / "representations.csv"), pd.read_csv(runs[1] / "representations.csv")
        num = [c for c in a.columns if c not in ("fit_s",)]
        same = a[num].round(10).equals(b[num].round(10)) and pd.read_csv(runs[0] / "calibration.csv").equals(pd.read_csv(runs[1] / "calibration.csv"))
        check(len(runs) == 2 and same, "every 2025 bar and daily row changed -> Stage B results identical")
        rep2 = (runs[1] / "report.md").read_text(encoding="utf-8")
        led = [json.loads(x) for x in (tmp / "panel" / "research_ledger.jsonl").read_text(encoding="utf-8").splitlines()]
        check("RERUN" in rep2 and led[-1]["fresh"] is False and led[-1]["previous_runs"] == [runs[0].name],
              "the second Stage B run is stamped RERUN (report and ledger)")
    finally:
        E.CFG["a_pit_days"] = saved
        shutil.rmtree(tmp, ignore_errors=True)


def main() -> int:
    t0 = time.time()
    print(f"{E.CODE_VERSION} / {SA.CODE_VERSION} / {SB.CODE_VERSION} tests (declaration {E.DECL_SHA}, bigmove_study {BM.CODE_VERSION})")
    only = sys.argv[1:]
    for nm, fn in (("hand", by_hand), ("lookahead", lookahead), ("models", models), ("worlds", worlds), ("stage_a", stage_a), ("glue", glue)):
        if not only or nm in only:
            fn()
    print(f"\n{len(FAILS)} failure(s) in {time.time() - t0:.0f} s")
    for f in FAILS:
        print("  FAIL:", f)
    if not FAILS and not only:
        print("VERIFIED")
    return 1 if FAILS else 0


if __name__ == "__main__":
    sys.exit(main())
