#!/usr/bin/env python3
"""
tests/engine_world.py - a synthetic NSE market for the behavioural engine's tests (no real data).

NIFTY 50, NIFTY BANK and n stocks on a real-looking session calendar (weekdays minus holidays): daily rows from 2019 (so
weekly context has history), 3-minute bars (125 a session, IST, no zone) from `start_3m`. Each stock lives in a hidden
day regime that persists from day to day (a Markov chain):
  quiet    lower volatility and volume
  trend    higher volatility and volume; after the first half hour the price keeps drifting the way it has moved
  revert   normal volatility; the price is pulled back toward the session VWAP when stretched
`planted=True` gives the trend and revert drifts (direction is predictable from behaviour); `planted=False` keeps every
volatility and volume difference but no drift (how MUCH it moves is predictable, which WAY is not).
U-shaped intraday volatility and volume, a market factor with stock betas, overnight gaps, about 1% of bars missing and
a few missing sessions. Daily rows are built from the bars: the close is the 15:00-15:30 VWAP (the official close), so
every complete session reconciles.
"""

from __future__ import annotations

import numpy as np
import pandas as pd

NB = 125
QUIET, TREND, REVERT = 0, 1, 2
LAST30 = np.arange(115, NB)


def calendar(start: str, end: str) -> pd.DatetimeIndex:
    d = pd.bdate_range(start, end)
    drop = np.zeros(len(d), bool)
    drop[np.arange(17, len(d), 41)] = True                   # holidays
    return d[~drop]


def _u_shape() -> np.ndarray:
    x = np.linspace(0.0, 1.0, NB)
    u = 0.7 + 2.4 * (x - 0.45) ** 2
    u[:6] *= np.linspace(1.8, 1.2, 6)
    return u / np.sqrt((u ** 2).mean())


class World:
    def __init__(self, n: int = 6, seed: int = 1, planted: bool = True, start_daily: str = "2019-01-01",
                 start_3m: str = "2021-09-01", end: str = "2025-03-31", kappa_t: float = 0.35, kappa_r: float = 0.35,
                 p_stay: float = 0.6, missing_bars: float = 0.01, missing_sessions: float = 0.005):
        rng = np.random.default_rng(seed)
        self.n, self.seed, self.planted = n, seed, planted
        self.cal = calendar(start_daily, end)
        self.names = ["NIFTY 50", "NIFTY BANK"] + [f"S{i:03d}" for i in range(n)]
        self.sector = {f"S{i:03d}": ("NIFTY BANK" if i < 2 else None) for i in range(n)}
        cal = self.cal
        i3 = int(np.searchsorted(cal, pd.Timestamp(start_3m)))
        days3 = cal[i3:]
        D, N = len(days3), len(self.names)
        stock = np.arange(N) >= 2
        u = _u_shape()
        uv = 1.0 + 6.4 * (np.linspace(0, 1, NB) - 0.5) ** 2
        uv[:5] *= 1.6
        sig_d = np.r_[0.010, 0.013, rng.uniform(0.013, 0.026, n)]
        beta = np.r_[1.0, 1.0, rng.uniform(0.6, 1.3, n)]
        p0 = np.r_[17000.0, 38000.0, rng.uniform(150, 3000, n)]
        v0 = np.r_[0.0, 0.0, rng.uniform(2e5, 2e6, n)]
        reg = np.zeros((N, D), int)
        P = np.full((3, 3), (1 - p_stay) / 2)
        np.fill_diagonal(P, p_stay)
        for s in range(2, N):
            r_ = int(rng.integers(3))
            for t in range(D):
                r_ = int(rng.choice(3, p=P[r_])) if t else r_
                reg[s, t] = r_
        self.regime = {self.names[s]: pd.Series(reg[s], index=days3) for s in range(2, N)}
        vs, vf = np.array([0.7, 1.25, 1.0]), np.array([0.7, 1.7, 1.0])
        # daily-only history before the bars
        dly = {nm: [] for nm in self.names}
        close = p0.copy()
        for t in range(i3):
            z = rng.normal(0, 1, N)
            mz = rng.normal()
            r = sig_d * (0.7 * beta * mz + 0.6 * z)
            r[1] = 0.8 * r[0] + 0.6 * sig_d[1] * z[1]
            o = close * np.exp(rng.normal(0, 0.3, N) * sig_d)
            c = o * np.exp(r)
            h = np.maximum(o, c) * np.exp(np.abs(rng.normal(0, 0.5, N)) * sig_d)
            l_ = np.minimum(o, c) * np.exp(-np.abs(rng.normal(0, 0.5, N)) * sig_d)
            v = np.where(v0 > 0, v0 * NB * np.exp(rng.normal(0, 0.3, N)), 0.0)
            for s, nm in enumerate(self.names):
                dly[nm].append((cal[t], o[s], h[s], l_[s], c[s], v[s]))
            close = c
        # sessions one by one (a session opens from the previous official close), all names at once, bar by bar
        sb = sig_d / np.sqrt(NB)
        bars = {nm: [] for nm in self.names}
        pc = close.copy()
        for t in range(D):
            rg = reg[:, t]
            vsr = np.where(stock, vs[rg], 1.0)
            vfr = np.where(stock, vf[rg], 0.0)
            O, H, L, C, V = (np.full((N, NB), np.nan) for _ in range(5))
            mg = rng.normal()
            gap = rng.normal(0, 0.3, N) * sig_d + np.where(stock, beta * mg * 0.3 * sig_d[0], 0.0)
            gap[0] = mg * 0.3 * sig_d[0]
            O0 = pc * np.exp(gap)
            pv, vv = np.zeros(N), np.zeros(N)
            for k in range(NB):
                sig = sb * u[k] * vsr
                m = rng.normal() * sb[0] * u[k]
                z = rng.normal(0, 1, N)
                r = np.where(stock, beta * m + sig * z, 0.0)
                r[0] = m
                r[1] = 0.8 * m + 0.6 * sb[1] * u[k] * z[1]
                if planted and k > 0:
                    mv = C[:, k - 1] / O0 - 1
                    with np.errstate(invalid="ignore", divide="ignore"):
                        dev = (C[:, k - 1] / (pv / np.maximum(vv, 1e-9)) - 1) / (sig_d * 0.25)
                    d_t = np.where((rg == TREND) & (k >= 10), kappa_t * sig * np.sign(mv), 0.0)
                    d_r = np.where((rg == REVERT) & (k >= 5), -kappa_r * sig * np.clip(np.nan_to_num(dev), -2, 2), 0.0)
                    r = r + np.where(stock, d_t + d_r, 0.0)
                ob = O0 if k == 0 else C[:, k - 1] * np.exp(rng.normal(0, 0.05, N) * sig)
                c = ob * np.exp(r)
                h = np.maximum(ob, c) * np.exp(np.abs(rng.normal(0, 0.4, N)) * sig)
                l_ = np.minimum(ob, c) * np.exp(-np.abs(rng.normal(0, 0.4, N)) * sig)
                vol = np.where(stock, v0 * uv[k] * vfr * np.exp(rng.normal(0, 0.3, N)), 0.0)
                O[:, k], H[:, k], L[:, k], C[:, k], V[:, k] = ob, h, l_, c, vol
                pv += (h + l_ + c) / 3 * vol
                vv += vol
            tp = (H[:, LAST30] + L[:, LAST30] + C[:, LAST30]) / 3
            vw = V[:, LAST30]
            with np.errstate(invalid="ignore", divide="ignore"):
                off = np.where(vw.sum(1) > 0, (tp * vw).sum(1) / np.maximum(vw.sum(1), 1e-12), tp.mean(1))
            day = days3[t]
            for s, nm in enumerate(self.names):
                skip = s >= 2 and rng.random() < missing_sessions
                keep = rng.random(NB) >= missing_bars
                keep[0] = True
                keep[LAST30] = True                            # the closing half hour stays whole (the close reconciles)
                if not skip:
                    ts = day + pd.to_timedelta(555 + 3 * np.flatnonzero(keep), unit="m")
                    bars[nm].append(pd.DataFrame({"timestamp": ts, "open": O[s, keep], "high": H[s, keep], "low": L[s, keep],
                                                  "close": C[s, keep], "volume": V[s, keep]}))
                dly[nm].append((day, O[s, 0], H[s].max(), L[s].min(), off[s], V[s].sum()))
            pc = off
        self._daily = {nm: pd.DataFrame(v, columns=["timestamp", "open", "high", "low", "close", "volume"]) for nm, v in dly.items()}
        self._bars = {nm: pd.concat(v, ignore_index=True) for nm, v in bars.items()}

    def daily(self, name: str) -> pd.DataFrame:
        return self._daily[name].copy()

    def bars(self, name: str) -> pd.DataFrame:
        return self._bars[name].copy()

    @property
    def stocks(self):
        return [nm for nm in self.names if nm.startswith("S")]


def reconcile_like_ic(intra: pd.DataFrame, daily: pd.DataFrame, tol_p: float = 0.005, tol_v: float = 0.10) -> pd.DataFrame:
    """A copy of intraday_cache v1.7 reconcile_symbol (the tests run without Kite's modules): first open, high, low within
    tol_p, the 15:00-15:30 VWAP within tol_p of the daily close, volume within tol_v; a close ratio near 2, 3, 5, 10 or
    0.5 with failed prices marks a split-basis mismatch."""
    import datetime as dt
    if intra.empty or daily.empty:
        return pd.DataFrame()
    g = intra.assign(day=intra["timestamp"].dt.normalize()).groupby("day")
    agg = pd.DataFrame({"i_open": g["open"].first(), "i_high": g["high"].max(), "i_low": g["low"].min(),
                        "i_close": g["close"].last(), "i_volume": g["volume"].sum(), "bars": g.size()})
    last30 = intra[intra["timestamp"].dt.time >= dt.time(15, 0)]
    tp = (last30["high"] + last30["low"] + last30["close"]) / 3.0
    lv = last30.assign(pv=tp * last30["volume"], tp=tp).groupby(last30["timestamp"].dt.normalize())
    agg["i_close_vwap"] = (lv["pv"].sum() / lv["volume"].sum()).where(lv["volume"].sum() > 0, lv["tp"].mean())
    d = daily.copy()
    t = pd.to_datetime(d["timestamp"])
    d["day"] = t.dt.tz_localize(None).dt.normalize() if getattr(t.dt, "tz", None) is not None else t.dt.normalize()
    J = agg.join(d.set_index("day")[["open", "high", "low", "close", "volume"]], how="left")
    rel = lambda a, b: (J[a] / J[b] - 1).abs()
    J["price_ok"] = (rel("i_open", "open") <= tol_p) & (rel("i_high", "high") <= tol_p) & (rel("i_low", "low") <= tol_p) & \
                    (rel("i_close_vwap", "close") <= tol_p)
    J["volume_ok"] = (J["volume"] <= 0) | ((J["i_volume"] / J["volume"] - 1).abs() <= tol_v)
    J["ratio"] = J["close"] / J["i_close"]
    J["basis_mismatch"] = J["ratio"].round(1).isin([2.0, 3.0, 5.0, 10.0, 0.5]) & ~J["price_ok"]
    J["full_session"] = J["bars"] == NB
    J["ok"] = J["price_ok"] & J["volume_ok"] & J["open"].notna()
    return J.reset_index()
