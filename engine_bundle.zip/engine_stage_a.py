#!/usr/bin/env python3
"""
engine_stage_a.py - Stage A of the 10-stock behavioural engine: data integrity (ENGINE_DECLARATION.json, stage_A).

    python engine_stage_a.py --root %CACHE_DAILY_ROOT%                      (stocks from engine_stocks.txt)
    python engine_stage_a.py --root %CACHE_DAILY_ROOT% --stocks my10.txt

In plain words: before the engine learns anything from the 10 stocks, check that their data can be trusted - bars on
the right 3-minute grid in IST, no duplicated or missing sessions, 3-minute sessions that agree with the daily cache,
no hidden split / bonus adjustment breaks, weekly bars that agree whichever way they are built, features that cannot
see the future (checked on real days by scrambling everything after a decision), and how realistic "enter at the next
bar's open" is. Each stock gets PASS or FIX NEEDED with its reasons; the engine never swaps a stock.

Reads every period, but only structure for 2025 onward (timestamps, sessions, reconciliation, adjustment basis); price,
range and execution statistics come from the development window (2021-10..2024-12) only.

Writes only <root>\\research2\\engine\\A_<date>_<n>\\ and one line in <root>\\panel\\research_ledger.jsonl.
"""

from __future__ import annotations

import argparse
import datetime as dt
import json
import platform
import sys
import time
from pathlib import Path
from typing import Dict, List, Optional, Tuple

import numpy as np
import pandas as pd

HERE = Path(__file__).resolve().parent
if str(HERE) not in sys.path:
    sys.path.insert(0, str(HERE))

import engine_core as E                  # noqa: E402

BM = E.BM
CODE_VERSION = "engine_stage_a v1.0"
CFG = E.CFG
HOLD = pd.Timestamp(CFG["holdout_start"])
CAS = pd.Timestamp(CFG["post_cas_start"])
CTX_FROM = E.DEV[0] - pd.Timedelta(days=int(CFG["a_context_days"]))


def _log(msg: str) -> None:
    print(f"{dt.datetime.now():%H:%M:%S}  {msg}", flush=True)


def segment(days) -> np.ndarray:
    d = pd.DatetimeIndex(days)
    return np.where(d < E.DEV[0], "pre", np.where(d <= E.DEV[1], "dev", np.where(d < CAS, "holdout", "post_cas")))


# ----------------------------------------------------------------------
# A1 timestamps
# ----------------------------------------------------------------------
def a1_bars(f: Path) -> Tuple[pd.DataFrame, dict]:
    """The raw file's timestamp defects (before anything is dropped); returns the rows in IST without a zone."""
    raw = pd.read_parquet(f)
    tz = getattr(pd.to_datetime(raw["timestamp"]).dt, "tz", None)
    X = E.load_bars(f)
    t = X["timestamp"]
    m = (t.dt.hour * 60 + t.dt.minute - 555).to_numpy()
    off = (m % E.BAR != 0) | (t.dt.second.to_numpy() != 0)
    outside = (m < 0) | (m >= E.NB * E.BAR)
    wkend = t.dt.weekday.to_numpy() >= 5
    dup = t.duplicated(keep="last").to_numpy()
    order = np.r_[False, np.diff(t.to_numpy().astype("datetime64[ns]").astype(np.int64)) < 0]
    nanp = X[["open", "high", "low", "close"]].isna().any(axis=1).to_numpy()
    seg = segment(t.dt.normalize())
    out = {"tz": str(tz) if tz is not None else "none (taken as IST)", "rows": int(len(X)), "first": str(t.min()), "last": str(t.max())}
    for nm, v in (("off_grid", off & ~outside), ("outside_session", outside), ("weekend", wkend), ("duplicate", dup),
                  ("out_of_order", order), ("blank_price", nanp)):
        out[nm] = int(v.sum())
        out[nm + "_dev"] = int((v & (seg == "dev")).sum())
    out["rows_dev"] = int((seg == "dev").sum())
    return X, out


def a1_daily(fp: Path) -> dict:
    raw = pd.read_parquet(fp, columns=["timestamp"])
    t = pd.to_datetime(raw["timestamp"])
    tz = getattr(t.dt, "tz", None)
    ti = BM.ist_naive(t)
    return {"daily_tz": str(tz) if tz is not None else "none", "daily_rows": int(len(t)),
            "daily_not_midnight_ist": int(((ti.dt.hour != 0) | (ti.dt.minute != 0)).sum()),
            "daily_duplicate_days": int(ti.dt.normalize().duplicated().sum()), "daily_weekend": int((ti.dt.weekday >= 5).sum())}


# ----------------------------------------------------------------------
# A2 sessions, A3 bars, A4 reconciliation, A5 adjustment basis, A6 weekly, A8 execution
# ----------------------------------------------------------------------
def a2_sessions(S: pd.DataFrame, daily: pd.DataFrame, cal: pd.DatetimeIndex) -> Tuple[dict, List[dict]]:
    days = pd.DatetimeIndex(S["day"])
    dd = pd.DatetimeIndex(daily["day"])
    ev, out = [], {}
    if not len(days):
        return {"sessions": 0}, ev
    lo, hi = days.min(), days.max()
    span = cal[(cal >= lo) & (cal <= hi)]
    traded = span[span.isin(dd)]                                   # trading days the stock has a daily row for
    miss = traded[~traded.isin(days)]
    extra = days[~days.isin(cal)]
    doff = dd[(dd >= lo) & (dd <= hi) & ~dd.isin(cal)]
    nodaily = days[~days.isin(dd)]
    short = days[~S["usable"].to_numpy(bool)]
    for nm, v in (("missing_sessions", miss), ("extra_sessions", extra), ("daily_off_calendar", doff),
                  ("sessions_without_daily", nodaily), ("short_sessions", short)):
        sg = segment(v)
        out[nm] = int(len(v))
        out[nm + "_dev"] = int((sg == "dev").sum())
        for d in v[:200]:
            ev.append({"check": "A2", "event": nm, "day": str(d.date()), "segment": segment([d])[0]})
    sg = segment(days)
    for s in ("dev", "holdout", "post_cas"):
        cs = cal[(segment(cal) == s) & (cal >= lo) & (cal <= hi)]
        out[f"calendar_{s}"] = int(len(cs))
        out[f"sessions_{s}"] = int((sg == s).sum())
        out[f"clean_{s}"] = int((S["clean"].to_numpy(bool) & (sg == s)).sum())
    first_daily = dd.min() if len(dd) else lo
    dev_cal = cal[(cal >= max(E.DEV[0], first_daily)) & (cal <= E.DEV[1])]
    out["dev_calendar_listed"] = int(len(dev_cal))
    out["clean_share_dev"] = out["clean_dev"] / len(dev_cal) if len(dev_cal) else np.nan
    return out, ev


def a3_bars(B: Dict[str, np.ndarray], days: pd.DatetimeIndex) -> dict:
    O, H, L, C, V = (B[k] for k in ("open", "high", "low", "close", "volume"))
    fin = np.isfinite(C)
    with np.errstate(invalid="ignore"):
        bad_hi = fin & (H < np.fmax(O, C) - 1e-9)
        bad_lo = fin & (L > np.fmin(O, C) + 1e-9)
        nonpos = fin & ((O <= 0) | (H <= 0) | (L <= 0) | (C <= 0))
        negv = fin & (V < 0)
        zerov = fin & (V == 0)
        flat = fin & (H == L)
    stale = np.zeros_like(fin)
    run = int(CFG["a_stale_run"])
    same = np.zeros_like(fin)
    same[:, 1:] = fin[:, 1:] & (C[:, 1:] == C[:, :-1]) & zerov[:, 1:]
    cnt = np.zeros(C.shape[0])
    for k in range(C.shape[1]):
        cnt = np.where(same[:, k], cnt + 1, 0)
        stale[:, k] = cnt >= run - 1
    dev = (segment(days) == "dev")[:, None]
    out = {"bars": int(fin.sum()), "bars_dev": int((fin & dev).sum())}
    for nm, v in (("high_below_body", bad_hi), ("low_above_body", bad_lo), ("price_not_positive", nonpos), ("negative_volume", negv),
                  ("zero_volume", zerov), ("flat_bar", flat), ("stale_run_bar", stale)):
        out[nm] = int(v.sum())
        out[nm + "_dev"] = int((v & dev).sum())
    return out


def a4_reconcile(S: pd.DataFrame) -> Tuple[dict, pd.DataFrame]:
    yr = pd.DatetimeIndex(S["day"]).year
    T = S.assign(year=yr).groupby("year").agg(sessions=("day", "size"), reconcile_ok=("rec_ok", "mean"),
                                              price_ok=("rec_price_ok", "mean"), volume_ok=("rec_volume_ok", "mean"),
                                              basis_mismatch=("rec_basis_mismatch", "sum")).reset_index()
    sg = segment(S["day"])
    out = {}
    for s in ("dev", "holdout", "post_cas"):
        m = sg == s
        out[f"reconcile_ok_{s}"] = float(S.loc[m, "rec_ok"].mean()) if m.any() else np.nan
    return out, T


def a5_basis(S: pd.DataFrame, ctx: pd.DataFrame, daily: pd.DataFrame, B: Dict[str, np.ndarray]) -> Tuple[dict, List[dict]]:
    ev = []
    dd = pd.DatetimeIndex(daily["day"])
    with np.errstate(invalid="ignore", divide="ignore"):
        pc = daily["close"].shift(1).to_numpy(float)
        r_open = daily["open"].to_numpy(float) / pc
    for j in np.flatnonzero(ctx["split_jump"].to_numpy(bool)):
        ev.append({"check": "A5", "event": "daily_split_like_jump", "day": str(dd[j].date()), "segment": segment([dd[j]])[0],
                   "ratio": float(r_open[j])})
    days = pd.DatetimeIndex(S["day"])
    O0 = B["open"][:, 0]
    last = E.ffill_rows(B["close"])[:, -1]
    with np.errstate(invalid="ignore", divide="ignore"):
        r3 = O0[1:] / last[:-1]
    for j in np.flatnonzero(E.split_like(r3)):
        ev.append({"check": "A5", "event": "bars_split_like_jump", "day": str(days[j + 1].date()), "segment": segment([days[j + 1]])[0],
                   "ratio": float(r3[j])})
    ratio = S["rec_ratio"].to_numpy(float)
    with np.errstate(invalid="ignore", divide="ignore"):
        off = np.abs(np.log(ratio)) > float(CFG["a_basis_tol"])
    off = np.where(np.isfinite(ratio), off, False)
    runs, j = [], 0
    while j < len(off):
        if off[j]:
            k = j
            while k + 1 < len(off) and off[k + 1]:
                k += 1
            runs.append((j, k))
            j = k + 1
        else:
            j += 1
    for a, b in runs:
        ev.append({"check": "A5", "event": "basis_segment", "day": str(days[a].date()), "to": str(days[b].date()), "sessions": int(b - a + 1),
                   "segment": segment([days[a]])[0], "ratio": float(np.nanmedian(ratio[a:b + 1]))})
    win = (days >= CTX_FROM) & (days <= E.DEV[1])
    in_win_d = [e for e in ev if e["event"] != "basis_segment" and CTX_FROM <= pd.Timestamp(e["day"]) <= E.DEV[1]]
    seg_sessions = np.zeros(len(days), bool)
    for a, b in runs:
        seg_sessions[a:b + 1] = True
    dev = (days >= E.DEV[0]) & (days <= E.DEV[1])
    affected = (seg_sessions | ~S["context_clean"].to_numpy(bool)) & dev
    out = {"split_like_daily": sum(e["event"] == "daily_split_like_jump" for e in ev),
           "split_like_bars": sum(e["event"] == "bars_split_like_jump" for e in ev),
           "basis_segments": len(runs), "basis_sessions_dev": int((seg_sessions & dev).sum()),
           "basis_events_context_window": len(in_win_d) + sum(1 for a, b in runs if (win[a:b + 1]).any()),
           "affected_share_dev": float(affected.sum() / max(dev.sum(), 1)),
           "affected_all_excluded": bool(not (affected & S["clean"].to_numpy(bool)).any())}
    return out, ev


def a6_weekly(S: pd.DataFrame, daily: pd.DataFrame, B: Dict[str, np.ndarray]) -> dict:
    """Weekly bars from the daily file vs from the 3-minute sessions (close = the 15:00-15:30 VWAP, the official close),
    development weeks in which every daily row has a clean 3-minute session."""
    days = pd.DatetimeIndex(S["day"])
    H, L, C, V = B["high"], B["low"], B["close"], B["volume"]
    tp = (H[:, 115:] + L[:, 115:] + C[:, 115:]) / 3
    vw = np.where(np.isfinite(V[:, 115:]), V[:, 115:], 0.0)
    with np.errstate(invalid="ignore", divide="ignore"):
        cl = np.where(vw.sum(1) > 0, np.nansum(tp * vw, 1) / vw.sum(1), np.nanmean(tp, 1))
    s3 = pd.DataFrame({"day": days, "o": B["open"][:, 0], "h": BM._rowmax(H), "l": BM._rowmin(L), "c": cl,
                       "clean": S["clean"].to_numpy(bool)})
    d = daily[["day", "open", "high", "low", "close"]].copy()
    d = d[(d["day"] >= E.DEV[0]) & (d["day"] <= E.DEV[1])]
    wk = lambda x: x - pd.to_timedelta(x.dt.weekday, unit="D")
    d["wk"] = wk(d["day"])
    s3 = s3[(s3["day"] >= E.DEV[0]) & (s3["day"] <= E.DEV[1])].copy()
    s3["wk"] = wk(s3["day"])
    J = d.merge(s3, on=["day", "wk"], how="left")
    full = J.groupby("wk")["clean"].apply(lambda x: bool(x.fillna(False).astype(bool).all()))
    gd = J.groupby("wk").agg(o=("open", "first"), h=("high", "max"), l=("low", "min"), c=("close", "last"))
    g3 = J.groupby("wk").agg(o=("o", "first"), h=("h", "max"), l=("l", "min"), c=("c", "last"))
    tol = float(CFG["a_week_tol"])
    with np.errstate(invalid="ignore", divide="ignore"):
        agree = ((g3 / gd - 1).abs() <= tol).all(axis=1)
    ok = full.reindex(gd.index).fillna(False).to_numpy(bool)
    n = int(ok.sum())
    return {"weeks_dev": int(len(gd)), "weeks_comparable": n, "weekly_agree": float(agree.to_numpy(bool)[ok].mean()) if n else np.nan}


def a8_execution(S: pd.DataFrame, B: Dict[str, np.ndarray], daily: pd.DataFrame) -> dict:
    m = S["clean"].to_numpy(bool) & (segment(S["day"]) == "dev")
    O, H, L, C, V = (B[k][m] for k in ("open", "high", "low", "close", "volume"))
    out = {"sessions": int(m.sum())}
    if not m.any():
        return out
    k = E.DEC_BARS
    dec = np.isfinite(C[:, k])
    nxt = np.isfinite(O[:, k + 1])
    out["next_bar_missing"] = float(((~nxt) & dec).sum() / max(dec.sum(), 1))
    e = np.stack([BM.first_true(np.isfinite(O), kk + 1, E.E_LAST) for kk in k], axis=1)
    out["no_entry_by_1430"] = float(((e < 0) & dec).sum() / max(dec.sum(), 1))
    out["exit_bar_present"] = float(np.isfinite(O[:, E.X_BAR]).mean())
    with np.errstate(invalid="ignore", divide="ignore"):
        j = np.abs(O[:, 1:] / C[:, :-1] - 1) * 1e4
        rng = (H - L) / C * 1e4
        part = float(CFG["notional_rs"]) / (C[:, k] * V[:, k])
    jf, rf = j[np.isfinite(j)], rng[np.isfinite(rng)]
    out["jump_bp_median"], out["jump_bp_p99"] = (float(np.median(jf)), float(np.percentile(jf, 99))) if len(jf) else (np.nan, np.nan)
    out["bar_range_bp_median"] = float(np.median(rf)) if len(rf) else np.nan
    out["zero_volume_at_decision"] = float(((V[:, k] == 0) & dec).sum() / max(dec.sum(), 1))
    pf = part[np.isfinite(part) & dec]
    out["participation_median"], out["participation_p90"] = (float(np.median(pf)), float(np.percentile(pf, 90))) if len(pf) else (np.nan, np.nan)
    dd = daily[(daily["day"] >= E.DEV[0]) & (daily["day"] <= E.DEV[1])]
    out["locked_days_dev"] = int((dd["high"] <= dd["low"]).sum())
    return out


# ----------------------------------------------------------------------
# the run
# ----------------------------------------------------------------------
def audit_stock(root, sym, sec, dq, IC, cal, reconcile, mkt, secs, mkt_raw, secs_raw, seed, log=_log) -> Tuple[dict, List[dict], pd.DataFrame, pd.DataFrame]:
    row = {"symbol": sym, "sector": sec or ""}
    reasons = []
    fp = Path(dq._paths(root, sym)[0])
    f = E.bar_file(root, IC, sym)
    if not fp.exists() or f is None:
        row["status"] = "FIX NEEDED"
        row["reasons"] = "no daily file" if not fp.exists() else "no 3-minute file"
        return row, [], pd.DataFrame(), pd.DataFrame()
    daily = E.load_daily(root, sym, dq)
    X, a1 = a1_bars(f)
    row.update(a1)
    row.update(a1_daily(fp))
    r = E.build_symbol(daily, X, cal, reconcile, mkt, secs.get(sec) if sec else None, with_outcomes=False)
    S, ctx, B = r["S"], r["ctx"], r["B"]
    a2, ev2 = a2_sessions(S, daily, cal)
    row.update(a2)
    row.update(a3_bars(B, pd.DatetimeIndex(S["day"])))
    a4, years = a4_reconcile(S)
    row.update(a4)
    a5, ev5 = a5_basis(S, ctx, daily, B)
    row.update(a5)
    row.update(a6_weekly(S, daily, B))
    row.update({"exe_" + k: v for k, v in a8_execution(S, B, daily).items()})
    t0 = time.time()
    pit = E.pit_check(daily, X, cal, mkt_raw, secs_raw.get(sec) if sec else None, r, int(CFG["a_pit_days"]), seed)
    row.update({"pit_checked": pit["checked"], "pit_failed": pit["failed"], "pit_failures": json.dumps(pit["failures"])})
    # the gate
    if not (row.get("clean_share_dev", 0) >= CFG["a_usable_min"]):
        reasons.append(f"clean sessions {row.get('clean_share_dev', 0) * 100:.1f}% of development sessions (< {CFG['a_usable_min'] * 100:.0f}%)")
    bad = row["off_grid_dev"] + row["duplicate_dev"] + row["outside_session_dev"] + row["weekend_dev"]
    if row["rows_dev"] and bad / row["rows_dev"] > CFG["a_badrow_max"]:
        reasons.append(f"{bad:,} off-grid / duplicate / out-of-session rows in development ({bad / row['rows_dev'] * 100:.2f}%)")
    if row["daily_not_midnight_ist"]:
        reasons.append(f"{row['daily_not_midnight_ist']:,} daily timestamps are not midnight IST (day attribution risk)")
    if row["basis_events_context_window"] and not (row["affected_share_dev"] <= CFG["a_basis_max"] and row["affected_all_excluded"]):
        reasons.append(f"{row['basis_events_context_window']} adjustment-basis / split-like event(s) in "
                       f"{CTX_FROM.date()}..{CFG['dev_end']} touching {row['affected_share_dev'] * 100:.1f}% of development sessions - refetch")
    if not (row.get("weekly_agree", 0) >= CFG["a_weekly_min"]):
        reasons.append(f"weekly bars agree on {row.get('weekly_agree', 0) * 100:.1f}% of comparable weeks (< {CFG['a_weekly_min'] * 100:.0f}%)")
    if pit["checked"] < int(CFG["a_pit_days"]) or pit["failed"]:
        reasons.append(f"point-in-time check {pit['checked'] - pit['failed']} of {CFG['a_pit_days']} passed" +
                       (" - ENGINE BUG, stop" if pit["failed"] else " (too few clean development sessions)"))
    row["status"] = "PASS" if not reasons else "FIX NEEDED"
    row["reasons"] = "; ".join(reasons)
    log(f"  {sym}: {row['status']}" + (f" - {row['reasons']}" if reasons else "") + f"  (point-in-time check {time.time() - t0:.0f} s)")
    ses = S[["day", "in_calendar", "usable", "rec_ok", "rec_price_ok", "rec_volume_ok", "rec_basis_mismatch", "rec_ratio", "liquid",
             "basis_guard", "context_clean", "clean", "bars"]].assign(symbol=sym, segment=segment(S["day"]))
    for e in ev2 + ev5:
        e["symbol"] = sym
    return row, ev2 + ev5, ses, years.assign(symbol=sym)


def audit_index(root, name, dq, IC) -> dict:
    out = {"index": name}
    f = E.bar_file(root, IC, name)
    d = E.load_daily(root, E.INDEX[name][1], dq)
    out["bars_file"] = f.name if f is not None else None
    out["daily_file"] = d is not None
    if f is None:
        out["status"] = "MISSING"
        return out
    X = E.grid_bars(E.load_bars(f))
    days, B = BM.bar_matrix(X)
    seg = segment(days)
    out["sessions_dev"] = int((seg == "dev").sum())
    out["usable_dev"] = float(BM.usable_sessions(B)[seg == "dev"].mean()) if (seg == "dev").any() else np.nan
    if d is not None and hasattr(IC, "reconcile_index"):
        J = IC.reconcile_index(X, d, float(IC.DECL["reconcile_price_tol"]))
        if len(J):
            js = segment(pd.to_datetime(J["day"]))
            out["agree_dev"] = float(J.loc[js == "dev", "ok"].mean()) if (js == "dev").any() else np.nan
            out["agree_holdout"] = float(J.loc[js != "dev", "ok"].mean()) if (js != "dev").any() else np.nan
    return out


def write_report(out: Path, rows: pd.DataFrame, idx: List[dict], ev: pd.DataFrame, info: dict, stage_pass: bool) -> None:
    L = ["# Stage A - data integrity of the engine's stocks", "",
         f"{CODE_VERSION} | {E.CODE_VERSION} | declaration {E.DECL_SHA} | {info['at']} | stocks {', '.join(rows['symbol'])} "
         f"(list {info['stocks_hash']})" + (f" | RERUN #{len(info['rerun']) + 1}" if info["rerun"] else ""), "",
         f"## VERDICT: {'PASS' if stage_pass else 'FIX NEEDED'}", ""]
    if stage_pass:
        L.append("Every stock and the market data pass the declared checks: Stage B can run on this data.")
    else:
        L.append("Fix the items below before Stage B (usually: refetch the named file). The engine does not swap stocks; "
                 "replacing a stock is Karan's decision.")
    L += ["", "| stock | status | clean dev sessions | reconcile dev / holdout / post-CAS | basis events | weekly agree | PIT | reasons |",
          "|---|---|---|---|---|---|---|---|"]
    pct = lambda x: "-" if x is None or not np.isfinite(x) else f"{x * 100:.1f}%"
    for _, r in rows.iterrows():
        L.append(f"| {r['symbol']} | **{r['status']}** | {pct(r.get('clean_share_dev', np.nan))} ({int(r.get('clean_dev', 0) or 0):,}) | "
                 f"{pct(r.get('reconcile_ok_dev', np.nan))} / {pct(r.get('reconcile_ok_holdout', np.nan))} / {pct(r.get('reconcile_ok_post_cas', np.nan))} | "
                 f"{int(r.get('basis_events_context_window', 0) or 0)} | {pct(r.get('weekly_agree', np.nan))} | "
                 f"{int(r.get('pit_checked', 0) or 0) - int(r.get('pit_failed', 0) or 0)}/{int(r.get('pit_checked', 0) or 0)} | {r.get('reasons', '')} |")
    L += ["", "## Market and sector indices", "", "| index | 3-minute file | development sessions | usable | agrees with daily (dev / later) | status |",
          "|---|---|---|---|---|---|"]
    for d in idx:
        L.append(f"| {d['index']} | {d.get('bars_file') or 'none'} | {d.get('sessions_dev', '-')} | {pct(d.get('usable_dev', np.nan))} | "
                 f"{pct(d.get('agree_dev', np.nan))} / {pct(d.get('agree_holdout', np.nan))} | {d.get('status', '')} |")
    L += ["", "## A1 timestamps (whole file)", "", "| stock | zone | rows | off-grid | outside 09:15-15:27 | weekend | duplicates | out of order | daily zone | daily not midnight IST |",
          "|---|---|---|---|---|---|---|---|---|---|"]
    for _, r in rows.iterrows():
        L.append(f"| {r['symbol']} | {r.get('tz', '-')} | {int(r.get('rows', 0) or 0):,} | {int(r.get('off_grid', 0) or 0)} | {int(r.get('outside_session', 0) or 0)} | "
                 f"{int(r.get('weekend', 0) or 0)} | {int(r.get('duplicate', 0) or 0)} | {int(r.get('out_of_order', 0) or 0)} | {r.get('daily_tz', '-')} | "
                 f"{int(r.get('daily_not_midnight_ist', 0) or 0)} |")
    L += ["", "## A2 sessions and A3 bars", "", "| stock | missing sessions (dev) | extra sessions | daily rows off calendar | short sessions (dev) | "
          "high/low outside body | zero-volume bars (dev) | flat bars (dev) | stale-run bars (dev) |", "|---|---|---|---|---|---|---|---|---|"]
    for _, r in rows.iterrows():
        g = lambda c: int(r.get(c, 0) or 0)
        L.append(f"| {r['symbol']} | {g('missing_sessions')} ({g('missing_sessions_dev')}) | {g('extra_sessions')} | {g('daily_off_calendar')} | "
                 f"{g('short_sessions')} ({g('short_sessions_dev')}) | {g('high_below_body') + g('low_above_body')} | {g('zero_volume_dev'):,} | "
                 f"{g('flat_bar_dev'):,} | {g('stale_run_bar_dev'):,} |")
    L += ["", "## A8 execution realism (development, clean sessions)", "",
          "| stock | next bar missing | no entry by 14:30 | 15:03 bar present | bar-to-bar jump bp (median / p99) | 3-min range bp (median) | "
          "zero volume at decision | Rs 5 lakh share of decision bar (median / p90) | locked days |", "|---|---|---|---|---|---|---|---|---|"]
    for _, r in rows.iterrows():
        g = lambda c: r.get("exe_" + c, np.nan)
        L.append(f"| {r['symbol']} | {pct(g('next_bar_missing'))} | {pct(g('no_entry_by_1430'))} | {pct(g('exit_bar_present'))} | "
                 f"{g('jump_bp_median'):.1f} / {g('jump_bp_p99'):.1f} | {g('bar_range_bp_median'):.1f} | {pct(g('zero_volume_at_decision'))} | "
                 f"{pct(g('participation_median'))} / {pct(g('participation_p90'))} | {int(g('locked_days_dev') or 0) if np.isfinite(g('locked_days_dev')) else '-'} |"
                 if np.isfinite(g("jump_bp_median")) else f"| {r['symbol']} | - | - | - | - | - | - | - | - |")
    L += ["", f"Slippage assumed later: 5 bp at entry, 3 bp at a time exit, 5 bp at a stop. A median bar-to-bar jump or a "
          f"participation share well above those levels means the assumption is optimistic for that stock.", ""]
    if len(ev):
        L += ["## A5 adjustment-basis and split-like events", "", "| stock | event | day | to | sessions | ratio | segment |", "|---|---|---|---|---|---|---|"]
        for _, e in ev[ev["check"] == "A5"].iterrows():
            L.append(f"| {e['symbol']} | {e['event']} | {e['day']} | {e.get('to', '') if isinstance(e.get('to', ''), str) else ''} | "
                     f"{'' if pd.isna(e.get('sessions', np.nan)) else int(e['sessions'])} | {e.get('ratio', np.nan):.3f} | {e['segment']} |")
    L += ["", "Full detail: stocks.csv (every number), events.csv (every event with its date), sessions.csv (every session's "
          "clean-session flags), reconcile_by_year.csv.", ""]
    (out / "report.md").write_text("\n".join(L), encoding="utf-8")


def previous_runs(root: Path, stocks_hash: str) -> List[str]:
    f = root / "panel" / "research_ledger.jsonl"
    out = []
    if f.exists():
        for line in f.read_text(encoding="utf-8").splitlines():
            try:
                rec = json.loads(line)
            except Exception:
                continue
            if rec.get("family") == E.DECL["family_id"] and rec.get("stage") == "A" and rec.get("stocks_hash") == stocks_hash:
                out.append(str(rec.get("run")))
    return out


def run(root: Path, stocks: List[Tuple[str, Optional[str]]], dq, IC, reconcile, log=_log) -> Tuple[Path, bool]:
    E.check_reuse()
    sh = E.stocks_hash(stocks)
    prev = previous_runs(root, sh)
    log(f"{CODE_VERSION} (declaration {E.DECL_SHA}): {len(stocks)} stocks; every period read for structure, development for the rest")
    nd = E.load_daily(root, "NIFTY50", dq)
    if nd is None:
        raise E.PreconditionError("no NIFTY50 daily file: it is the session calendar")
    cal = pd.DatetimeIndex(nd["day"])
    nb = E.load_bars(E.bar_file(root, IC, "NIFTY 50"))
    mkt = E.index_panel(nd, nb)
    secs, secs_raw = {}, {}
    for s in sorted({sec for _, sec in stocks if sec}):
        d_ = E.load_daily(root, E.INDEX[s][1], dq)
        x_ = E.load_bars(E.bar_file(root, IC, s))
        secs[s], secs_raw[s] = E.index_panel(d_, x_), (d_, x_)
    idx = [audit_index(root, nm, dq, IC) for nm in ["NIFTY 50"] + sorted(secs)]
    for d in idx:
        if d.get("status") != "MISSING":
            ok = d.get("agree_dev", np.nan)
            d["status"] = "PASS" if (np.isfinite(ok) and ok >= CFG["a_index_min"]) or (not np.isfinite(ok) and d["index"] != "NIFTY 50") else "FIX NEEDED"
    rows, evs, sess, years = [], [], [], []
    for j, (sym, sec) in enumerate(stocks):
        r, ev, ses, yr = audit_stock(root, sym, sec, dq, IC, cal, reconcile, mkt, secs, (nd, nb), secs_raw, int(CFG["seed"]) + j, log)
        rows.append(r)
        evs += ev
        sess.append(ses)
        years.append(yr)
    R = pd.DataFrame(rows)
    EV = pd.DataFrame(evs)
    mkt_ok = idx[0].get("status") == "PASS"
    stage_pass = bool((R["status"] == "PASS").all()) and mkt_ok
    base = root / "research2" / "engine"
    base.mkdir(parents=True, exist_ok=True)
    day = dt.date.today().strftime("%Y%m%d")
    n = 1
    while (base / f"A_{day}_{n:03d}").exists():
        n += 1
    out = base / f"A_{day}_{n:03d}"
    out.mkdir()
    info = {"at": f"{dt.datetime.now():%Y-%m-%d %H:%M}", "stocks_hash": sh, "rerun": prev}
    write_report(out, R, idx, EV, info, stage_pass)
    R.to_csv(out / "stocks.csv", index=False)
    EV.to_csv(out / "events.csv", index=False)
    pd.concat(sess, ignore_index=True).to_csv(out / "sessions.csv", index=False)
    pd.concat(years, ignore_index=True).to_csv(out / "reconcile_by_year.csv", index=False)
    summ = {"tool": CODE_VERSION, "core": E.CODE_VERSION, "declaration": E.DECL_SHA, "verdict": "PASS" if stage_pass else "FIX NEEDED",
            "stocks": stocks, "stocks_hash": sh, "rerun_of": prev, "indices": idx,
            "per_stock": {r["symbol"]: {"status": r["status"], "reasons": r["reasons"]} for r in rows}}
    (out / "summary.json").write_text(json.dumps(summ, indent=2, default=str), encoding="utf-8")
    prov = {"tool": CODE_VERSION, "declaration": E.DECL_SHA, "python": platform.python_version(), "numpy": np.__version__,
            "pandas": pd.__version__, "platform": platform.platform(),
            "code_sha256_16": {p: BM._sha_path(HERE / p) for p in ("engine_stage_a.py", "engine_core.py")}}
    BM.seal_outputs(out, prov)
    BM.write_ledger(root, {"kind": "audit", "tool": CODE_VERSION, "family": E.DECL["family_id"], "stage": "A", "declaration": E.DECL_SHA,
                           "run": out.name, "stocks": [s for s, _ in stocks], "stocks_hash": sh, "fresh": not prev, "previous_runs": prev,
                           "verdict": "PASS" if stage_pass else "FIX NEEDED",
                           "fix_needed": [r["symbol"] for r in rows if r["status"] != "PASS"]})
    return out, stage_pass


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description="Stage A: data integrity of the engine's stocks")
    ap.add_argument("--root", required=True)
    ap.add_argument("--stocks", default=str(HERE / "engine_stocks.txt"))
    a = ap.parse_args(argv)
    root = Path(a.root)
    if not root.is_dir():
        raise E.PreconditionError(f"--root {root} is not a folder - run 'call env_daily.bat' and pass --root %CACHE_DAILY_ROOT%")
    stocks = E.read_stocks(Path(a.stocks))
    import data_quality as dq
    import intraday_cache as IC
    tol_p, tol_v = IC.DECL["reconcile_price_tol"], IC.DECL["reconcile_volume_tol"]
    reconcile = lambda Xg, d: IC.reconcile_symbol(Xg, d, tol_p, tol_v)
    t0 = time.time()
    out, ok = run(root, stocks, dq, IC, reconcile)
    _log(f"VERDICT: {'PASS' if ok else 'FIX NEEDED'}  ({time.time() - t0:.0f} s)")
    print(f"  report: {out / 'report.md'}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
