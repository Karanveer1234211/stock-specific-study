# Behavioural engine - Stage A (data integrity) and Stage B (state discovery)

Spec: `ENGINE_SPEC.md` (your message of 11 Oct 2026, word for word, plus freeze notes).
Rules: `ENGINE_DECLARATION.json` (frozen before any real-data run; the fingerprint is printed on every report).

## Files

| file | goes in | what it is |
|---|---|---|
| ENGINE_SPEC.md, ENGINE_DECLARATION.json, ENGINE_README.md | `bigmove_deploy\open_close\` | spec, frozen rules, this page |
| engine_core.py | `bigmove_deploy\open_close\` | loading, clean sessions, point-in-time features, outcomes, look-ahead check |
| engine_models.py | `bigmove_deploy\open_close\` | k-means, Gaussian mixture, HMM (filtered only), human grid, nearest neighbours (numpy only) |
| engine_stage_a.py | `bigmove_deploy\open_close\` | Stage A: is the data clean enough to learn from? |
| engine_stage_b.py | `bigmove_deploy\open_close\` | Stage B: do learned states predict anything beyond each stock's time-of-day baseline? |
| engine_stocks.txt | `bigmove_deploy\open_close\` | YOUR 10 stocks, one per line (optional `, NIFTY BANK` or `, NIFTY IT`) |
| tests\engine_world.py, tests\test_engine.py | `bigmove_deploy\open_close\tests\` | synthetic market and the test suite (no real data) |

Needs `bigmove_study.py`, `intraday_cache.py`, `data_quality.py` and `soul_intraday_study.py` where they already are (bigmove_deploy).

## Run (Windows cmd)

```
cd /d C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy
call env_daily.bat
set PYTHONPATH=C:\Users\karanvsi\PyCharmMiscProject\bigmove_deploy
cd open_close
python tests\test_engine.py
python engine_stage_a.py --root %CACHE_DAILY_ROOT%
python engine_stage_b.py --root %CACHE_DAILY_ROOT%
```

1. The tests end with `VERIFIED` (about 20 minutes; `python tests\test_engine.py hand lookahead models` is a 1-minute subset).
2. Fill in `engine_stocks.txt` first. Stage A and Stage B refuse to run without it.
3. Stage A writes `%CACHE_DAILY_ROOT%\research2\engine\A_<date>_<n>\report.md`. If it says FIX NEEDED, send the report; do not run Stage B on a stock that failed.
4. Stage B (about 5 minutes for 10 stocks) writes `%CACHE_DAILY_ROOT%\research2\engine\B_<date>_<n>\report.md` and one line per representation in `research2\engine\experiments.jsonl`.
5. Paste both report.md files into the project.

Stage B reads nothing after 2024-12-31. 2025-01-01..2026-07-31 is the lightly exposed holdout for a later stage (used once); there is no fully untouched historical period, so the clean test is forward data from 12 Oct 2026.

Each run adds one line to `panel\research_ledger.jsonl`. Running the same stage again with the same declaration and stock list is stamped RERUN and is not fresh evidence.
