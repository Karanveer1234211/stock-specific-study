"""
intraday_lab / costs.py
NSE round-trip cost model (Zerodha-style charges), date-aware.

VERIFY the current rates on https://zerodha.com/charges before trusting results:
statutory charges change by budget/circular. Every rate below is in one table so
a change is a one-line edit.

All functions return costs as a FRACTION of notional (0.0005 = 5 bp).
"""
import datetime as dt
import config

# (effective_from, rate). Rate applies from that date until the next entry.
STT_SELL = {
    "equity_intraday": [(dt.date(2004, 10, 1), 0.00025)],
    "index_fut": [
        (dt.date(2008, 6, 1), 0.0001),
        (dt.date(2023, 4, 1), 0.000125),
        (dt.date(2024, 10, 1), 0.0002),
        (dt.date(2026, 4, 1), 0.0005),     # Budget 2026 hike
    ],
}
EXCHANGE_TXN = {   # NSE transaction charges, both sides
    "equity_intraday": [(dt.date(2010, 1, 1), 0.0000345), (dt.date(2024, 10, 1), 0.0000297)],
    "index_fut": [(dt.date(2010, 1, 1), 0.00002), (dt.date(2024, 10, 1), 0.0000173)],
}
STAMP_BUY = {"equity_intraday": 0.00003, "index_fut": 0.00002}
SEBI_FEE = 0.000001          # Rs 10 per crore, both sides
GST = 0.18                   # on brokerage + exchange + SEBI fee
BROKERAGE_PCT = 0.0003       # 0.03% ...
BROKERAGE_CAP = 20.0         # ... or Rs 20 per executed order, whichever lower


def _rate(table, instrument, date):
    sched = table[instrument]
    r = sched[0][1]
    for start, val in sched:
        if date >= start:
            r = val
    return r


def statutory_round_trip(instrument, date=None, notional=None, mode=None):
    """Brokerage + STT + exchange + SEBI + stamp + GST for one buy and one sell."""
    mode = mode or config.COST_MODE
    if mode == "current" or date is None:
        date = dt.date.today()
    notional = notional or config.NOTIONAL[instrument]
    brokerage_side = min(BROKERAGE_PCT * notional, BROKERAGE_CAP) / notional
    stt = _rate(STT_SELL, instrument, date)
    exch = _rate(EXCHANGE_TXN, instrument, date)
    brokerage = 2 * brokerage_side
    exch_rt = 2 * exch
    sebi_rt = 2 * SEBI_FEE
    gst = GST * (brokerage + exch_rt + sebi_rt)
    return brokerage + stt + exch_rt + sebi_rt + STAMP_BUY[instrument] + gst


def slippage_round_trip(instrument, mult=1.0):
    return 2 * config.SLIPPAGE_BPS_PER_SIDE[instrument] * 1e-4 * mult


def cost_table(instrument):
    """Human-readable breakdown, printed in reports."""
    rt = statutory_round_trip(instrument)
    sl = slippage_round_trip(instrument)
    return (f"{instrument}: statutory {rt*1e4:.2f} bp + slippage {sl*1e4:.2f} bp "
            f"= {(rt+sl)*1e4:.2f} bp round trip (mode={config.COST_MODE})")


if __name__ == "__main__":
    for ins in ("equity_intraday", "index_fut"):
        print(cost_table(ins))
        for d in (dt.date(2020, 1, 1), dt.date(2024, 1, 1), dt.date(2025, 1, 1), dt.date(2026, 6, 1)):
            print(f"   historical {d}: {statutory_round_trip(ins, d, mode='historical')*1e4:.2f} bp")
