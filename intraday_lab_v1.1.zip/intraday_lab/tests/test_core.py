"""
intraday_lab / tests/test_core.py
Permanent checks of the statistics and plumbing.  Run:  python -m pytest tests -q
(The SPA cross-check needs the 'arch' package: pip install arch)
"""
import datetime as dt
import math
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest
from scipy import stats

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import costs            # noqa: E402
import validation as V  # noqa: E402


# ----------------------------------------------------------------------------- SPA / RC
def test_spa_matches_arch_package():
    arch = pytest.importorskip("arch.bootstrap")
    rng = np.random.default_rng(1)
    T, N = 1200, 20
    F = rng.standard_normal((T, N)) * 0.01
    F[:, 3] += 0.0012
    mine = V.reality_check_spa(F, B=4000, mean_block=10, seed=3)
    spa = arch.SPA(np.zeros(T), -F, block_size=10, reps=4000, seed=3)   # arch works with losses
    spa.compute()
    ref = spa.pvalues
    for mine_k, ref_k in (("spa_l", "lower"), ("spa_c", "consistent"), ("spa_u", "upper")):
        assert abs(mine[mine_k] - ref[ref_k]) < 0.03, (mine_k, mine[mine_k], ref[ref_k])


def test_spa_size_under_null():
    """With no edge, SPA(consistent) should reject at 5% rarely (allow sampling slack)."""
    rej = 0
    for s in range(30):
        rng = np.random.default_rng(100 + s)
        F = rng.standard_normal((400, 8)) * 0.01
        rej += V.reality_check_spa(F, B=300, mean_block=5, seed=s)["spa_c"] < 0.05
    assert rej / 30 <= 0.15


def test_spa_power_with_edge():
    rng = np.random.default_rng(7)
    F = rng.standard_normal((1000, 10)) * 0.01
    F[:, 0] += 0.002
    assert V.reality_check_spa(F, B=1000, mean_block=5, seed=1)["spa_c"] < 0.01


# ----------------------------------------------------------------------------- DSR / PSR
def test_expected_max_sharpe_reference_value():
    # Bailey & Lopez de Prado: ~3.26 for 1,000 trials with unit Sharpe variance
    assert abs(V.expected_max_sr(1.0, 1000) - 3.26) < 0.01
    assert V.expected_max_sr(1.0, 1) == 0.0


def test_psr_normal_case():
    sr, T = 0.05, 1000
    expected = stats.norm.cdf(sr * math.sqrt(T - 1) / math.sqrt(1 + sr ** 2 / 2))
    assert abs(V.psr(sr, T, 0.0, 3.0) - expected) < 1e-12


def test_dsr_penalises_more_trials():
    rng = np.random.default_rng(3)
    M = rng.standard_normal((1000, 50)) * 0.01
    best = M[:, np.argmax(M.mean(0) / M.std(0))]
    few = V.deflated_sharpe(best, M[:, :5])["dsr"]
    many = V.deflated_sharpe(best, M, n_trials_total=500)["dsr"]
    assert many < few


def test_effective_n():
    rng = np.random.default_rng(0)
    x = rng.standard_normal((500, 1))
    same = np.repeat(x, 10, axis=1) + 1e-9 * rng.standard_normal((500, 10))
    assert V.effective_n(same) < 1.5
    assert V.effective_n(rng.standard_normal((500, 10))) > 8


# ----------------------------------------------------------------------------- PBO
def test_pbo_noise_is_coin_flip():
    """On pure noise PBO is ~0.5 ON AVERAGE; a single sample is very noisy (0.2-0.9),
    which is why PBO is never used alone."""
    r = [V.pbo_cscv(np.random.default_rng(s).standard_normal((1600, 20)) * 0.01, S=12)["pbo"] for s in range(12)]
    assert 0.4 < np.mean(r) < 0.75


def test_pbo_real_winner_is_low():
    rng = np.random.default_rng(12)
    M = rng.standard_normal((1600, 20)) * 0.01
    M[:, 5] += 0.002
    assert V.pbo_cscv(M, S=12)["pbo"] < 0.1


# ----------------------------------------------------------------------------- bootstrap
def test_stationary_bootstrap_block_length():
    rng = np.random.default_rng(5)
    idx = V.stationary_bootstrap_indices(2000, 50, 10, rng)
    jumps = (np.diff(idx, axis=1) != 1).mean()
    assert 0.07 < jumps < 0.13          # new block with prob 1/10 (plus wrap-around)


def test_block_ci_contains_mean():
    x = np.random.default_rng(2).standard_normal(500) * 0.01 + 0.001
    m, lo, hi = V.block_bootstrap_ci(x, B=500)
    assert lo < m < hi


# ----------------------------------------------------------------------------- walk-forward
def test_walk_forward_picks_consistent_winner():
    idx = pd.bdate_range("2018-01-01", "2022-12-31")
    rng = np.random.default_rng(4)
    M = pd.DataFrame(rng.standard_normal((len(idx), 4)) * 0.01, index=idx, columns=list("abcd"))
    M["c"] += 0.003
    tab, oos = V.walk_forward_selection(M, embargo_days=5)
    assert (tab["picked"] == "c").all()
    assert oos.index.min().year == 2019        # first year has no training data


# ----------------------------------------------------------------------------- costs
def test_futures_stt_schedule():
    r = lambda d: costs._rate(costs.STT_SELL, "index_fut", d)
    assert r(dt.date(2022, 1, 1)) == 0.0001
    assert r(dt.date(2023, 6, 1)) == 0.000125
    assert r(dt.date(2025, 1, 1)) == 0.0002
    assert r(dt.date(2026, 4, 1)) == 0.0005


def test_round_trip_cost_magnitudes():
    fut = costs.statutory_round_trip("index_fut", dt.date(2026, 6, 1), 1_600_000, mode="historical")
    eq = costs.statutory_round_trip("equity_intraday", dt.date(2026, 6, 1), 500_000, mode="historical")
    assert 5.5e-4 < fut < 6.5e-4      # ~5.9 bp, STT alone is 5 bp
    assert 4.0e-4 < eq < 5.0e-4       # ~4.5 bp


# ----------------------------------------------------------------------------- no look-ahead
def test_positions_lag_signals():
    from exp_tsmom import lag_signal, score
    sig = np.array([[1.0, -1.0, 1.0, 0.0]])
    p = lag_signal(sig, 4)
    assert p.tolist() == [[0.0, 1.0, -1.0, 1.0]]      # first bar never traded on a same-bar signal
    h = np.array([[0.01, 0.02, 0.03, 0.04]])
    gross, rt, _, _ = score(p, h)
    assert abs(gross[0] - (0.02 - 0.03 + 0.04)) < 1e-12
    assert rt[0] == 3.0          # sides: enter 1 + flip 2 + flip 2 + close 1 = 6 -> 3 round trips


def test_neighbours():
    import evaluate
    params = {
        "a": {"name": "a", "k": 5, "thr": 1},
        "b": {"name": "b", "k": 15, "thr": 1},
        "c": {"name": "c", "k": 15, "thr": 2},
        "d": {"name": "d", "k": 5, "thr": 1, "extra": 1},
    }
    assert evaluate.neighbours("a", params) == ["b"]


# ----------------------------------------------------------------------------- events
def test_expiry_rules():
    import events
    days = pd.bdate_range("2025-07-01", "2025-10-31")
    monthly = events._expiry_dates(days, weekly=False)
    got = [d.strftime("%Y-%m-%d") for d in monthly]
    assert "2025-07-31" in got and "2025-08-28" in got     # last Thursdays
    assert "2025-09-30" in got and "2025-10-28" in got     # last Tuesdays after the switch
    # holiday rule: remove the expiry day, expiry moves to the previous trading day
    days2 = days.drop(pd.Timestamp("2025-07-31"))
    assert pd.Timestamp("2025-07-30") in events._expiry_dates(days2, weekly=False)
