"""
intraday_lab / data.py
Load 1-minute bars, validate them, convert to day x minute matrices,
and manage the frozen research / lockbox split.

Conventions
- Timestamps are tz-naive IST, bar START (Kite convention).
- A bar's close is only known when the bar ends, so a signal computed on bar j
  is executed at the OPEN of bar j+1. Every experiment follows this.
"""
import json
import datetime as dt
import numpy as np
import pandas as pd
import config


def sym_file(symbol):
    return config.MINUTE_DIR / (symbol.replace(" ", "_").replace("&", "and") + ".parquet")


def load_minutes(symbol):
    f = sym_file(symbol)
    if not f.exists():
        raise FileNotFoundError(f"No minute data for {symbol}: {f}")
    df = pd.read_parquet(f)
    if "date" in df.columns and not isinstance(df.index, pd.DatetimeIndex):
        df = df.set_index("date")
    df.index = pd.to_datetime(df.index)
    if df.index.tz is not None:
        df.index = df.index.tz_convert("Asia/Kolkata").tz_localize(None)
    df = df.sort_index()
    cols = ["open", "high", "low", "close"] + (["volume"] if "volume" in df.columns else [])
    df = df[cols].astype(float)
    if "volume" not in df.columns:
        df["volume"] = 0.0
    return df


# ----------------------------------------------------------------------------- validation
def audit(df, symbol=""):
    """Return (clean_df, report dict). Drops broken rows and irregular days, flags the rest."""
    rep = {"symbol": symbol, "rows_in": len(df)}
    dup = df.index.duplicated(keep="last")
    rep["duplicates"] = int(dup.sum())
    df = df[~dup]

    t = df.index.strftime("%H:%M")
    in_sess = (t >= config.SESSION_START) & (t <= config.SESSION_END_BAR)
    rep["out_of_session"] = int((~in_sess).sum())
    df = df[in_sess]

    bad_px = (df[["open", "high", "low", "close"]] <= 0).any(axis=1)
    hi_bad = df["high"] < df[["open", "close", "low"]].max(axis=1) - 1e-9
    lo_bad = df["low"] > df[["open", "close", "high"]].min(axis=1) + 1e-9
    rep["bad_ohlc"] = int((bad_px | hi_bad | lo_bad).sum())
    df = df[~(bad_px | hi_bad | lo_bad)]

    day = df.index.normalize()
    counts = df.groupby(day).size()
    irregular = counts[counts < config.MIN_BARS_PER_DAY].index
    rep["irregular_days"] = len(irregular)
    rep["irregular_day_list"] = [d.strftime("%Y-%m-%d") for d in irregular[:20]]
    df = df[~day.isin(irregular)]

    # minute jumps > 8% inside a day are almost always bad ticks
    r = np.log(df["close"]).diff()
    same_day = df.index.normalize() == pd.Series(df.index.normalize()).shift(1).values
    jumps = (r.abs() > 0.08) & same_day
    rep["intraday_jumps_gt8pct"] = int(jumps.sum())

    # overnight gaps > 20% => suspected unadjusted corporate action
    daily_close = df["close"].groupby(df.index.normalize()).last()
    daily_open = df["open"].groupby(df.index.normalize()).first()
    gap = np.log(daily_open / daily_close.shift(1))
    ca_days = gap[gap.abs() > 0.20].index
    rep["suspected_corp_action_days"] = [d.strftime("%Y-%m-%d") for d in ca_days]
    rep["days"] = int(df.index.normalize().nunique())
    rep["first_day"] = str(df.index.min().date()) if len(df) else None
    rep["last_day"] = str(df.index.max().date()) if len(df) else None
    rep["rows_out"] = len(df)
    return df, rep, set(ca_days)


# ----------------------------------------------------------------------------- matrices
class DayMatrix:
    """Day x minute arrays (D x 375). Missing minutes are forward-filled flat with volume 0."""

    def __init__(self, df, symbol="", corp_action_days=()):
        self.symbol = symbol
        minute_idx = (df.index.hour * 60 + df.index.minute) - (9 * 60 + 15)
        days = df.index.normalize()
        self.dates = pd.DatetimeIndex(days.unique())
        d_idx = self.dates.get_indexer(days)
        D, M = len(self.dates), config.BARS_PER_DAY
        arr = {}
        for c in ("open", "high", "low", "close", "volume"):
            a = np.full((D, M), np.nan)
            a[d_idx, minute_idx] = df[c].values
            arr[c] = a
        self.missing = np.isnan(arr["close"])
        # forward fill within day; a leading gap is back-filled from the first real open
        C = pd.DataFrame(arr["close"]).ffill(axis=1).values
        first_open = pd.DataFrame(arr["open"]).bfill(axis=1).values[:, 0]
        C = np.where(np.isnan(C), first_open[:, None], C)
        for c in ("open", "high", "low"):
            arr[c] = np.where(np.isnan(arr[c]), C, arr[c])
        arr["close"] = C
        arr["volume"] = np.nan_to_num(arr["volume"])
        self.O, self.H, self.L, self.C, self.V = (arr[k] for k in ("open", "high", "low", "close", "volume"))
        self.prev_close = np.r_[np.nan, self.C[:-1, -1]]
        # gap unusable on corporate-action days and after a calendar hole > 7 days
        ca = self.dates.isin(list(corp_action_days))
        hole = np.r_[True, np.diff(self.dates.values).astype("timedelta64[D]").astype(int) > 7]
        self.prev_close[ca | hole] = np.nan

    def resample(self, k):
        """Aggregate to k-minute bars aligned at 09:15. Last bar may be partial."""
        starts = np.arange(0, config.BARS_PER_DAY, k)
        O = self.O[:, starts]
        H = np.maximum.reduceat(self.H, starts, axis=1)
        L = np.minimum.reduceat(self.L, starts, axis=1)
        ends = np.r_[starts[1:] - 1, config.BARS_PER_DAY - 1]
        C = self.C[:, ends]
        V = np.add.reduceat(self.V, starts, axis=1)
        return O, H, L, C, V, starts


def minute_of(hhmm):
    h, m = map(int, hhmm.split(":"))
    return h * 60 + m - (9 * 60 + 15)


def load_matrix(symbol):
    df = load_minutes(symbol)
    clean, rep, ca = audit(df, symbol)
    return DayMatrix(clean, symbol, ca), rep


# ----------------------------------------------------------------------------- frozen split
def get_split(index_dates=None):
    """Research/lockbox boundary, frozen the first time it is computed so that adding
    new data never moves it (new data simply lands in lockbox/forward)."""
    if config.SPLIT_FILE.exists():
        return json.loads(config.SPLIT_FILE.read_text())
    if index_dates is None:
        raise RuntimeError("Split not frozen yet: run 'python run.py split' after fetching data.")
    dates = pd.DatetimeIndex(index_dates)
    cut = int(len(dates) * (1 - config.LOCKBOX_FRACTION))
    sp = {
        "research_start": str(dates[0].date()),
        "research_end": str(dates[cut - 1].date()),
        "lockbox_start": str(dates[cut].date()),
        "frozen_on": str(dt.date.today()),
        "note": "Never edit. Lockbox is scored only via 'run.py lockbox'.",
    }
    config.SPLIT_FILE.parent.mkdir(parents=True, exist_ok=True)
    config.SPLIT_FILE.write_text(json.dumps(sp, indent=2))
    return sp


def period_mask(dates, period):
    sp = get_split()
    d = pd.DatetimeIndex(dates)
    if period == "research":
        return np.asarray(d <= pd.Timestamp(sp["research_end"]))
    if period == "lockbox":
        return np.asarray(d >= pd.Timestamp(sp["lockbox_start"]))
    raise ValueError(period)
