"""
intraday_lab / facts.py
Stylized-facts audit of YOUR data (Cont 2001; Andersen & Bollerslev 1997).
Run before any experiment: if the data don't look like real market data, results are noise.

For each instrument, on 5-minute returns (overnight gap excluded):
  shape     mean |r| at the open / midday / close; real NSE data show a U (open >> midday)
  ACF r     autocorrelation of returns at lag 1 bar; should be close to zero
  ACF |r|   raw: has a daily periodic pattern (peaks at lag 75 = one day);
            filtered by the time-of-day profile: should decay slowly and stay positive
            (long memory). The gap between raw and filtered at short lags shows why
            normalisation matters.
  tails     excess kurtosis of 5-min and daily returns (real data: well above 0),
            Hill tail index of daily returns (real data: roughly 2-5)
  leverage  corr(daily r_t, |r_{t+1}|); typically negative for equity indices
Flags are warnings, not verdicts: they tell you where to look.
"""
import numpy as np
import pandas as pd
from scipy import stats
import config
import data
import features


def _acf(x, lags):
    x = np.asarray(x, float)
    x = x[np.isfinite(x)]
    x = x - x.mean()
    v = x @ x
    return {L: float(x[L:] @ x[:-L] / v) if v > 0 and L < len(x) else np.nan for L in lags}


def _hill(x, frac=0.05):
    a = np.sort(np.abs(x[np.isfinite(x)]))[::-1]
    k = max(int(len(a) * frac), 10)
    if len(a) <= k + 1 or a[k] <= 0:
        return np.nan
    return float(1.0 / np.mean(np.log(a[:k] / a[k])))


def audit_symbol(sym):
    dm, _ = data.load_matrix(sym)
    O, H, L, C, V, starts = dm.resample(5)
    R = features.bar_returns(O, C)
    ev = features.expected_variance(R)
    warm = np.isfinite(ev).all(axis=1)
    absR = np.abs(R)
    prof = absR.mean(axis=0)
    mid = prof[len(prof) // 2 - 3: len(prof) // 2 + 3].mean()
    out = {"symbol": sym, "days": len(dm.dates),
           "open_vs_midday": float(prof[:3].mean() / mid),
           "close_vs_midday": float(prof[-3:].mean() / mid)}
    lags = (1, 6, 12, 37, 75, 150)
    raw = _acf(absR[warm].ravel(), lags)
    with np.errstate(invalid="ignore", divide="ignore"):
        filt = _acf((absR / np.sqrt(ev))[warm].ravel(), lags)
    out["acf_r_lag1"] = _acf(R[warm].ravel(), (1,))[1]
    for L_ in lags:
        out[f"acf_abs_raw_{L_}"] = raw[L_]
        out[f"acf_abs_filt_{L_}"] = filt[L_]
    out["exkurt_5min"] = float(stats.kurtosis(R[warm].ravel()))
    daily = np.log(dm.C[:, -1] / dm.prev_close)
    daily = daily[np.isfinite(daily)]
    out["exkurt_daily"] = float(stats.kurtosis(daily)) if len(daily) > 30 else np.nan
    out["hill_daily"] = _hill(daily)
    if len(daily) > 30:
        out["leverage_corr"] = float(np.corrcoef(daily[:-1], np.abs(daily[1:]))[0, 1])
    flags = []
    if out["open_vs_midday"] < 1.3:
        flags.append("no opening volatility spike (expected U-shape)")
    if abs(out["acf_r_lag1"]) > 0.1:
        flags.append("large lag-1 return autocorrelation (stale prices / bad ticks?)")
    if not (filt[12] > 0.05):
        flags.append("weak volatility clustering after filtering")
    if out["exkurt_5min"] < 2:
        flags.append("5-min returns look too normal (synthetic or over-cleaned data?)")
    if np.isfinite(out["hill_daily"]) and not (1.5 <= out["hill_daily"] <= 6):
        flags.append(f"daily tail index {out['hill_daily']:.1f} outside the usual 2-5")
    out["flags"] = "; ".join(flags) or "ok"
    return out, prof


def run(symbols=None):
    files = sorted(config.MINUTE_DIR.glob("*.parquet"))
    symbols = symbols or [f.stem for f in files]
    rows, profiles = [], {}
    for s in symbols:
        try:
            r, prof = audit_symbol(s)
            rows.append(r)
            profiles[s] = prof
        except Exception as ex:
            rows.append({"symbol": s, "flags": f"error: {ex}"})
    t = pd.DataFrame(rows)
    outdir = config.RESEARCH_DIR
    outdir.mkdir(parents=True, exist_ok=True)
    t.to_csv(outdir / "stylized_facts.csv", index=False)
    pd.DataFrame(profiles).to_csv(outdir / "intraday_abs_return_profile_5min.csv")
    show = ["symbol", "open_vs_midday", "close_vs_midday", "acf_r_lag1", "acf_abs_raw_12",
            "acf_abs_filt_12", "acf_abs_filt_75", "exkurt_5min", "exkurt_daily", "hill_daily", "leverage_corr"]
    with pd.option_context("display.width", 220, "display.max_columns", 30):
        print(t[[c for c in show if c in t.columns]].round(3).to_string(index=False))
    print("\nFlags:")
    for _, r in t.iterrows():
        print(f"  {r['symbol']}: {r['flags']}")
    print(f"\nWritten {outdir / 'stylized_facts.csv'} and the 5-minute |return| profile CSV.")
    return t
