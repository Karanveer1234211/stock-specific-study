"""
intraday_lab / exp_early_late.py
Experiment 3 — early-session to late-session market momentum (Gao, Han, Li & Zhou 2018).

Signal (known at 09:45): early return r1, three declared definitions
  full    = P(09:45) / prev close - 1        (GHLZ convention: includes the gap)
  regular = P(09:45) / P(09:15 open) - 1     (regular session only)
  gap     = P(09:15 open) / prev close - 1   (overnight only)
  P(09:45) = close of the 09:44 one-minute bar.
Optional second predictor r12 = P(15:00) / P(14:30) - 1 (closes of 14:59 and 14:29 bars).

Trade: enter at the OPEN of the 15:00 bar, exit at the CLOSE of EOD_EXIT_FUTURES (15:29).
Direction = sign(r1). Filters (declared):
  none     — trade every day
  agree12  — only when sign(r1) == sign(r12)
  highvol  — only when first-30-min realised variance is in the top tercile of the
             trailing 250 days (past only)

Index data are used as the price; execution is assumed on NIFTY futures (costs =
index_fut). Basis noise between index and futures is ignored — check it in paper trading.
NSE's official close is a 15:00-15:30 VWAP; we exit at the 15:29 bar close, which you can
actually trade at, not at the official close.
"""
import numpy as np
import config
import data
import features
from engine import VariantAccumulator

FAMILY = "early_late"
INSTRUMENT = "index_fut"
SYMBOL = config.INDEX_SYMBOL


def variants():
    v = []
    for r1 in ("full", "regular", "gap"):
        for flt in ("none", "agree12", "highvol"):
            v.append({"name": f"el_{r1}_{flt}", "r1": r1, "filter": flt})
    return v


def signals(dm):
    m = data.minute_of
    p945 = dm.C[:, m("09:44")]
    o915 = dm.O[:, 0]
    prev = dm.prev_close
    r1 = {"full": p945 / prev - 1, "regular": p945 / o915 - 1, "gap": o915 / prev - 1}
    r12 = dm.C[:, m("14:59")] / dm.C[:, m("14:29")] - 1
    entry = dm.O[:, m("15:00")]
    exit_ = dm.C[:, m(config.EOD_EXIT_FUTURES)]
    late = exit_ / entry - 1
    R = features.bar_returns(dm.O, dm.C)
    rv30 = (R[:, :30] ** 2).sum(axis=1)
    hv, hv_unknown = features.trailing_tercile_flag(rv30)
    warm = np.arange(len(dm.dates)) >= (config.WARMUP_DAYS + 60)
    return {"r1": r1, "r12": r12, "late": late, "highvol": hv, "warm": warm & ~hv_unknown}


def run(period="research", symbol=None, only=None):
    dm, _ = data.load_matrix(symbol or SYMBOL)
    s = signals(dm)
    pmask = data.period_mask(dm.dates, period)
    out = {}
    for v in variants():
        if only and v["name"] not in only:
            continue
        r1 = s["r1"][v["r1"]]
        active = pmask & s["warm"] & np.isfinite(r1) & np.isfinite(s["late"])
        pos = np.sign(np.nan_to_num(r1))
        if v["filter"] == "agree12":
            pos = np.where(np.sign(s["r12"]) == pos, pos, 0)
        elif v["filter"] == "highvol":
            pos = np.where(s["highvol"], pos, 0)
        gross = pos * np.nan_to_num(s["late"])
        acc = VariantAccumulator(INSTRUMENT)
        acc.add(dm.dates, gross, (pos != 0).astype(int), active)
        out[v["name"]] = (v, acc.finalize())
    return out


def regression_frame(period="research", symbol=None):
    """Arrays for the GHLZ predictive regression (used by the evaluator)."""
    import pandas as pd
    dm, _ = data.load_matrix(symbol or SYMBOL)
    s = signals(dm)
    m = data.period_mask(dm.dates, period) & s["warm"]
    df = pd.DataFrame({"r1_full": s["r1"]["full"], "r1_regular": s["r1"]["regular"],
                       "r1_gap": s["r1"]["gap"], "r12": s["r12"], "late": s["late"]},
                      index=dm.dates)[m].dropna()
    return df
