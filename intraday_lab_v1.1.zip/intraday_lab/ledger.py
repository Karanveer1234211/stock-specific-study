"""
intraday_lab / ledger.py
The trial ledger (Sullivan, Timmermann & White 1999): every variant ever run is recorded,
winners and losers alike, so the multiple-testing corrections know how hard you searched.

SQLite file: <ROOT>/ledger/ledger.sqlite
Daily series: <ROOT>/research/<family>/daily_<field>.parquet  (date x variant)
"""
import datetime as dt
import hashlib
import json
import sqlite3
import pandas as pd
import config

SCHEMA = """
CREATE TABLE IF NOT EXISTS trials (
  trial_id INTEGER PRIMARY KEY AUTOINCREMENT,
  family TEXT, name TEXT, params_json TEXT, params_hash TEXT,
  first_run TEXT, last_run TEXT, times_run INTEGER,
  period TEXT, start_day TEXT, end_day TEXT, days INTEGER, n_trades INTEGER,
  gross_bp_per_trade REAL, net_bp_per_trade REAL, mean_daily_net_bp REAL,
  sharpe_ann REAL, max_dd_pct REAL, code_version TEXT,
  decision TEXT, decision_reason TEXT,
  UNIQUE(family, params_hash)
);
CREATE TABLE IF NOT EXISTS lockbox_log (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  family TEXT, trial_name TEXT, scored_on TEXT, result_json TEXT
);
CREATE TABLE IF NOT EXISTS runs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  family TEXT, run_on TEXT, n_variants INTEGER, cost_mode TEXT,
  slippage_json TEXT, code_version TEXT
);
"""


def connect():
    config.LEDGER_DB.parent.mkdir(parents=True, exist_ok=True)
    con = sqlite3.connect(config.LEDGER_DB)
    con.executescript(SCHEMA)
    return con


def phash(params):
    return hashlib.sha1(json.dumps(params, sort_keys=True, default=str).encode()).hexdigest()[:16]


def record_run(family, results, summaries, period="research"):
    """results: name -> (params, daily_df). summaries: name -> dict from engine.summarize."""
    con = connect()
    now = dt.datetime.now().isoformat(timespec="seconds")
    con.execute("INSERT INTO runs(family, run_on, n_variants, cost_mode, slippage_json, code_version) VALUES (?,?,?,?,?,?)",
                (family, now, len(results), config.COST_MODE, json.dumps(config.SLIPPAGE_BPS_PER_SIDE), config.CODE_VERSION))
    for name, (params, daily) in results.items():
        s = summaries[name]
        h = phash(params)
        start = str(daily.index.min().date()) if len(daily) else None
        end = str(daily.index.max().date()) if len(daily) else None
        row = con.execute("SELECT trial_id, times_run FROM trials WHERE family=? AND params_hash=?", (family, h)).fetchone()
        vals = (period, start, end, s["days"], s["n_trades"], s["gross_bp_per_trade"], s["net_bp_per_trade"],
                s["mean_daily_net_bp"], s["sharpe_ann"], s["max_dd_pct"], config.CODE_VERSION)
        if row:
            con.execute("""UPDATE trials SET last_run=?, times_run=?, period=?, start_day=?, end_day=?, days=?, n_trades=?,
                           gross_bp_per_trade=?, net_bp_per_trade=?, mean_daily_net_bp=?, sharpe_ann=?, max_dd_pct=?,
                           code_version=? WHERE trial_id=?""", (now, row[1] + 1, *vals, row[0]))
        else:
            con.execute("""INSERT INTO trials(family, name, params_json, params_hash, first_run, last_run, times_run,
                           period, start_day, end_day, days, n_trades, gross_bp_per_trade, net_bp_per_trade,
                           mean_daily_net_bp, sharpe_ann, max_dd_pct, code_version)
                           VALUES (?,?,?,?,?,?,1,?,?,?,?,?,?,?,?,?,?,?)""",
                        (family, name, json.dumps(params, default=str), h, now, now, *vals))
    con.commit()
    con.close()
    save_matrices(family, results)


def save_matrices(family, results):
    d = config.RESEARCH_DIR / family
    d.mkdir(parents=True, exist_ok=True)
    for field in ("net", "gross", "stat_cost", "slip_cost", "n_trades", "n_active"):
        m = pd.DataFrame({name: daily[field] for name, (_, daily) in results.items()})
        m.index.name = "date"
        m.sort_index().to_parquet(d / f"daily_{field}.parquet")
    bk = []
    for name, (_, daily) in results.items():
        b = daily.attrs.get("buckets")
        if b is not None and len(b):
            bk.append(b.assign(variant=name))
    if bk:
        pd.concat(bk, ignore_index=True).to_parquet(d / "buckets.parquet")
    (d / "variants.json").write_text(json.dumps({n: p for n, (p, _) in results.items()}, indent=1, default=str))


def load_matrix(family, field="net"):
    f = config.RESEARCH_DIR / family / f"daily_{field}.parquet"
    if not f.exists():
        raise FileNotFoundError(f"No results for {family}. Run: python run.py run --family {family}")
    return pd.read_parquet(f).fillna(0.0)


def load_variants(family):
    return json.loads((config.RESEARCH_DIR / family / "variants.json").read_text())


def n_trials(family=None):
    con = connect()
    q = "SELECT COUNT(*) FROM trials" + (" WHERE family=?" if family else "")
    n = con.execute(q, (family,) if family else ()).fetchone()[0]
    con.close()
    return n


def set_decision(family, name, decision, reason):
    con = connect()
    con.execute("UPDATE trials SET decision=?, decision_reason=? WHERE family=? AND name=?", (decision, reason, family, name))
    con.commit()
    con.close()


def lockbox_history(family):
    con = connect()
    rows = con.execute("SELECT trial_name, scored_on FROM lockbox_log WHERE family=?", (family,)).fetchall()
    con.close()
    return rows


def log_lockbox(family, name, result):
    con = connect()
    con.execute("INSERT INTO lockbox_log(family, trial_name, scored_on, result_json) VALUES (?,?,?,?)",
                (family, name, dt.datetime.now().isoformat(timespec="seconds"), json.dumps(result, default=str)))
    con.commit()
    con.close()


def export_csv(path):
    con = connect()
    pd.read_sql("SELECT * FROM trials ORDER BY family, trial_id", con).to_csv(path, index=False)
    con.close()


def load_buckets(family):
    f = config.RESEARCH_DIR / family / "buckets.parquet"
    return pd.read_parquet(f) if f.exists() else None
