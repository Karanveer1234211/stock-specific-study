"""
intraday_lab / universe.py
Which symbols exist, and which are tradable on each day (point-in-time liquidity).

Survivorship warning: Kite only serves instruments that still exist, so a list of
today's symbols misses stocks that were delisted or merged. Results on stocks are
therefore biased upward somewhat. The index families do not have this problem.
"""
import numpy as np
import pandas as pd
import config

INDEX_FILES = {config.INDEX_SYMBOL, config.BANK_INDEX_SYMBOL}


def stock_symbols():
    out = []
    for f in sorted(config.MINUTE_DIR.glob("*.parquet")):
        sym = f.stem.replace("_", " ")
        if sym in INDEX_FILES:
            continue
        out.append(f.stem)      # keep file-safe name; load_minutes handles it
    return out


def trailing_turnover_cr(dm):
    """Median daily turnover (Rs crore) over the previous LIQ_LOOKBACK days (past only)."""
    turnover = pd.Series((dm.C * dm.V).sum(axis=1), index=dm.dates)
    med = turnover.rolling(config.LIQ_LOOKBACK, min_periods=config.LIQ_LOOKBACK // 2).median().shift(1)
    return med.to_numpy() / 1e7


def liquid_mask(dm):
    """True on day t if the trailing median daily turnover >= LIQ_FLOOR_CR."""
    return np.nan_to_num(trailing_turnover_cr(dm)) >= config.LIQ_FLOOR_CR


def liquidity_label(dm):
    """Per-day liquidity bucket from trailing turnover (declared edges in config.LIQ_BUCKETS_CR)."""
    t = np.nan_to_num(trailing_turnover_cr(dm))
    lo, hi = config.LIQ_BUCKETS_CR
    return np.where(t < lo, f"1 <{lo:g}cr", np.where(t < hi, f"2 {lo:g}-{hi:g}cr", f"3 >{hi:g}cr")).astype(object)
