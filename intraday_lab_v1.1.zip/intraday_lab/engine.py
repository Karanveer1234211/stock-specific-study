"""
intraday_lab / engine.py
Turns per-symbol trade outcomes into one daily return series per variant,
with costs split into statutory and slippage parts so cost sensitivity can be
re-scored without re-simulating.

Capital model: capital split equally across the symbols active that day; each
symbol slot holds at most one position at a time. Daily return = mean over
active symbols of (sum of that symbol's trade returns that day).
"""
import numpy as np
import pandas as pd
import costs


class VariantAccumulator:
    def __init__(self, instrument):
        self.instrument = instrument
        self.parts = []
        self.buckets = {}          # (dim, label) -> [gross_sum, n_trades]

    def add_buckets(self, dim, labels, gross, n_trades, active):
        """Diagnostic attribution of trade outcomes to buckets (time of day, liquidity, ...).
        labels / gross / n_trades: arrays of the same shape, (D,) or (D, C); active: (D,).
        Only research-period active days count."""
        labels = np.asarray(labels, dtype=object)
        g = np.asarray(gross, float)
        n = np.asarray(n_trades, float)
        a = np.asarray(active, bool)
        if g.ndim == 2:
            a = np.broadcast_to(a[:, None], g.shape)
            if labels.ndim == 1:
                labels = np.broadcast_to(labels[:, None], g.shape)
        m = a & (n > 0)
        if not m.any():
            return
        df = pd.DataFrame({"lab": labels[m].astype(str), "g": np.nan_to_num(g[m]), "n": n[m]})
        for lab, row in df.groupby("lab")[["g", "n"]].sum().iterrows():
            cur = self.buckets.setdefault((dim, lab), [0.0, 0.0])
            cur[0] += row["g"]
            cur[1] += row["n"]

    def bucket_frame(self):
        rows = [{"dim": d, "bucket": b, "gross_sum": v[0], "n_trades": v[1]} for (d, b), v in self.buckets.items()]
        return pd.DataFrame(rows, columns=["dim", "bucket", "gross_sum", "n_trades"])

    def add(self, dates, gross, n_trades, active):
        """dates: DatetimeIndex (D,); gross: sum of simple trade returns per day;
        n_trades: round trips per day; active: bool, symbol eligible that day."""
        df = pd.DataFrame({"gross": np.where(active, np.nan_to_num(gross), 0.0),
                           "n_trades": np.where(active, n_trades, 0),
                           "n_active": active.astype(int)}, index=pd.DatetimeIndex(dates))
        self.parts.append(df[df["n_active"] > 0])

    def finalize(self, slip_mult=1.0):
        if not self.parts:
            return pd.DataFrame(columns=["gross", "stat_cost", "slip_cost", "net", "n_trades", "n_active"])
        df = pd.concat(self.parts).groupby(level=0).sum().sort_index()
        # statutory rate per unique date (COST_MODE handled inside costs)
        uniq = pd.Index(np.unique(df.index.date))
        rate = pd.Series([costs.statutory_round_trip(self.instrument, d) for d in uniq], index=uniq)
        stat = rate.reindex(df.index.date).values
        slip = costs.slippage_round_trip(self.instrument, slip_mult)
        out = pd.DataFrame(index=df.index)
        out["gross"] = df["gross"] / df["n_active"]
        out["stat_cost"] = df["n_trades"] * stat / df["n_active"]
        out["slip_cost"] = df["n_trades"] * slip / df["n_active"]
        out["net"] = out["gross"] - out["stat_cost"] - out["slip_cost"]
        out["n_trades"] = df["n_trades"]
        out["n_active"] = df["n_active"]
        out["trade_gross_sum"] = df["gross"]
        out.attrs["buckets"] = self.bucket_frame()
        return out


def tod_label(minute_idx):
    """Time-of-day bucket for a minute index (0 = 09:15)."""
    t = 9 * 60 + 15 + np.asarray(minute_idx)
    edges = np.array([600, 660, 720, 780, 840])          # 10:00 11:00 12:00 13:00 14:00
    names = np.array(["a 09:15-10:00", "b 10:00-11:00", "c 11:00-12:00", "d 12:00-13:00",
                      "e 13:00-14:00", "f 14:00-15:30"], dtype=object)
    return names[np.searchsorted(edges, t, side="right")]


def summarize(daily):
    """Per-variant headline numbers."""
    n = daily["n_trades"].sum()
    net = daily["net"]
    sd = net.std(ddof=1)
    return {
        "days": int(len(daily)),
        "n_trades": int(n),
        "trades_per_day": float(n / max(len(daily), 1)),
        "gross_bp_per_trade": float(daily["trade_gross_sum"].sum() / n * 1e4) if n else np.nan,
        "net_bp_per_trade": float((daily["net"] * daily["n_active"]).sum() / n * 1e4) if n else np.nan,
        "mean_daily_net_bp": float(net.mean() * 1e4),
        "sharpe_ann": float(net.mean() / sd * np.sqrt(250)) if sd > 0 else np.nan,
        "max_dd_pct": float(max_drawdown(net) * 100),
    }


def max_drawdown(r):
    eq = np.cumsum(np.nan_to_num(np.asarray(r)))
    peak = np.maximum.accumulate(np.r_[0.0, eq])[1:]
    return float(np.min(eq - peak)) if len(eq) else 0.0
